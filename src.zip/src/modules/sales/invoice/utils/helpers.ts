export function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(value);
}

export function generateInvoiceNumber() {
  return `INV-${Date.now()}`;
}