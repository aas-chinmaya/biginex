export function calculateSubtotal(items: any[]) {
  return items.reduce(
    (total, item) =>
      total + item.quantity * item.price,
    0
  );
}

export function calculateGrandTotal(
  subtotal: number,
  tax: number
) {
  return subtotal + tax;
}