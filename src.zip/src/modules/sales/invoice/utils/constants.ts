export const INVOICE_STATUS = [
  "Draft",
  "Pending",
  "Paid",
  "Cancelled",
];

export const PAYMENT_TERMS = [
  "Due on Receipt",
  "Net 15",
  "Net 30",
  "Net 45",
];