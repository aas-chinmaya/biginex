// src/lib/invoice/data.ts

/* =========================================================
   STATIC DATA  (never changes from API)
   Used for invoice generation: logo, business, bank etc.
========================================================= */

export const BUSINESS_STATIC = {
  legalName: "AAS INTERNATIONAL PRIVATE LIMITED",
  tradeName: "AAS International Pvt Ltd",
  tagline: "Software Development, IT Solutions & Digital Services",

  addressLine1: "Plot 52, Forest Park,",
  addressLine2: "",
  city: "Bhubaneswar",
  state: "Odisha",
  pincode: "751009",
  country: "India",

  registeredAddress:
    "Plot No. 242/3003, Sanra, Tirtol, Nalibar, Jagatsinghapur, Odisha - 754104",

  phone: "+91 674 123 4567",
  email: "contact@aasint.com",
  accountsEmail: "accounts@aasint.in",
  website: "www.aasint.com",

  gstin: "21AABCA1234D1Z5",
  pan: "AABCA1234D",

  logoText: "AAS",
  slogan: "Innovate. Build. Scale.",

  // Paste real base64 later → "data:image/png;base64,...."
  logoBase64: "",
};

export const BANK_STATIC = {
  bankName: "HDFC Bank",
  branch: "Bhubaneswar Main",
  accountNumber: "50200098765432",
  ifsc: "HDFC0001234",
  upiId: "aasint@hdfcbank",

  upiQrString:
    "upi://pay?pa=aasint@hdfcbank&pn=AAS%20International%20Pvt%20Ltd&cu=INR",

  // Paste real QR base64 later → "data:image/png;base64,...."
qrBase64:
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNk+M9Qz0AEYBxVSF+FABJADveWkH6oAAAAAElFTkSuQmCC",};

export const INVOICE_STATIC = {
  currency: "INR",
  termsAndConditions:
    "Subject to Bhubaneswar Jurisdiction. Payment is due as per agreed terms. Software licenses and services once delivered are non-refundable unless otherwise agreed in writing. Support is provided as per the signed agreement.",
  notes: "Thank you for choosing AAS International Pvt Ltd.",
  footerNote: "This is a computer generated invoice. No signature required.",
};

/* =========================================================
   API / DYNAMIC DATA helpers
========================================================= */

export type InvoiceApiData = {
  invoiceNumber: string | null;
  invoiceDate: string | null;
  dueDate: string | null;
  referenceNumber: string | null;
  placeOfSupply: string | null;
  placeOfSupplyCode: string | null;
};