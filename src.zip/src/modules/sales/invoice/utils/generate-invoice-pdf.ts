import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { Invoice } from "../types/invoice";

export type InvoiceCopyMode = "ORIGINAL" | "DUPLICATE" | "BOTH";
export type InvoiceTheme = "mono" | "ocean" | "emerald" | "violet" | "rose";

interface GeneratePdfOptions {
  inv: Invoice;
  invoiceType: string;
  invoiceStatus: string;
  customerName: string;
  contactName: string | null;
  customerEmail: string | null;
  customerPhone: string | null;
  customerGstin: string | null;
  billingAddress: string;
  sellerName: string;
  sellerAddress: string;
  subtotalAmount: number;
  taxAmountTotal: number;
  copyType?: InvoiceCopyMode;
  theme?: InvoiceTheme;
}

const PALETTES: Record<InvoiceTheme, { primary: [number, number, number]; soft: [number, number, number] }> = {
  mono: { primary: [28, 28, 28], soft: [245, 245, 245] },
  ocean: { primary: [14, 116, 144], soft: [236, 252, 255] },
  emerald: { primary: [5, 122, 85], soft: [236, 253, 245] },
  violet: { primary: [109, 40, 217], soft: [245, 243, 255] },
  rose: { primary: [190, 24, 93], soft: [253, 242, 248] },
};

export function generateInvoicePDF(options: GeneratePdfOptions): Blob {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pages = options.copyType === "BOTH" ? ["ORIGINAL", "DUPLICATE"] as const : [options.copyType ?? "ORIGINAL"] as const;
  pages.forEach((copy, index) => {
    if (index) doc.addPage();
    drawInvoicePage(doc, options, copy);
  });
  return doc.output("blob");
}

function drawInvoicePage(doc: jsPDF, options: GeneratePdfOptions, copy: "ORIGINAL" | "DUPLICATE") {
  const { inv, customerName, contactName, customerEmail, customerPhone, customerGstin, billingAddress, sellerName, sellerAddress, subtotalAmount, taxAmountTotal } = options;
  const palette = PALETTES[options.theme ?? "mono"];
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 12;
  const contentWidth = pageWidth - margin * 2;
  const currency = inv.currency ?? "INR";
  const label = copy === "ORIGINAL" ? "ORIGINAL FOR RECIPIENT" : "DUPLICATE FOR SUPPLIER";

  doc.setFillColor(255, 255, 255); doc.rect(0, 0, pageWidth, pageHeight, "F");
  doc.setFillColor(...palette.primary); doc.roundedRect(margin, 10, contentWidth, 10, 2, 2, "F");
  doc.setTextColor(255, 255, 255); doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.text("TAX INVOICE", margin + 4, 16.4);
  doc.setFont("helvetica", "normal"); doc.setFontSize(7); doc.text(label, pageWidth - margin - 4, 16.2, { align: "right" });


doc.setTextColor(32, 32, 32);
doc.setFont("helvetica", "bold");
doc.setFontSize(11);
doc.text(sellerName || "Your business", margin, 31);

doc.setFont("helvetica", "normal");
doc.setFontSize(7.5);
doc.setTextColor(90, 90, 90);

doc.text(
  doc.splitTextToSize(
    sellerAddress || "Business address",
    92
  ),
  margin,
  38
);

if (inv.sellerGSTIN) {
  doc.text(
    `GSTIN: ${inv.sellerGSTIN}`,
    margin,
    50
  );
}
  const metaX = pageWidth - margin - 60;
  doc.setDrawColor(225, 225, 225); doc.roundedRect(metaX, 25, 60, 38, 2, 2, "S");
  doc.setFont("helvetica", "bold"); doc.setTextColor(...palette.primary); doc.setFontSize(8); doc.text(inv.invoiceNumber ?? "DRAFT", metaX + 4, 32);
  doc.setFont("helvetica", "normal"); doc.setTextColor(75, 75, 75); doc.setFontSize(7);
  drawKeyValue(doc, "Invoice date", formatDate(inv.invoiceDate), metaX + 4, 39, 52);
  drawKeyValue(doc, "Invoice type", options.invoiceType, metaX + 4, 45, 52);
  drawKeyValue(doc, "Status", options.invoiceStatus, metaX + 4, 51, 52);

  const boxY = 70; const half = (contentWidth - 4) / 2;
  drawPartyBox(doc, margin, boxY, half, "BILLED BY", sellerName || "Your business", sellerAddress, inv.sellerGSTIN, palette);
  drawPartyBox(doc, margin + half + 4, boxY, half, "BILLED TO", customerName, [contactName, billingAddress, customerEmail, customerPhone].filter(Boolean).join("\n"), customerGstin, palette);

  const items = inv.items ?? [];
  autoTable(doc, {
    startY: 110,
    margin: { left: margin, right: margin },
    head: [["Item name & description", "HSN/SAC", "GST rate", "Qty", "Rate", "Amount"]],
    body: items.map((item) => [
      [item.itemName ?? item.product ?? item.itemCode ?? "Unnamed item", item.description ?? ""].filter(Boolean).join("\n"),
      item.itemCode ?? "—",
      `${Number(item.gstRate ?? item.tax ?? 0)}%`,
      `${Number(item.quantity ?? 0)} ${item.unit ?? ""}`.trim(),
      money(item.unitPrice, currency),
      money(item.lineTotal, currency),
    ]),
    theme: "grid",
    styles: { font: "helvetica", fontSize: 7.2, cellPadding: 2.6, lineColor: [228, 228, 228], lineWidth: 0.15, textColor: [55, 55, 55] },
    headStyles: { fillColor: palette.primary, textColor: [255, 255, 255], fontStyle: "bold", halign: "center" },
    alternateRowStyles: { fillColor: palette.soft },
    columnStyles: { 0: { cellWidth: 67 }, 1: { cellWidth: 20 }, 2: { cellWidth: 18, halign: "center" }, 3: { cellWidth: 20, halign: "right" }, 4: { cellWidth: 28, halign: "right" }, 5: { cellWidth: 32, halign: "right", fontStyle: "bold" } },
  });
  // @ts-expect-error jspdf-autotable augments jsPDF at runtime.
  let y = (doc.lastAutoTable?.finalY ?? 110) + 8;

  const leftWidth = 112; const rightX = margin + leftWidth + 5; const rightWidth = contentWidth - leftWidth - 5;
  drawPaymentBox(doc, margin, y, leftWidth, inv, palette);
  drawTotals(doc, rightX, y, rightWidth, inv, subtotalAmount, taxAmountTotal, currency, palette);
  y += 44;
  drawNotes(doc, margin, y, contentWidth, inv, palette);

  doc.setDrawColor(...palette.primary); doc.setLineWidth(0.45); doc.line(margin, pageHeight - 18, pageWidth - margin, pageHeight - 18);
  doc.setFont("helvetica", "normal"); doc.setFontSize(6.8); doc.setTextColor(115, 115, 115);
  doc.text("This is a computer-generated invoice.", margin, pageHeight - 12);
  doc.text(label, pageWidth - margin, pageHeight - 12, { align: "right" });
}

function drawPartyBox(doc: jsPDF, x: number, y: number, width: number, caption: string, name: string, body: string, gstin: string | null | undefined, palette: { primary: [number, number, number]; soft: [number, number, number] }) {
  doc.setFillColor(...palette.soft); doc.roundedRect(x, y, width, 34, 2, 2, "F");
  doc.setTextColor(...palette.primary); doc.setFont("helvetica", "bold"); doc.setFontSize(6.8); doc.text(caption, x + 3, y + 5);
  doc.setTextColor(45, 45, 45); doc.setFontSize(8.2); doc.text(name || "—", x + 3, y + 11);
  doc.setFont("helvetica", "normal"); doc.setFontSize(6.7); doc.setTextColor(90, 90, 90); doc.text(doc.splitTextToSize(body || "—", width - 6), x + 3, y + 16);
  if (gstin) { doc.setFont("helvetica", "bold"); doc.text(`GSTIN: ${gstin}`, x + 3, y + 30); }
}

function drawPaymentBox(doc: jsPDF, x: number, y: number, width: number, inv: Invoice, palette: { primary: [number, number, number]; soft: [number, number, number] }) {
  doc.setDrawColor(225, 225, 225); doc.roundedRect(x, y, width, 38, 2, 2, "S");
  doc.setFillColor(...palette.soft); doc.roundedRect(x, y, width, 7, 2, 2, "F"); doc.rect(x, y + 5, width, 2, "F");
  doc.setFont("helvetica", "bold"); doc.setTextColor(...palette.primary); doc.setFontSize(7); doc.text("BANK AND PAYMENT DETAILS", x + 3, y + 4.6);
  doc.setFont("helvetica", "normal"); doc.setTextColor(85, 85, 85); doc.setFontSize(7);
  const lines = [["Payment method", inv.paymentMethod], ["Payment status", inv.paymentStatus], ["Received account", inv.receivedAccount], ["Transaction ID", inv.transactionId]].filter(([, value]) => value);
  lines.forEach(([key, value], index) => drawKeyValue(doc, key, String(value), x + 3, y + 13 + index * 6, width - 6));
}

function drawTotals(doc: jsPDF, x: number, y: number, width: number, inv: Invoice, subtotal: number, tax: number, currency: string, palette: { primary: [number, number, number]; soft: [number, number, number] }) {
  const rows: [string, string][] = [["Subtotal", money(subtotal, currency)], ["Discount", `− ${money(inv.discountAmount, currency)}`], ["Taxable amount", money(inv.taxableAmount ?? subtotal, currency)], ["GST", money(tax, currency)]];
  doc.setFont("helvetica", "normal"); doc.setFontSize(7.3); rows.forEach(([label, value], index) => drawKeyValue(doc, label, value, x, y + 5 + index * 6, width));
  doc.setFillColor(...palette.primary); doc.roundedRect(x, y + 28, width, 10, 2, 2, "F"); doc.setTextColor(255, 255, 255); doc.setFont("helvetica", "bold"); doc.setFontSize(8.4); doc.text("TOTAL DUE", x + 3, y + 34); doc.text(money(inv.grandTotal, currency), x + width - 3, y + 34, { align: "right" });
}


function drawNotes(
  doc: jsPDF,
  x: number,
  y: number,
  width: number,
  inv: Invoice,
  palette: {
    primary: [number, number, number];
    soft: [number, number, number];
  }
) {
  const sections: string[] = [];

  if (inv.termsAndConditions) {
    sections.push(
      `Terms & Conditions\n${inv.termsAndConditions}`
    );
  }

  if (inv.notes) {
    sections.push(
      `Additional Notes\n${inv.notes}`
    );
  }

  if (!sections.length) {
    return y;
  }

  const paddingX = 3;
  const topPadding = 5;
  const bottomPadding = 4;
  const lineHeight = 3.2;
  const contentWidth = width - paddingX * 2;

  const notesText = sections.join("\n\n");

  doc.setFont("helvetica", "normal");
  doc.setFontSize(6.8);

  const lines = doc.splitTextToSize(
    notesText,
    contentWidth
  );

  const contentHeight = lines.length * lineHeight;

  // Header height + content + bottom padding
  const boxHeight =
    topPadding + contentHeight + bottomPadding + 4;

  // Background
  doc.setFillColor(...palette.soft);
  doc.roundedRect(
    x,
    y,
    width,
    boxHeight,
    2,
    2,
    "F"
  );

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(7);
  doc.setTextColor(...palette.primary);

  doc.text(
    "TERMS & NOTES",
    x + paddingX,
    y + 5
  );

  // Content
  doc.setFont("helvetica", "normal");
  doc.setFontSize(6.8);
  doc.setTextColor(85, 85, 85);

  doc.text(
    lines,
    x + paddingX,
    y + 10,
    {
      lineHeightFactor: 1.15,
    }
  );

  return y + boxHeight;
}

function drawKeyValue(doc: jsPDF, label: string, value: string, x: number, y: number, width: number) { doc.setTextColor(125, 125, 125); doc.text(label, x, y); doc.setTextColor(48, 48, 48); doc.text(value, x + width, y, { align: "right" }); }
function money(value: number | null | undefined, currency: string) { return `${currency} ${Number(value ?? 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; }
function formatDate(value: string | null | undefined) { if (!value) return "—"; const date = new Date(value); return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }); }




