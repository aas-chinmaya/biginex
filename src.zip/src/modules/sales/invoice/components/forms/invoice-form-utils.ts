import type { Invoice } from "../../types/types";
import type { InvoiceFormValues } from "../../types/invoice-form.types";
import { DEFAULT_VALUES } from "../../hooks/use-invoice-form";

// ==========================================================
// Helpers
// ==========================================================

const text = (value: unknown): string =>
  String(value ?? "").trim();

const numberValue = (
  value: unknown,
): number => {
  const number = Number(value);

  return Number.isFinite(number)
    ? number
    : 0;
};

const round = (value: number): number =>
  Number(value.toFixed(2));

// ==========================================================
// Required Customer + Items
// ==========================================================

export function invoiceHasRequiredCustomerAndItems(
  values: InvoiceFormValues,
): boolean {
  return Boolean(
    (
      text(values.customerId) ||
      text(values.buyerName)
    ) &&
      text(values.buyerPhone) &&
      text(values.buyerEmail) &&
      text(values.billingAddressLine1) &&
      text(values.billingCity) &&
      text(values.billingState) &&
      text(values.billingStateCode) &&
      text(values.billingPincode) &&
      text(values.placeOfSupply) &&
      text(values.placeOfSupplyCode) &&
      values.items?.some(
        (item) =>
          text(item.productId) &&
          numberValue(item.quantity) > 0,
      ),
  );
}

// ==========================================================
// Required Field Errors
// ==========================================================

export function getRequiredFieldErrors(
  values: InvoiceFormValues,
): Record<string, string> {
  const errors: Record<string, string> = {};

  // --------------------------------------------------------
  // Buyer
  // --------------------------------------------------------

  if (
    !text(values.customerId) &&
    !text(values.buyerName)
  ) {
    errors.customerId = "Buyer is required";
    errors.buyerName = "Buyer name is required";
  }

  // --------------------------------------------------------
  // Invoice Date
  // --------------------------------------------------------

  if (!text(values.invoiceDate)) {
    errors.invoiceDate =
      "Invoice date is required";
  }

  // --------------------------------------------------------
  // Invoice Items
  // --------------------------------------------------------

  if (
    !Array.isArray(values.items) ||
    values.items.length === 0
  ) {
    errors.items =
      "At least one invoice item is required";
  } else {
    const invalidIndex =
      values.items.findIndex(
        (item) =>
          !text(item.productId) ||
          numberValue(item.quantity) <= 0,
      );

    if (invalidIndex >= 0) {
      errors[
        `items.${invalidIndex}.productId`
      ] = "Item and quantity are required";
    }
  }

  // --------------------------------------------------------
  // Billing Address
  // --------------------------------------------------------

  if (!text(values.billingAddressLine1)) {
    errors.billingAddressLine1 =
      "Billing address is required";
  }

  if (!text(values.billingCity)) {
    errors.billingCity =
      "Billing city is required";
  }

  if (!text(values.billingState)) {
    errors.billingState =
      "Billing state is required";
  }

  if (!text(values.billingStateCode)) {
    errors.billingStateCode =
      "Billing state code is required";
  }

  if (!text(values.billingPincode)) {
    errors.billingPincode =
      "Billing pincode is required";
  }

  // --------------------------------------------------------
  // Place of Supply
  // --------------------------------------------------------

  if (!text(values.placeOfSupply)) {
    errors.placeOfSupply =
      "Place of supply is required";
  }

  if (!text(values.placeOfSupplyCode)) {
    errors.placeOfSupplyCode =
      "Place of supply code is required";
  }

  return errors;
}

// ==========================================================
// Convert Form → API Payload
// ==========================================================

export function toInvoicePayload(
  values: InvoiceFormValues,
): Partial<Invoice> {
  const sellerStateCode =
    text(values.sellerStateCode);

  const placeOfSupplyCode =
    text(values.placeOfSupplyCode);

  const billingStateCode =
    text(values.billingStateCode);

  const isIntraStateSupply =
    Boolean(
      sellerStateCode &&
        placeOfSupplyCode &&
        sellerStateCode === placeOfSupplyCode,
    );

  // --------------------------------------------------------
  // Items
  // --------------------------------------------------------

  const items = (values.items ?? []).map(
    (item, index) => {
      const quantity =
        numberValue(item.quantity);

      const rate =
        numberValue(item.rate);

      const subtotal =
        quantity * rate;

      const discountValue =
        numberValue(item.discountValue);

      const discountAmount =
        item.discountType === "fixed"
          ? Math.min(
              discountValue,
              subtotal,
            )
          : Math.min(
              (subtotal * discountValue) / 100,
              subtotal,
            );

      const taxableAmount = round(
        subtotal - discountAmount,
      );

      const cgst =
        isIntraStateSupply
          ? round(
              numberValue(item.cgst),
            )
          : 0;

      const sgst =
        isIntraStateSupply
          ? round(
              numberValue(item.sgst),
            )
          : 0;

      const igst =
        isIntraStateSupply
          ? 0
          : round(
              numberValue(item.igst),
            );

      const cess =
        round(
          numberValue(item.cess),
        );

      const lineTotal = round(
        taxableAmount +
          cgst +
          sgst +
          igst +
          cess,
      );

      return {
        id: item.id,
        productId:
          text(item.productId) ||
          undefined,

        itemId:
          text(item.productId) ||
          undefined,

        itemName:
          text(item.productName),

        product:
          text(item.productName),

        itemCode: null,

        unit:
          text(item.unit) || "NOS",

        hsnSacCode:
          text(item.hsnSacCode) || "NA",

        quantity,

        unitPrice: rate,

        sellingPrice: rate,

        discountType:
          item.discountType.toUpperCase(),

        discountValue,

        discountAmount:
          round(discountAmount),

        gstRate: round(
          isIntraStateSupply
            ? numberValue(item.cgst) +
                numberValue(item.sgst)
            : numberValue(item.igst),
        ),

        taxableAmount,

        cgstAmount: cgst,

        sgstAmount: sgst,

        igstAmount: igst,

        cessAmount: cess,

        lineNumber: index + 1,

        lineTotal,
      };
    },
  );

  // --------------------------------------------------------
  // Totals
  // --------------------------------------------------------

  const subtotal = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.quantity) *
          numberValue(item.unitPrice),
      0,
    ),
  );

  const discountAmount = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.discountAmount),
      0,
    ),
  );

  const taxableAmount = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.taxableAmount),
      0,
    ),
  );

  const cgstAmount = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.cgstAmount),
      0,
    ),
  );

  const sgstAmount = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.sgstAmount),
      0,
    ),
  );

  const igstAmount = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.igstAmount),
      0,
    ),
  );

  const cessAmount = round(
    items.reduce(
      (sum, item) =>
        sum +
        numberValue(item.cessAmount),
      0,
    ),
  );

  const calculatedTotal = round(
    taxableAmount +
      cgstAmount +
      sgstAmount +
      igstAmount +
      cessAmount,
  );

  const roundOffAmount = round(
    numberValue(values.roundOffAmount),
  );

  const totalAmount = round(
    calculatedTotal +
      roundOffAmount,
  );

  const paidAmount = round(
    numberValue(values.paidAmount),
  );

  const pendingAmount = round(
    Math.max(
      totalAmount - paidAmount,
      0,
    ),
  );

  // --------------------------------------------------------
  // Shipping Address
  // --------------------------------------------------------

  const shippingAddress = values.sameAsBilling
    ? {
        shippingAddressLine1:
          text(
            values.billingAddressLine1,
          ),

        shippingAddressLine2:
          text(
            values.billingAddressLine2,
          ),

        shippingCity:
          text(values.billingCity),

        shippingState:
          text(values.billingState),

        shippingStateCode:
          billingStateCode,

        shippingPincode:
          text(values.billingPincode),

        shippingCountry:
          text(values.billingCountry),
      }
    : {
        shippingAddressLine1:
          text(
            values.shippingAddressLine1,
          ),

        shippingAddressLine2:
          text(
            values.shippingAddressLine2,
          ),

        shippingCity:
          text(values.shippingCity),

        shippingState:
          text(values.shippingState),

        shippingStateCode:
          text(
            values.shippingStateCode,
          ),

        shippingPincode:
          text(values.shippingPincode),

        shippingCountry:
          text(values.shippingCountry),
      };

  // --------------------------------------------------------
  // Payload
  // --------------------------------------------------------

  return {
    // ------------------------------------------------------
    // Context
    // ------------------------------------------------------

    businessId:
      text(values.businessId) ||
      undefined,

    branchId:
      text(values.branchId) ||
      undefined,

    // ------------------------------------------------------
    // Invoice
    // ------------------------------------------------------

    invoiceNumber:
      text(values.invoiceNumber) ||
      undefined,

    invoiceDate:
      text(values.invoiceDate) ||
      undefined,

    dueDate:
      text(values.dueDate) ||
      undefined,

    financialYear:
      text(values.financialYear) ||
      undefined,

    invoiceType:
      text(values.invoiceType) ||
      undefined,

    invoiceStatus:
      text(values.invoiceStatus) ||
      undefined,

    invoiceSource:
      text(values.invoiceSource) ||
      undefined,

    referenceNumber:
      text(values.referenceNumber) ||
      undefined,

    // ------------------------------------------------------
    // Seller
    // ------------------------------------------------------

    sellerLegalName:
      text(values.sellerLegalName) ||
      undefined,

    sellerTradeName:
      text(values.sellerTradeName) ||
      undefined,

    sellerGSTIN:
      text(values.sellerGSTIN) ||
      undefined,

    sellerPAN:
      text(values.sellerPAN) ||
      undefined,

    sellerPhone:
      text(values.sellerPhone) ||
      undefined,

    sellerEmail:
      text(values.sellerEmail) ||
      undefined,

    sellerAddressLine1:
      text(values.sellerAddressLine1) ||
      undefined,

    sellerAddressLine2:
      text(values.sellerAddressLine2) ||
      undefined,

    sellerCity:
      text(values.sellerCity) ||
      undefined,

    sellerState:
      text(values.sellerState) ||
      undefined,

    sellerStateCode:
      sellerStateCode ||
      undefined,

    sellerPincode:
      text(values.sellerPincode) ||
      undefined,

    sellerCountry:
      text(values.sellerCountry) ||
      undefined,

    // ------------------------------------------------------
    // Buyer
    // ------------------------------------------------------

    customerId:
      text(values.customerId) ||
      undefined,

    buyerName:
      text(values.buyerName) ||
      undefined,

    buyerCompanyName:
      text(values.buyerCompanyName) ||
      undefined,

    buyerGSTIN:
      text(values.buyerGSTIN) ||
      undefined,

    buyerPAN:
      text(values.buyerPAN) ||
      undefined,

    buyerPhone:
      text(values.buyerPhone) ||
      undefined,

    buyerEmail:
      text(values.buyerEmail) ||
      undefined,

    buyerType:
      text(values.buyerType) ||
      undefined,

    buyerContactPerson:
      text(
        values.buyerContactPerson,
      ) || undefined,

    buyerRevCharge:
      text(values.buyerRevCharge) ||
      undefined,

    // ------------------------------------------------------
    // Billing
    // ------------------------------------------------------

    billingAddressLine1:
      text(
        values.billingAddressLine1,
      ) || undefined,

    billingAddressLine2:
      text(
        values.billingAddressLine2,
      ) || undefined,

    billingCity:
      text(values.billingCity) ||
      undefined,

    billingState:
      text(values.billingState) ||
      undefined,

    billingStateCode:
      billingStateCode ||
      undefined,

    billingPincode:
      text(values.billingPincode) ||
      undefined,

    billingCountry:
      text(values.billingCountry) ||
      undefined,

    // ------------------------------------------------------
    // Shipping
    // ------------------------------------------------------

    ...shippingAddress,

    sameAsBilling:
      Boolean(values.sameAsBilling),

    // ------------------------------------------------------
    // Tax / GST
    // ------------------------------------------------------

    placeOfSupply:
      text(values.placeOfSupply) ||
      undefined,

    placeOfSupplyCode:
      placeOfSupplyCode ||
      undefined,

    taxType:
      text(values.taxType) ||
      undefined,

    reverseCharge:
      Boolean(values.reverseCharge),

    isExport:
      Boolean(values.isExport),

    isSEZ:
      Boolean(values.isSEZ),

    currency:
      text(values.currency) ||
      undefined,

    exchangeRate:
      numberValue(values.exchangeRate),

    // ------------------------------------------------------
    // Items
    // ------------------------------------------------------

    items,

    totalItems:
      items.length,

    totalQuantity:
      items.reduce(
        (sum, item) =>
          sum +
          numberValue(item.quantity),
        0,
      ),

    subtotal,

    discountAmount,

    taxableAmount,

    cgstAmount,

    sgstAmount,

    igstAmount,

    cessAmount,

    roundOffAmount,

    totalAmount,

    // ------------------------------------------------------
    // Payment
    // ------------------------------------------------------

    paymentStatus:
      text(values.paymentStatus) ||
      undefined,

    paymentMethod:
      text(values.paymentMethod) ||
      undefined,

    paidAmount,

    pendingAmount,

    paymentDate:
      text(values.paymentDate) ||
      undefined,

    transactionId:
      text(values.transactionId) ||
      undefined,

    receivedAccount:
      text(values.receivedAccount) ||
      undefined,

    // ------------------------------------------------------
    // E-Invoice
    // ------------------------------------------------------

    irn:
      text(values.irn) ||
      undefined,

    acknowledgementNumber:
      text(
        values.acknowledgementNumber,
      ) || undefined,

    acknowledgementDate:
      text(
        values.acknowledgementDate,
      ) || undefined,

    signedQRCode:
      text(values.signedQRCode) ||
      undefined,

    qrCodeImage:
      text(values.qrCodeImage) ||
      undefined,

    // ------------------------------------------------------
    // Additional
    // ------------------------------------------------------

    notes:
      text(values.notes) ||
      undefined,

    terms:
      text(values.terms) ||
      undefined,
  };
}

// ==========================================================
// Convert API Invoice → Form Values
// ==========================================================

export function toInvoiceFormValues(
  invoice: Invoice,
): InvoiceFormValues {
  const values: InvoiceFormValues = {
    ...DEFAULT_VALUES,
  };

  const source =
    invoice as unknown as Record<
      string,
      unknown
    >;

  const destination =
    values as unknown as Record<
      string,
      unknown
    >;

  // --------------------------------------------------------
  // Copy common scalar fields
  // --------------------------------------------------------

  for (
    const key of Object.keys(
      DEFAULT_VALUES,
    ) as Array<keyof InvoiceFormValues>
  ) {
    if (key === "items") {
      continue;
    }

    const value = source[key];

    if (
      value !== null &&
      value !== undefined
    ) {
      destination[key] = value;
    }
  }

  // --------------------------------------------------------
  // Items
  // --------------------------------------------------------

  const invoiceItems =
    Array.isArray(invoice.items)
      ? invoice.items
      : [];

  values.items = invoiceItems.map(
    (item) => {
      const itemSource =
        item as unknown as Record<
          string,
          unknown
        >;

      return {
        id:
          text(itemSource.id) ||
          undefined,

        productId:
          text(
            itemSource.productId ??
              itemSource.itemId,
          ),

        productName:
          text(
            itemSource.itemName ??
              itemSource.product,
          ),

        unit:
          text(itemSource.unit) ||
          "NOS",

        hsnSacCode:
          text(
            itemSource.hsnSacCode,
          ) || "NA",

        quantity:
          numberValue(
            itemSource.quantity,
          ),

        rate:
          numberValue(
            itemSource.unitPrice ??
              itemSource.sellingPrice,
          ),

        discountType:
          String(
            itemSource.discountType ??
              "percentage",
          ).toLowerCase() === "fixed"
            ? "fixed"
            : "percentage",

        discountValue:
          numberValue(
            itemSource.discountValue,
          ),

        taxableAmount:
          numberValue(
            itemSource.taxableAmount,
          ),

        cgst:
          numberValue(
            itemSource.cgstAmount ??
              itemSource.cgst,
          ),

        sgst:
          numberValue(
            itemSource.sgstAmount ??
              itemSource.sgst,
          ),

        igst:
          numberValue(
            itemSource.igstAmount ??
              itemSource.igst,
          ),

        cess:
          numberValue(
            itemSource.cessAmount ??
              itemSource.cess,
          ),

        totalAmount:
          numberValue(
            itemSource.lineTotal ??
              itemSource.totalAmount,
          ),

        description:
          text(
            itemSource.description,
          ) || undefined,
      };
    },
  );

  return values;
}