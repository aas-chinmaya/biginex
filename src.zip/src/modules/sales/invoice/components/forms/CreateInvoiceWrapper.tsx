"use client";

import { useRouter } from "next/navigation";
import { FormProvider } from "react-hook-form";

import { Button } from "@/components/ui/button";
import { notify } from "@/lib/toast";

import {
  CheckCircle2,
  FilePenLine,
  RotateCcw,
} from "lucide-react";

import BuyerInformationCard from "./buyer-information-card";
import InvoiceDetailsCard from "./invoice-details-card";
import InvoiceItemsCard from "./invoice-items-card";
import InvoicePaymentCard from "./invoice-payment-card";
import InvoiceAdditionalCard from "./invoice-additional-card";

import {
  DEFAULT_VALUES,
  useInvoiceForm,
} from "../../hooks/use-invoice-form";

import { useInvoiceActions } from "../../hooks/use-invoice-actions";

import type { InvoiceFormValues } from "../../types/invoice-form.types";

import {
  getRequiredFieldErrors,
  toInvoicePayload,
} from "./invoice-form-utils";

export default function CreateInvoiceWrapper() {
  const router = useRouter();

  const form = useInvoiceForm();

  const {
    createDraft,
    createInvoice,
  } = useInvoiceActions();

  // ==========================================================
  // Validation
  // ==========================================================

  const validateInvoice = (
    values: InvoiceFormValues,
  ): boolean => {
    const errors = getRequiredFieldErrors(values);

    if (Object.keys(errors).length === 0) {
      return true;
    }

    Object.entries(errors).forEach(
      ([field, message]) => {
        form.setError(
          field as keyof InvoiceFormValues,
          {
            type: "manual",
            message,
          },
        );
      },
    );

    return false;
  };

  // ==========================================================
  // Save Draft
  // ==========================================================

  const handleSaveDraft = async (
    values: InvoiceFormValues,
  ) => {
    if (!validateInvoice(values)) {
      return;
    }

    try {
      const payload = toInvoicePayload(values);

      console.debug(
        "createDraft payload:",
        payload,
      );

      await createDraft(payload).unwrap();

      notify.success("Draft saved");

      router.push("/sales/invoice");
    } catch (error) {
      console.error(
        "Failed to create draft invoice:",
        error,
      );

      notify.error(
        "Failed to save draft",
      );
    }
  };

  // ==========================================================
  // Create Invoice
  // ==========================================================

  const handleCreateInvoice = async (
    values: InvoiceFormValues,
  ) => {
    if (!validateInvoice(values)) {
      return;
    }

    try {
      const payload = toInvoicePayload(values);

      console.debug(
        "createInvoice payload:",
        payload,
      );

      await createInvoice(payload).unwrap();

      notify.success(
        "Invoice created",
      );

      router.push("/sales/invoice");
    } catch (error) {
      console.error(
        "Failed to create invoice:",
        error,
      );

      notify.error(
        "Failed to create invoice",
      );
    }
  };

  // ==========================================================
  // Reset
  // ==========================================================

  const handleReset = () => {
    const businessId =
      form.getValues("businessId");

    const branchId =
      form.getValues("branchId");

    form.reset({
      ...DEFAULT_VALUES,
      businessId,
      branchId,
    });
  };

  // ==========================================================
  // Render
  // ==========================================================

  return (
    <FormProvider {...form}>
      <form
        onSubmit={form.handleSubmit(
          handleCreateInvoice,
        )}
        className="mx-auto w-full max-w-[1600px] space-y-4"
      >
        <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">

          {/* ==================================================
              Buyer + Invoice Details
          ================================================== */}

          <div className="grid min-w-0 grid-cols-1 xl:grid-cols-2">
            <div className="min-w-0 p-4 sm:p-5 lg:p-6">
              <BuyerInformationCard />
            </div>

            <div className="min-w-0 border-t border-gray-200 p-4 sm:p-5 lg:p-6 xl:border-l xl:border-t-0">
              <InvoiceDetailsCard />
            </div>
          </div>

          {/* ==================================================
              Invoice Items
          ================================================== */}

          <div className="border-t border-gray-200 p-4 sm:p-5 lg:p-6">
            <InvoiceItemsCard />
          </div>

          {/* ==================================================
              Payment + Additional
          ================================================== */}

          <div className="grid lg:grid-cols-2">
            <div className="border-t border-gray-200 p-4 sm:p-5 lg:border-l lg:border-t-0 lg:p-6">
              <InvoicePaymentCard />
            </div>

            <div className="border-t border-gray-200 p-4 sm:p-5 lg:border-l lg:border-t-0 lg:p-6">
              <InvoiceAdditionalCard />
            </div>
          </div>

          {/* ==================================================
              Actions
          ================================================== */}

          <div className="border-t border-gray-200 bg-white p-4 sm:p-5">
            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-end">

              {/* Reset */}

              <Button
                type="button"
                variant="outline"
                onClick={handleReset}
                className="gap-2"
              >
                <RotateCcw className="size-4" />
                Reset form
              </Button>

              {/* Save Draft */}

              <Button
                type="button"
                variant="outline"
                onClick={() =>
                  void form.handleSubmit(
                    handleSaveDraft,
                  )()
                }
                className="gap-2"
              >
                <FilePenLine className="size-4" />
                Save Draft
              </Button>

              {/* Save Invoice */}

              <Button
                type="submit"
                className="gap-2"
              >
                <CheckCircle2 className="size-4" />
                Save invoice
              </Button>

            </div>
          </div>
        </div>
      </form>
    </FormProvider>
  );
}