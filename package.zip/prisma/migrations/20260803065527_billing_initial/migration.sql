/*
  Warnings:

  - A unique constraint covering the columns `[businessId,mobile]` on the table `customers` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "ProformaStatus" AS ENUM ('DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'CONVERTED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "ProformaType" AS ENUM ('B2B', 'B2C', 'EXPORT', 'SEZ');

-- CreateEnum
CREATE TYPE "ProformaSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "InvoiceType" AS ENUM ('B2B', 'B2C', 'EXPORT', 'SEZ');

-- CreateEnum
CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT', 'ISSUED', 'PARTIALLY_PAID', 'PAID', 'CANCELLED');

-- CreateEnum
CREATE TYPE "InvoiceSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "BuyerType" AS ENUM ('REGISTERED', 'UNREGISTERED', 'EXPORT');

-- CreateEnum
CREATE TYPE "TaxType" AS ENUM ('INTRA_STATE', 'INTER_STATE');

-- CreateEnum
CREATE TYPE "DeliveryChallanStatus" AS ENUM ('DRAFT', 'DISPATCHED', 'DELIVERED', 'RETURNED', 'CANCELLED', 'CONVERTED');

-- CreateEnum
CREATE TYPE "DeliveryChallanType" AS ENUM ('B2B', 'B2C', 'EXPORT', 'SEZ');

-- CreateEnum
CREATE TYPE "DeliveryChallanSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "DeliveryReason" AS ENUM ('SALE', 'JOB_WORK', 'BRANCH_TRANSFER', 'APPROVAL', 'EXHIBITION', 'EXPORT', 'REPLACEMENT', 'RETURN', 'SAMPLE', 'OTHERS');

-- CreateEnum
CREATE TYPE "TransportMode" AS ENUM ('ROAD', 'RAIL', 'AIR', 'SEA', 'COURIER', 'HAND_DELIVERY');

-- CreateEnum
CREATE TYPE "ReceiptVoucherStatus" AS ENUM ('DRAFT', 'RECEIVED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "ReceiptVoucherType" AS ENUM ('RECEIPT', 'ADVANCE_RECEIPT');

-- CreateEnum
CREATE TYPE "ReceiptAgainstType" AS ENUM ('SALES_INVOICE', 'PROFORMA_INVOICE', 'ADVANCE', 'OTHER');

-- CreateEnum
CREATE TYPE "ReceiptSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "CreditNoteStatus" AS ENUM ('DRAFT', 'ISSUED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "CreditNoteReason" AS ENUM ('SALES_RETURN', 'RATE_DIFFERENCE', 'DAMAGE', 'EXCESS_BILLING', 'POST_SALE_DISCOUNT', 'OTHERS');

-- CreateEnum
CREATE TYPE "CreditNoteSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "DebitNoteStatus" AS ENUM ('DRAFT', 'ISSUED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "DebitNoteReason" AS ENUM ('RATE_DIFFERENCE', 'SHORT_BILLING', 'ADDITIONAL_CHARGES', 'OTHERS');

-- CreateEnum
CREATE TYPE "DebitNoteSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "DiscountType" AS ENUM ('FIXED', 'PERCENTAGE');

-- CreateEnum
CREATE TYPE "GSTClassification" AS ENUM ('GOODS', 'SERVICES');

-- CreateEnum
CREATE TYPE "VoucherStatus" AS ENUM ('DRAFT', 'PAID', 'CANCELLED');

-- CreateEnum
CREATE TYPE "VoucherSource" AS ENUM ('POS', 'MANUAL', 'API');

-- CreateEnum
CREATE TYPE "PaymentMethod" AS ENUM ('CASH', 'UPI', 'CARD', 'NET_BANKING');

-- CreateEnum
CREATE TYPE "PaymentGateway" AS ENUM ('RAZORPAY');

-- CreateEnum
CREATE TYPE "PaymentStatus" AS ENUM ('PENDING', 'SUCCESS', 'FAILED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "PaymentDocumentType" AS ENUM ('SALES_INVOICE', 'RECEIPT_VOUCHER', 'ADVANCE_RECEIPT', 'REFUND_VOUCHER');

-- DropIndex
DROP INDEX "customers_businessId_customerCode_key";

-- CreateTable
CREATE TABLE "advance_payments" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "voucherNumber" TEXT NOT NULL,
    "voucherDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "voucherStatus" "VoucherStatus" NOT NULL DEFAULT 'PAID',
    "voucherSource" "VoucherSource" NOT NULL DEFAULT 'POS',
    "customerId" TEXT,
    "payeeName" TEXT NOT NULL,
    "payeePhone" TEXT,
    "payeeGSTIN" TEXT,
    "advanceAmount" DECIMAL(18,2) NOT NULL,
    "balanceAmount" DECIMAL(18,2) NOT NULL,
    "paymentNumber" TEXT,
    "paymentReference" TEXT,
    "isAdjusted" BOOLEAN NOT NULL DEFAULT false,
    "adjustedAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "adjustmentDocumentNumber" TEXT,
    "adjustmentDate" TIMESTAMP(3),
    "remarks" TEXT,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "advance_payments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "advance_receipts" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "voucherNumber" TEXT NOT NULL,
    "voucherDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "voucherStatus" "ReceiptVoucherStatus" NOT NULL DEFAULT 'RECEIVED',
    "voucherSource" "ReceiptSource" NOT NULL DEFAULT 'POS',
    "customerId" TEXT NOT NULL,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT,
    "customerGSTIN" TEXT,
    "advanceAmount" DECIMAL(18,2) NOT NULL,
    "balanceAmount" DECIMAL(18,2) NOT NULL,
    "paymentNumber" TEXT,
    "isAdjusted" BOOLEAN NOT NULL DEFAULT false,
    "adjustedAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "adjustmentDocumentNumber" TEXT,
    "adjustmentDate" TIMESTAMP(3),
    "remarks" TEXT,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "advance_receipts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "credit_notes" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "creditNoteNumber" TEXT NOT NULL,
    "creditNoteDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "status" "CreditNoteStatus" NOT NULL DEFAULT 'DRAFT',
    "source" "CreditNoteSource" NOT NULL DEFAULT 'POS',
    "customerId" TEXT NOT NULL,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT,
    "customerGSTIN" TEXT,
    "salesInvoiceNumber" TEXT,
    "reason" "CreditNoteReason" NOT NULL,
    "totalItems" INTEGER NOT NULL,
    "totalQuantity" DECIMAL(18,3) NOT NULL,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "roundOffAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "grandTotal" DECIMAL(18,2) NOT NULL,
    "remarks" TEXT,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "credit_notes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "credit_note_items" (
    "id" TEXT NOT NULL,
    "creditNoteId" TEXT NOT NULL,
    "lineNumber" INTEGER NOT NULL,
    "productId" TEXT NOT NULL,
    "itemCode" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT,
    "hsnSacCode" TEXT NOT NULL,
    "itemType" "GSTClassification" NOT NULL,
    "unitCode" TEXT NOT NULL,
    "unitName" TEXT NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "unitPrice" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "gstRate" DECIMAL(5,2) NOT NULL,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "lineTotal" DECIMAL(18,2) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "credit_note_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "debit_notes" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "debitNoteNumber" TEXT NOT NULL,
    "debitNoteDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "status" "DebitNoteStatus" NOT NULL DEFAULT 'DRAFT',
    "source" "DebitNoteSource" NOT NULL DEFAULT 'POS',
    "customerId" TEXT NOT NULL,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT,
    "customerGSTIN" TEXT,
    "salesInvoiceNumber" TEXT,
    "reason" "DebitNoteReason" NOT NULL,
    "totalItems" INTEGER NOT NULL,
    "totalQuantity" DECIMAL(18,3) NOT NULL,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "roundOffAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "grandTotal" DECIMAL(18,2) NOT NULL,
    "remarks" TEXT,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "debit_notes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "debit_note_items" (
    "id" TEXT NOT NULL,
    "debitNoteId" TEXT NOT NULL,
    "lineNumber" INTEGER NOT NULL,
    "productId" TEXT NOT NULL,
    "itemCode" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT,
    "hsnSacCode" TEXT NOT NULL,
    "itemType" "GSTClassification" NOT NULL,
    "unitCode" TEXT NOT NULL,
    "unitName" TEXT NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "unitPrice" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "gstRate" DECIMAL(5,2) NOT NULL,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "lineTotal" DECIMAL(18,2) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "debit_note_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "delivery_challans" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "challanNumber" TEXT NOT NULL,
    "challanDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "challanStatus" "DeliveryChallanStatus" NOT NULL DEFAULT 'DRAFT',
    "challanType" "DeliveryChallanType" NOT NULL,
    "challanSource" "DeliveryChallanSource" NOT NULL DEFAULT 'POS',
    "deliveryReason" "DeliveryReason" NOT NULL,
    "customerId" TEXT NOT NULL,
    "buyerName" TEXT NOT NULL,
    "buyerCompanyName" TEXT,
    "buyerGSTIN" TEXT,
    "buyerPAN" TEXT,
    "buyerPhone" TEXT,
    "buyerEmail" TEXT,
    "buyerType" "BuyerType" NOT NULL,
    "sellerLegalName" TEXT NOT NULL,
    "sellerTradeName" TEXT,
    "sellerGSTIN" TEXT NOT NULL,
    "sellerPAN" TEXT,
    "sellerPhone" TEXT,
    "sellerEmail" TEXT,
    "billingAddressLine1" TEXT NOT NULL,
    "billingAddressLine2" TEXT,
    "billingCity" TEXT NOT NULL,
    "billingState" TEXT NOT NULL,
    "billingStateCode" TEXT NOT NULL,
    "billingPincode" TEXT NOT NULL,
    "billingCountry" TEXT NOT NULL DEFAULT 'India',
    "shippingAddressLine1" TEXT,
    "shippingAddressLine2" TEXT,
    "shippingCity" TEXT,
    "shippingState" TEXT,
    "shippingStateCode" TEXT,
    "shippingPincode" TEXT,
    "shippingCountry" TEXT,
    "transporterName" TEXT,
    "transporterGSTIN" TEXT,
    "transporterId" TEXT,
    "vehicleNumber" TEXT,
    "transportMode" "TransportMode",
    "lrNumber" TEXT,
    "eWayBillNumber" TEXT,
    "dispatchDate" TIMESTAMP(3),
    "expectedDeliveryDate" TIMESTAMP(3),
    "deliveredDate" TIMESTAMP(3),
    "totalItems" INTEGER NOT NULL,
    "totalQuantity" DECIMAL(18,3) NOT NULL,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "roundOffAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "grandTotal" DECIMAL(18,2) NOT NULL,
    "remarks" TEXT,
    "termsAndConditions" TEXT,
    "printCount" INTEGER NOT NULL DEFAULT 0,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "delivery_challans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "delivery_challan_items" (
    "id" TEXT NOT NULL,
    "deliveryChallanId" TEXT NOT NULL,
    "lineNumber" INTEGER NOT NULL,
    "productId" TEXT NOT NULL,
    "itemCode" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT,
    "hsnSacCode" TEXT NOT NULL,
    "itemType" "GSTClassification" NOT NULL,
    "unitCode" TEXT,
    "unitName" TEXT NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "freeQuantity" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "mrp" DECIMAL(18,2),
    "sellingPrice" DECIMAL(18,2),
    "unitPrice" DECIMAL(18,2) NOT NULL,
    "discountType" "DiscountType",
    "discountValue" DECIMAL(18,2),
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "gstRate" DECIMAL(5,2) NOT NULL,
    "cgstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "lineTotal" DECIMAL(18,2) NOT NULL,
    "batchNumber" TEXT,
    "serialNumber" TEXT,
    "expiryDate" TIMESTAMP(3),
    "isTaxInclusive" BOOLEAN NOT NULL DEFAULT false,
    "remarks" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "delivery_challan_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "proforma_invoices" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "proformaNumber" TEXT NOT NULL,
    "proformaDate" TIMESTAMP(3) NOT NULL,
    "validUntil" TIMESTAMP(3),
    "financialYear" TEXT NOT NULL,
    "proformaType" "ProformaType" NOT NULL,
    "proformaStatus" "ProformaStatus" NOT NULL DEFAULT 'DRAFT',
    "proformaSource" "ProformaSource" NOT NULL DEFAULT 'POS',
    "isConverted" BOOLEAN NOT NULL DEFAULT false,
    "convertedInvoiceNumber" TEXT,
    "convertedAt" TIMESTAMP(3),
    "sellerLegalName" TEXT NOT NULL,
    "sellerTradeName" TEXT,
    "sellerGSTIN" TEXT NOT NULL,
    "sellerPAN" TEXT,
    "sellerPhone" TEXT,
    "sellerEmail" TEXT,
    "sellerAddressLine1" TEXT NOT NULL,
    "sellerAddressLine2" TEXT,
    "sellerCity" TEXT NOT NULL,
    "sellerState" TEXT NOT NULL,
    "sellerStateCode" TEXT NOT NULL,
    "sellerPincode" TEXT NOT NULL,
    "sellerCountry" TEXT NOT NULL DEFAULT 'India',
    "customerId" TEXT NOT NULL,
    "buyerName" TEXT NOT NULL,
    "buyerCompanyName" TEXT,
    "buyerGSTIN" TEXT,
    "buyerPAN" TEXT,
    "buyerPhone" TEXT,
    "buyerEmail" TEXT,
    "buyerType" "BuyerType" NOT NULL,
    "billingAddressLine1" TEXT NOT NULL,
    "billingAddressLine2" TEXT,
    "billingCity" TEXT NOT NULL,
    "billingState" TEXT NOT NULL,
    "billingStateCode" TEXT NOT NULL,
    "billingPincode" TEXT NOT NULL,
    "billingCountry" TEXT NOT NULL DEFAULT 'India',
    "shippingAddressLine1" TEXT,
    "shippingAddressLine2" TEXT,
    "shippingCity" TEXT,
    "shippingState" TEXT,
    "shippingStateCode" TEXT,
    "shippingPincode" TEXT,
    "shippingCountry" TEXT,
    "placeOfSupply" TEXT,
    "placeOfSupplyCode" TEXT,
    "taxType" "TaxType" NOT NULL,
    "reverseCharge" BOOLEAN NOT NULL DEFAULT false,
    "isExport" BOOLEAN NOT NULL DEFAULT false,
    "isSEZ" BOOLEAN NOT NULL DEFAULT false,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "exchangeRate" DECIMAL(18,6),
    "totalItems" INTEGER NOT NULL,
    "totalQuantity" DECIMAL(18,3) NOT NULL,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "roundOffAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "grandTotal" DECIMAL(18,2) NOT NULL,
    "notes" TEXT,
    "termsAndConditions" TEXT,
    "printCount" INTEGER NOT NULL DEFAULT 0,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "proforma_invoices_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "proforma_invoice_items" (
    "id" TEXT NOT NULL,
    "proformaInvoiceId" TEXT NOT NULL,
    "lineNumber" INTEGER NOT NULL,
    "productId" TEXT NOT NULL,
    "itemCode" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT,
    "hsnSacCode" TEXT NOT NULL,
    "itemType" "GSTClassification" NOT NULL,
    "unitCode" TEXT NOT NULL,
    "unitName" TEXT NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "freeQuantity" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "mrp" DECIMAL(18,2),
    "sellingPrice" DECIMAL(18,2),
    "unitPrice" DECIMAL(18,2) NOT NULL,
    "discountType" "DiscountType",
    "discountValue" DECIMAL(18,2),
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "gstRate" DECIMAL(5,2) NOT NULL,
    "cgstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "lineTotal" DECIMAL(18,2) NOT NULL,
    "batchNumber" TEXT,
    "serialNumber" TEXT,
    "expiryDate" TIMESTAMP(3),
    "isTaxInclusive" BOOLEAN NOT NULL DEFAULT false,
    "remarks" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "proforma_invoice_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "receipt_vouchers" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "voucherNumber" TEXT NOT NULL,
    "voucherDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "voucherStatus" "ReceiptVoucherStatus" NOT NULL DEFAULT 'DRAFT',
    "voucherType" "ReceiptVoucherType" NOT NULL DEFAULT 'RECEIPT',
    "voucherSource" "ReceiptSource" NOT NULL DEFAULT 'POS',
    "customerId" TEXT NOT NULL,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT,
    "customerGSTIN" TEXT,
    "amountReceived" DECIMAL(18,2) NOT NULL,
    "paymentNumber" TEXT,
    "againstType" "ReceiptAgainstType",
    "againstDocumentNumber" TEXT,
    "remarks" TEXT,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "receipt_vouchers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "refund_vouchers" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "voucherNumber" TEXT NOT NULL,
    "voucherDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "voucherStatus" "ReceiptVoucherStatus" NOT NULL DEFAULT 'RECEIVED',
    "voucherSource" "ReceiptSource" NOT NULL DEFAULT 'POS',
    "customerId" TEXT NOT NULL,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT,
    "customerGSTIN" TEXT,
    "refundAmount" DECIMAL(18,2) NOT NULL,
    "paymentNumber" TEXT,
    "refundReason" TEXT,
    "againstType" "ReceiptAgainstType",
    "againstDocumentNumber" TEXT,
    "remarks" TEXT,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "refund_vouchers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sales_invoices" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "invoiceNumber" TEXT NOT NULL,
    "invoiceDate" TIMESTAMP(3) NOT NULL,
    "financialYear" TEXT NOT NULL,
    "invoiceType" "InvoiceType" NOT NULL,
    "invoiceStatus" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
    "invoiceSource" "InvoiceSource" NOT NULL DEFAULT 'POS',
    "sellerLegalName" TEXT NOT NULL,
    "sellerTradeName" TEXT,
    "sellerGSTIN" TEXT NOT NULL,
    "sellerPAN" TEXT,
    "sellerPhone" TEXT,
    "sellerEmail" TEXT,
    "sellerAddressLine1" TEXT NOT NULL,
    "sellerAddressLine2" TEXT,
    "sellerCity" TEXT NOT NULL,
    "sellerState" TEXT NOT NULL,
    "sellerStateCode" TEXT NOT NULL,
    "sellerPincode" TEXT NOT NULL,
    "sellerCountry" TEXT NOT NULL DEFAULT 'India',
    "customerId" TEXT NOT NULL,
    "buyerName" TEXT NOT NULL,
    "buyerCompanyName" TEXT,
    "buyerGSTIN" TEXT,
    "buyerPAN" TEXT,
    "buyerPhone" TEXT,
    "buyerEmail" TEXT,
    "buyerType" "BuyerType" NOT NULL,
    "billingAddressLine1" TEXT NOT NULL,
    "billingAddressLine2" TEXT,
    "billingCity" TEXT NOT NULL,
    "billingState" TEXT NOT NULL,
    "billingStateCode" TEXT NOT NULL,
    "billingPincode" TEXT NOT NULL,
    "billingCountry" TEXT NOT NULL DEFAULT 'India',
    "shippingAddressLine1" TEXT,
    "shippingAddressLine2" TEXT,
    "shippingCity" TEXT,
    "shippingState" TEXT,
    "shippingStateCode" TEXT,
    "shippingPincode" TEXT,
    "shippingCountry" TEXT,
    "placeOfSupply" TEXT NOT NULL,
    "placeOfSupplyCode" TEXT NOT NULL,
    "taxType" "TaxType" NOT NULL,
    "reverseCharge" BOOLEAN NOT NULL DEFAULT false,
    "isExport" BOOLEAN NOT NULL DEFAULT false,
    "isSEZ" BOOLEAN NOT NULL DEFAULT false,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "exchangeRate" DECIMAL(18,6),
    "totalItems" INTEGER NOT NULL,
    "totalQuantity" DECIMAL(18,3) NOT NULL,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "roundOffAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "grandTotal" DECIMAL(18,2) NOT NULL,
    "paidAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "pendingAmount" DECIMAL(18,2) NOT NULL,
    "irn" TEXT,
    "acknowledgementNumber" TEXT,
    "acknowledgementDate" TIMESTAMP(3),
    "signedQRCode" TEXT,
    "qrCodeImage" TEXT,
    "notes" TEXT,
    "termsAndConditions" TEXT,
    "printCount" INTEGER NOT NULL DEFAULT 0,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "sales_invoices_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sales_invoice_items" (
    "id" TEXT NOT NULL,
    "salesInvoiceId" TEXT NOT NULL,
    "lineNumber" INTEGER NOT NULL,
    "productId" TEXT NOT NULL,
    "itemCode" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT,
    "hsnSacCode" TEXT NOT NULL,
    "classification" "GSTClassification" NOT NULL,
    "unit" TEXT NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "freeQuantity" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "mrp" DECIMAL(18,2),
    "sellingPrice" DECIMAL(18,2),
    "unitPrice" DECIMAL(18,2) NOT NULL,
    "discountType" "DiscountType",
    "discountValue" DECIMAL(18,2),
    "discountAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "taxableAmount" DECIMAL(18,2) NOT NULL,
    "gstRate" DECIMAL(5,2) NOT NULL,
    "cgstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "cgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "sgstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "sgstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "igstRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "igstAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "cessRate" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "cessAmount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "lineTotal" DECIMAL(18,2) NOT NULL,
    "batchNumber" TEXT,
    "serialNumber" TEXT,
    "expiryDate" TIMESTAMP(3),
    "isTaxInclusive" BOOLEAN NOT NULL DEFAULT false,
    "remarks" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sales_invoice_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "payments" (
    "id" TEXT NOT NULL,
    "businessId" TEXT NOT NULL,
    "branchId" TEXT,
    "paymentNumber" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "paymentMethod" "PaymentMethod" NOT NULL,
    "paymentStatus" "PaymentStatus" NOT NULL DEFAULT 'PENDING',
    "paymentDate" TIMESTAMP(3) NOT NULL,
    "remarks" TEXT,
    "documentType" "PaymentDocumentType" NOT NULL,
    "documentNumber" TEXT NOT NULL,
    "paymentGateway" "PaymentGateway",
    "gatewayOrderId" TEXT,
    "gatewayPaymentId" TEXT,
    "gatewaySignature" TEXT,
    "transactionReference" TEXT,
    "gatewayResponse" JSONB,
    "createdBy" TEXT NOT NULL,
    "updatedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "payments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "advance_payments_businessId_idx" ON "advance_payments"("businessId");

-- CreateIndex
CREATE INDEX "advance_payments_branchId_idx" ON "advance_payments"("branchId");

-- CreateIndex
CREATE INDEX "advance_payments_customerId_idx" ON "advance_payments"("customerId");

-- CreateIndex
CREATE INDEX "advance_payments_voucherDate_idx" ON "advance_payments"("voucherDate");

-- CreateIndex
CREATE INDEX "advance_payments_isAdjusted_idx" ON "advance_payments"("isAdjusted");

-- CreateIndex
CREATE UNIQUE INDEX "advance_payments_businessId_voucherNumber_key" ON "advance_payments"("businessId", "voucherNumber");

-- CreateIndex
CREATE INDEX "advance_receipts_businessId_idx" ON "advance_receipts"("businessId");

-- CreateIndex
CREATE INDEX "advance_receipts_branchId_idx" ON "advance_receipts"("branchId");

-- CreateIndex
CREATE INDEX "advance_receipts_customerId_idx" ON "advance_receipts"("customerId");

-- CreateIndex
CREATE INDEX "advance_receipts_voucherDate_idx" ON "advance_receipts"("voucherDate");

-- CreateIndex
CREATE INDEX "advance_receipts_isAdjusted_idx" ON "advance_receipts"("isAdjusted");

-- CreateIndex
CREATE UNIQUE INDEX "advance_receipts_businessId_voucherNumber_key" ON "advance_receipts"("businessId", "voucherNumber");

-- CreateIndex
CREATE INDEX "credit_notes_businessId_idx" ON "credit_notes"("businessId");

-- CreateIndex
CREATE INDEX "credit_notes_branchId_idx" ON "credit_notes"("branchId");

-- CreateIndex
CREATE INDEX "credit_notes_customerId_idx" ON "credit_notes"("customerId");

-- CreateIndex
CREATE UNIQUE INDEX "credit_notes_businessId_creditNoteNumber_key" ON "credit_notes"("businessId", "creditNoteNumber");

-- CreateIndex
CREATE INDEX "credit_note_items_creditNoteId_idx" ON "credit_note_items"("creditNoteId");

-- CreateIndex
CREATE INDEX "credit_note_items_productId_idx" ON "credit_note_items"("productId");

-- CreateIndex
CREATE UNIQUE INDEX "credit_note_items_creditNoteId_lineNumber_key" ON "credit_note_items"("creditNoteId", "lineNumber");

-- CreateIndex
CREATE INDEX "debit_notes_businessId_idx" ON "debit_notes"("businessId");

-- CreateIndex
CREATE INDEX "debit_notes_branchId_idx" ON "debit_notes"("branchId");

-- CreateIndex
CREATE INDEX "debit_notes_customerId_idx" ON "debit_notes"("customerId");

-- CreateIndex
CREATE UNIQUE INDEX "debit_notes_businessId_debitNoteNumber_key" ON "debit_notes"("businessId", "debitNoteNumber");

-- CreateIndex
CREATE INDEX "debit_note_items_debitNoteId_idx" ON "debit_note_items"("debitNoteId");

-- CreateIndex
CREATE INDEX "debit_note_items_productId_idx" ON "debit_note_items"("productId");

-- CreateIndex
CREATE UNIQUE INDEX "debit_note_items_debitNoteId_lineNumber_key" ON "debit_note_items"("debitNoteId", "lineNumber");

-- CreateIndex
CREATE INDEX "delivery_challans_businessId_idx" ON "delivery_challans"("businessId");

-- CreateIndex
CREATE INDEX "delivery_challans_branchId_idx" ON "delivery_challans"("branchId");

-- CreateIndex
CREATE INDEX "delivery_challans_customerId_idx" ON "delivery_challans"("customerId");

-- CreateIndex
CREATE INDEX "delivery_challans_challanDate_idx" ON "delivery_challans"("challanDate");

-- CreateIndex
CREATE INDEX "delivery_challans_challanStatus_idx" ON "delivery_challans"("challanStatus");

-- CreateIndex
CREATE UNIQUE INDEX "delivery_challans_businessId_challanNumber_key" ON "delivery_challans"("businessId", "challanNumber");

-- CreateIndex
CREATE INDEX "delivery_challan_items_deliveryChallanId_idx" ON "delivery_challan_items"("deliveryChallanId");

-- CreateIndex
CREATE INDEX "delivery_challan_items_productId_idx" ON "delivery_challan_items"("productId");

-- CreateIndex
CREATE INDEX "delivery_challan_items_hsnSacCode_idx" ON "delivery_challan_items"("hsnSacCode");

-- CreateIndex
CREATE UNIQUE INDEX "delivery_challan_items_deliveryChallanId_lineNumber_key" ON "delivery_challan_items"("deliveryChallanId", "lineNumber");

-- CreateIndex
CREATE INDEX "proforma_invoices_businessId_idx" ON "proforma_invoices"("businessId");

-- CreateIndex
CREATE INDEX "proforma_invoices_branchId_idx" ON "proforma_invoices"("branchId");

-- CreateIndex
CREATE INDEX "proforma_invoices_customerId_idx" ON "proforma_invoices"("customerId");

-- CreateIndex
CREATE INDEX "proforma_invoices_proformaDate_idx" ON "proforma_invoices"("proformaDate");

-- CreateIndex
CREATE INDEX "proforma_invoices_proformaStatus_idx" ON "proforma_invoices"("proformaStatus");

-- CreateIndex
CREATE INDEX "proforma_invoices_proformaType_idx" ON "proforma_invoices"("proformaType");

-- CreateIndex
CREATE UNIQUE INDEX "proforma_invoices_businessId_financialYear_proformaNumber_key" ON "proforma_invoices"("businessId", "financialYear", "proformaNumber");

-- CreateIndex
CREATE INDEX "proforma_invoice_items_proformaInvoiceId_idx" ON "proforma_invoice_items"("proformaInvoiceId");

-- CreateIndex
CREATE INDEX "proforma_invoice_items_productId_idx" ON "proforma_invoice_items"("productId");

-- CreateIndex
CREATE INDEX "proforma_invoice_items_hsnSacCode_idx" ON "proforma_invoice_items"("hsnSacCode");

-- CreateIndex
CREATE UNIQUE INDEX "proforma_invoice_items_proformaInvoiceId_lineNumber_key" ON "proforma_invoice_items"("proformaInvoiceId", "lineNumber");

-- CreateIndex
CREATE INDEX "receipt_vouchers_businessId_idx" ON "receipt_vouchers"("businessId");

-- CreateIndex
CREATE INDEX "receipt_vouchers_branchId_idx" ON "receipt_vouchers"("branchId");

-- CreateIndex
CREATE INDEX "receipt_vouchers_customerId_idx" ON "receipt_vouchers"("customerId");

-- CreateIndex
CREATE INDEX "receipt_vouchers_voucherDate_idx" ON "receipt_vouchers"("voucherDate");

-- CreateIndex
CREATE UNIQUE INDEX "receipt_vouchers_businessId_voucherNumber_key" ON "receipt_vouchers"("businessId", "voucherNumber");

-- CreateIndex
CREATE INDEX "refund_vouchers_businessId_idx" ON "refund_vouchers"("businessId");

-- CreateIndex
CREATE INDEX "refund_vouchers_branchId_idx" ON "refund_vouchers"("branchId");

-- CreateIndex
CREATE INDEX "refund_vouchers_customerId_idx" ON "refund_vouchers"("customerId");

-- CreateIndex
CREATE INDEX "refund_vouchers_voucherDate_idx" ON "refund_vouchers"("voucherDate");

-- CreateIndex
CREATE UNIQUE INDEX "refund_vouchers_businessId_voucherNumber_key" ON "refund_vouchers"("businessId", "voucherNumber");

-- CreateIndex
CREATE INDEX "sales_invoices_businessId_idx" ON "sales_invoices"("businessId");

-- CreateIndex
CREATE INDEX "sales_invoices_branchId_idx" ON "sales_invoices"("branchId");

-- CreateIndex
CREATE INDEX "sales_invoices_customerId_idx" ON "sales_invoices"("customerId");

-- CreateIndex
CREATE INDEX "sales_invoices_invoiceDate_idx" ON "sales_invoices"("invoiceDate");

-- CreateIndex
CREATE INDEX "sales_invoices_invoiceStatus_idx" ON "sales_invoices"("invoiceStatus");

-- CreateIndex
CREATE INDEX "sales_invoices_invoiceType_idx" ON "sales_invoices"("invoiceType");

-- CreateIndex
CREATE UNIQUE INDEX "sales_invoices_businessId_financialYear_invoiceNumber_key" ON "sales_invoices"("businessId", "financialYear", "invoiceNumber");

-- CreateIndex
CREATE INDEX "sales_invoice_items_salesInvoiceId_idx" ON "sales_invoice_items"("salesInvoiceId");

-- CreateIndex
CREATE INDEX "sales_invoice_items_productId_idx" ON "sales_invoice_items"("productId");

-- CreateIndex
CREATE INDEX "sales_invoice_items_hsnSacCode_idx" ON "sales_invoice_items"("hsnSacCode");

-- CreateIndex
CREATE UNIQUE INDEX "sales_invoice_items_salesInvoiceId_lineNumber_key" ON "sales_invoice_items"("salesInvoiceId", "lineNumber");

-- CreateIndex
CREATE INDEX "payments_businessId_idx" ON "payments"("businessId");

-- CreateIndex
CREATE INDEX "payments_branchId_idx" ON "payments"("branchId");

-- CreateIndex
CREATE INDEX "payments_customerId_idx" ON "payments"("customerId");

-- CreateIndex
CREATE INDEX "payments_paymentMethod_idx" ON "payments"("paymentMethod");

-- CreateIndex
CREATE INDEX "payments_paymentStatus_idx" ON "payments"("paymentStatus");

-- CreateIndex
CREATE INDEX "payments_paymentDate_idx" ON "payments"("paymentDate");

-- CreateIndex
CREATE UNIQUE INDEX "payments_businessId_paymentNumber_key" ON "payments"("businessId", "paymentNumber");

-- CreateIndex
CREATE UNIQUE INDEX "customers_businessId_mobile_key" ON "customers"("businessId", "mobile");

-- AddForeignKey
ALTER TABLE "advance_payments" ADD CONSTRAINT "advance_payments_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "advance_receipts" ADD CONSTRAINT "advance_receipts_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "credit_notes" ADD CONSTRAINT "credit_notes_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "credit_note_items" ADD CONSTRAINT "credit_note_items_creditNoteId_fkey" FOREIGN KEY ("creditNoteId") REFERENCES "credit_notes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "debit_notes" ADD CONSTRAINT "debit_notes_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "debit_note_items" ADD CONSTRAINT "debit_note_items_debitNoteId_fkey" FOREIGN KEY ("debitNoteId") REFERENCES "debit_notes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "delivery_challans" ADD CONSTRAINT "delivery_challans_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "delivery_challan_items" ADD CONSTRAINT "delivery_challan_items_deliveryChallanId_fkey" FOREIGN KEY ("deliveryChallanId") REFERENCES "delivery_challans"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proforma_invoices" ADD CONSTRAINT "proforma_invoices_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "proforma_invoice_items" ADD CONSTRAINT "proforma_invoice_items_proformaInvoiceId_fkey" FOREIGN KEY ("proformaInvoiceId") REFERENCES "proforma_invoices"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "receipt_vouchers" ADD CONSTRAINT "receipt_vouchers_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "refund_vouchers" ADD CONSTRAINT "refund_vouchers_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sales_invoices" ADD CONSTRAINT "sales_invoices_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sales_invoice_items" ADD CONSTRAINT "sales_invoice_items_salesInvoiceId_fkey" FOREIGN KEY ("salesInvoiceId") REFERENCES "sales_invoices"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "payments" ADD CONSTRAINT "payments_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
