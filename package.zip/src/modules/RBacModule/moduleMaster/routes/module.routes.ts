import { Router } from "express";
import {createModule, getAllModules, updateModule , deleteModule } from "../controllers/module.controller";
// import { isAuthenticated } from "../../middleware/auth.middleware";
const router = Router();

router.post("/createModule", createModule);
router.get("/fetchModules", getAllModules);
router.put("/updateModule/:id", updateModule);
router.delete("/deleteModule/:id", deleteModule);

export default router;