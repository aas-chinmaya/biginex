import * as repository from "../repository/module.repository";

export const createModuleService = async (body: any) => {
  const { name, route, description, priority } = body;

  if (!name || !priority) {
    return {
      status: 400,
      message: "Name and priority are required",
    };
  }

  const moduleName = name.trim().toUpperCase();

  const existingModule = await repository.findModuleByName(moduleName);

  // Duplicate check
  if (existingModule && !existingModule.isDeleted) {
    return {
      status: 400,
      message: "Module already exists",
    };
  }

  // Reactivate soft deleted module
  if (existingModule && existingModule.isDeleted) {
    const updatedModule = await repository.updateModuleRepo(
      existingModule.id,
      {
        isDeleted: false,
        route,
        description,
        priority,
      }
    );

    return {
      status: 200,
      message: "Module re-activated",
      data: updatedModule,
    };
  }

  const newModule = await repository.createModuleRepo({
    name: moduleName,
    route,
    description,
    priority,
  });

  return {
    status: 201,
    message: "Module created successfully",
    data: newModule,
  };
};


export const getAllModulesService = async (query: any) => {
  const page = Number(query.page) || 1;
  const limit = query.limit ? Number(query.limit) : null;
  const search = (query.search as string) || "";
  const isAll = query.all === "true";

  const whereClause = {
    isDeleted: false,
    ...(search && {
      name: {
        contains: search,
        mode: "insensitive" as const,
      },
    }),
  };

  // Dropdown
  if (isAll) {
    const modules =
      await repository.getAllModulesDropdownRepo(whereClause);

    return {
      status: 200,
      message: "All modules fetched",
      data: modules,
    };
  }

  const take = limit || 10;
  const skip = (page - 1) * take;

  const totalModules =
    await repository.countModulesRepo(whereClause);

  const modules = await repository.getAllModulesRepo(
    whereClause,
    skip,
    take
  );

  return {
    status: 200,
    message: "Modules fetched successfully",
    data: modules,
    pagination: {
      total: totalModules,
      page,
      limit: take,
      totalPages: Math.ceil(totalModules / take),
    },
  };
};


export const updateModuleService = async (
  id: string,
  body: any
) => {
  const moduleId = String(id);



  const { name, route, description, priority } = body;

  const existingModule = await repository.findModuleById(moduleId);

  if (!existingModule || existingModule.isDeleted) {
    return {
      status: 404,
      message: "Module not found",
    };
  }

  let updatedName = existingModule.name;

  if (name) {
    const moduleName = name.trim().toUpperCase();

    const duplicate = await repository.findModuleByName(moduleName);

    if (duplicate && duplicate.id !== moduleId) {
      return {
        status: 400,
        message: "Module name already exists",
      };
    }

    updatedName = moduleName;
  }

  const updatedModule = await repository.updateModuleRepo(moduleId, {
    name: updatedName,
    route: route ?? existingModule.route,
    description: description ?? existingModule.description,
    priority: priority ?? existingModule.priority,
  });

  return {
    status: 200,
    message: "Module updated successfully",
    data: updatedModule,
  };
};


export const deleteModuleService = async (id: string) => {
  const moduleId = String(id);


  const existingModule = await repository.findModuleById(moduleId);

  if (!existingModule || existingModule.isDeleted) {
    return {
      status: 404,
      message: "Module not found",
    };
  }

  await repository.softDeleteModuleRepo(moduleId);

  return {
    status: 200,
    message: "Module deleted successfully",
  };
};
