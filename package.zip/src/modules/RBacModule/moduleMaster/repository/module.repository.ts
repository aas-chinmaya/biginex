import prisma from "../../../../config/db";



export const findModuleById = async (id: string) => {
  return prisma.module.findUnique({
    where: { id },
  });
};

export const findModuleByName = (name: string) => {
  return prisma.module.findUnique({
    where: { name },
  });
};

export const createModuleRepo = (data: any) => {
  return prisma.module.create({
    data,
  });
};

export const updateModuleRepo = (id: string, data: any) => {
  return prisma.module.update({
    where: { id },
    data,
  });
};


export const getAllModulesRepo = async (
  whereClause: any,
  skip: number,
  take: number
) => {
  return prisma.module.findMany({
    where: whereClause,
    orderBy: {
      priority: "asc",
    },
    skip,
    take,
    include: {
      subModules: {
        where: {
          isDeleted: false,
        },
        orderBy: {
          priority: "asc",
        },
      },
    },
  });
};

export const getAllModulesDropdownRepo = async (whereClause: any) => {
  return prisma.module.findMany({
    where: whereClause,
    orderBy: {
      priority: "asc",
    },
    select: {
      id: true,
      name: true,
    },
  });
};

export const countModulesRepo = async (whereClause: any) => {
  return prisma.module.count({
    where: whereClause,
  });
};

export const softDeleteModuleRepo = async (id: string) => {
  return prisma.module.update({
    where: { id },
    data: { isDeleted: true },
  });
};
