import { Request, Response } from "express";
import * as service from "../services/module.service";

export const createModule = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.createModuleService(req.body);

    return res.status(result.status).json({
      message: result.message,
      module: result.data,
    });
  } catch (error) {
    console.error("Create Module Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const getAllModules = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.getAllModulesService(req.query);

    return res.status(result.status).json({
      message: result.message,
      data: result.data,
      pagination: result.pagination,
    });
  } catch (error) {
    console.error("Get Modules Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const updateModule = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.updateModuleService(
      String(req.params.id),
      req.body
    );

    return res.status(result.status).json({
      message: result.message,
      module: result.data,
    });
  } catch (error) {
    console.error("Update Module Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const deleteModule = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await service.deleteModuleService(
      Number(req.params.id)
    );

    return res.status(result.status).json({
      message: result.message,
    });
  } catch (error) {
    console.error("Delete Module Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};