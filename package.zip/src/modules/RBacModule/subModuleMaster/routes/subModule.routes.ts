import { Router } from "express";
import {createSubModule, getAllSubModules, getSubModulesByModule, updateSubModule, deleteSubModule} from "../controllers/subModule.controller";
import { isAuthenticated } from "../../../../middleware/auth.middleware";
const router = Router();

router.post("/createSubModule", createSubModule);
router.get("/fetchSubModules", getAllSubModules);
router.get("/getSubModulesByModule/:moduleId", getSubModulesByModule);
router.put("/updateSubModule/:id", updateSubModule);
router.delete("/deleteSubModule/:id", deleteSubModule);

export default router;