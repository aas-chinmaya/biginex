import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/subModule.service";

export const createSubModule = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createSubModuleService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getAllSubModules = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getAllSubModulesService(req.query);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
    pagination: result.pagination,
  });
});

export const getSubModulesByModule = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getSubModulesByModuleService(String(req.params.moduleId), req.query);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
    pagination: result.pagination,
  });
});

export const updateSubModule = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateSubModuleService(String(req.params.id), req.body);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteSubModule = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.deleteSubModuleService(String(req.params.id));

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});