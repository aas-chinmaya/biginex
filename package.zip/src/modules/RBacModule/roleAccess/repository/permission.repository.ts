import prisma from "../../../../config/db";

export const findRoleById = async (roleId: string) => {
  return prisma.role.findUnique({
    where: { id: roleId },
  });
};

export const getApisByFeatureIds = async (
  featureIds: string[]
) => {
  return prisma.api.findMany({
    where: {
      featureId: {
        in: featureIds,
      },
      isDeleted: false,
    },
    select: {
      id: true,
    },
  });
};


export const getApiIdsByFeatureId = async (
  featureId: string
) => {
  const apis = await prisma.api.findMany({
    where: {
      featureId,
      isDeleted: false,
    },
    select: {
      id: true,
    },
  });

  return apis.map((api) => api.id);
};

export const getApisBySubModuleIds = async (
  subModuleIds: string[]
) => {
  return prisma.api.findMany({
    where: {
      OR: [
        {
          subModuleId: {
            in: subModuleIds,
          },
        },
        {
          feature: {
            subModuleId: {
              in: subModuleIds,
            },
          },
        },
      ],
      isDeleted: false,
    },
    select: {
      id: true,
    },
  });
};

export const getApisByModuleIds = async (
  moduleIds: string[]
) => {
  return prisma.api.findMany({
    where: {
      OR: [
        {
          moduleId: {
            in: moduleIds,
          },
        },
        {
          subModule: {
            moduleId: {
              in: moduleIds,
            },
          },
        },
        {
          feature: {
            moduleId: {
              in: moduleIds,
            },
          },
        },
        {
          feature: {
            subModule: {
              moduleId: {
                in: moduleIds,
              },
            },
          },
        },
      ],
      isDeleted: false,
    },
    select: {
      id: true,
    },
  });
};

export const getValidApis = async (
  apiIds: string[]
) => {
  return prisma.api.findMany({
    where: {
      id: {
        in: apiIds,
      },
      isDeleted: false,
    },
    select: {
      id: true,
    },
  });
};

export const assignPermissionsTransaction = async (
  operations: any[]
) => {
  return prisma.$transaction(operations);
};

export const createPermissionOperation = (
  roleId: string,
  apiId: string,
  isAllowed: boolean
) => {
  return prisma.roleApiPermission.upsert({
    where: {
      roleId_apiId: {
        roleId,
        apiId,
      },
    },
    update: {
      isAllowed,
    },
    create: {
      roleId,
      apiId,
      isAllowed,
    },
  });
};

export const getRolePermissions = async (
  roleId: string
) => {
  return prisma.roleApiPermission.findMany({
    where: {
      roleId,
    },
    include: {
      api: {
        select: {
          id: true,
          name: true,
          method: true,
          route: true,
        },
      },
    },
  });
};

export const createPermissionOperations = (
  roleId: string,
  apis: { id: string }[],
  isAllowed: boolean
) => {
  return apis.map((api) =>
    prisma.roleApiPermission.upsert({
      where: {
        roleId_apiId: {
          roleId,
          apiId: api.id,
        },
      },
      update: {
        isAllowed,
      },
      create: {
        roleId,
        apiId: api.id,
        isAllowed,
      },
    })
  );
};




export const getAllowedPermissionsRepo = async (
  roleId: string
) => {
  return prisma.rolePermission.findMany({
    where: {
      roleId,
    },
    select: {
      id: true,
      roleId: true,
      moduleId: true,
      subModuleId: true,
      featureId: true,
      apiId: true,
      isAllowed: true,
    },
  });
};


export const getModuleHierarchyRepo = async () => {
  return prisma.module.findMany({
    where: {
      isDeleted: false,
    },

    orderBy: {
      priority: "asc",
    },

    include: {
      // --------------------------------
      // SUB MODULES
      // --------------------------------
      subModules: {
        where: {
          isDeleted: false,
        },

        orderBy: {
          priority: "asc",
        },

        include: {
          // ----------------------------
          // FEATURES UNDER SUB MODULE
          // ----------------------------
          features: {
            where: {
              isDeleted: false,
            },

            include: {
              apis: {
                where: {
                  isDeleted: false,
                },
              },
            },
          },

          // ----------------------------
          // DIRECT APIs UNDER SUB MODULE
          // ----------------------------
          apis: {
            where: {
              isDeleted: false,
            },
          },
        },
      },

      // --------------------------------
      // FEATURES DIRECTLY UNDER MODULE
      // --------------------------------
      features: {
        where: {
          isDeleted: false,
          subModuleId: null,
        },

        include: {
          apis: {
            where: {
              isDeleted: false,
            },
          },
        },
      },

      // --------------------------------
      // DIRECT APIs UNDER MODULE
      // --------------------------------
      apis: {
        where: {
          isDeleted: false,
        },
      },
    },
  });
};


export const saveModulePermission = (
  roleId: string,
  moduleId: string,
  isAllowed: boolean
) => {
  return prisma.rolePermission.upsert({
    where: {
      roleId_moduleId: {
        roleId,
        moduleId,
      },
    },
    update: {
      isAllowed,
    },
    create: {
      roleId,
      moduleId,
      isAllowed,
    },
  });
};


export const saveSubModulePermission = (
  roleId: string,
  subModuleId: string,
  isAllowed: boolean
) => {
  return prisma.rolePermission.upsert({
    where: {
      roleId_subModuleId: {
        roleId,
        subModuleId,
      },
    },
    update: {
      isAllowed,
    },
    create: {
      roleId,
      subModuleId,
      isAllowed,
    },
  });
};

export const executeTransaction = async (
  operations: any[]
) => {
  return prisma.$transaction(operations);
};

export const saveFeaturePermission = (
  roleId: string,
  featureId: string,
  isAllowed: boolean
) => {
  return prisma.rolePermission.upsert({
    where: {
      roleId_featureId: {
        roleId,
        featureId,
      },
    },
    update: {
      isAllowed,
    },
    create: {
      roleId,
      featureId,
      isAllowed,
    },
  });
};


export const saveApiPermission = (
  roleId: string,
  apiId: string,
  isAllowed: boolean
) => {
  return prisma.rolePermission.upsert({
    where: {
      roleId_apiId: {
        roleId,
        apiId,
      },
    },
    update: {
      isAllowed,
    },
    create: {
      roleId,
      apiId,
      isAllowed,
    },
  });
};


export const revokeApiPermission = (
  roleId: string,
  apiId: string
) => {
  return prisma.rolePermission.updateMany({
    where: {
      roleId,
      apiId,
    },
    data: {
      isAllowed: false,
    },
  });
};

export const createApiPermissionOperations = (
  roleId: string,
  apis: { id: string }[],
  isAllowed: boolean
) => {
  return apis.map((api) =>
    prisma.roleApiPermission.upsert({
      where: {
        roleId_apiId: {
          roleId,
          apiId: api.id,
        },
      },
      update: {
        isAllowed,
      },
      create: {
        roleId,
        apiId: api.id,
        isAllowed,
      },
    })
  );
};




export const getRoleHierarchyPermissionsRepo = async (
  roleId: string
) => {
  return prisma.rolePermission.findMany({
    where: {
      roleId,
    },
    select: {
      id: true,
      roleId: true,
      moduleId: true,
      subModuleId: true,
      featureId: true,
      apiId: true,
      isAllowed: true,
    },
  });
};


export const getModuleDescendants = async (
  moduleId: string
) => {
  const module = await prisma.module.findUnique({
    where: {
      id: moduleId,
    },

    include: {
      subModules: {
        where: {
          isDeleted: false,
        },

        include: {
          features: {
            where: {
              isDeleted: false,
            },

            include: {
              apis: {
                where: {
                  isDeleted: false,
                },

                select: {
                  id: true,
                },
              },
            },
          },

          apis: {
            where: {
              isDeleted: false,
            },

            select: {
              id: true,
            },
          },
        },
      },

      features: {
        where: {
          isDeleted: false,
        },

        include: {
          apis: {
            where: {
              isDeleted: false,
            },

            select: {
              id: true,
            },
          },
        },
      },

      apis: {
        where: {
          isDeleted: false,
        },

        select: {
          id: true,
        },
      },
    },
  });

  if (!module) {
    return {
      subModuleIds: [],
      featureIds: [],
      apiIds: [],
    };
  }

  const subModuleIds: string[] = [];
  const featureIds: string[] = [];
  const apiIds = new Set<string>();

  // ------------------------------------------------------------
  // SUB MODULES
  // ------------------------------------------------------------

  for (const subModule of module.subModules) {
    subModuleIds.push(subModule.id);

    // APIs directly under submodule
    for (const api of subModule.apis) {
      apiIds.add(api.id);
    }

    // Features under submodule
    for (const feature of subModule.features) {
      featureIds.push(feature.id);

      for (const api of feature.apis) {
        apiIds.add(api.id);
      }
    }
  }

  // ------------------------------------------------------------
  // FEATURES DIRECTLY UNDER MODULE
  // ------------------------------------------------------------

  for (const feature of module.features) {
    featureIds.push(feature.id);

    for (const api of feature.apis) {
      apiIds.add(api.id);
    }
  }

  // ------------------------------------------------------------
  // APIs DIRECTLY UNDER MODULE
  // ------------------------------------------------------------

  for (const api of module.apis) {
    apiIds.add(api.id);
  }

  return {
    subModuleIds,
    featureIds,
    apiIds: Array.from(apiIds),
  };
};



export const getSubModuleDescendants = async (
  subModuleId: string
) => {
  const subModule =
    await prisma.subModule.findUnique({
      where: {
        id: subModuleId,
      },

      include: {
        features: {
          where: {
            isDeleted: false,
          },

          include: {
            apis: {
              where: {
                isDeleted: false,
              },

              select: {
                id: true,
              },
            },
          },
        },

        apis: {
          where: {
            isDeleted: false,
          },

          select: {
            id: true,
          },
        },
      },
    });

  if (!subModule) {
    return {
      featureIds: [],
      apiIds: [],
    };
  }

  const featureIds: string[] = [];
  const apiIds = new Set<string>();

  // Direct APIs under submodule

  for (const api of subModule.apis) {
    apiIds.add(api.id);
  }

  // Features under submodule

  for (const feature of subModule.features) {
    featureIds.push(feature.id);

    for (const api of feature.apis) {
      apiIds.add(api.id);
    }
  }

  return {
    featureIds,
    apiIds: Array.from(apiIds),
  };
};


export const revokeModulePermissions = (
  roleId: string,
  moduleId: string,
  subModuleIds: string[],
  featureIds: string[],
  apiIds: string[]
) => {
  const conditions: any[] = [
    {
      moduleId,
    },
  ];

  if (subModuleIds.length > 0) {
    conditions.push({
      subModuleId: {
        in: subModuleIds,
      },
    });
  }

  if (featureIds.length > 0) {
    conditions.push({
      featureId: {
        in: featureIds,
      },
    });
  }

  if (apiIds.length > 0) {
    conditions.push({
      apiId: {
        in: apiIds,
      },
    });
  }

  return prisma.rolePermission.updateMany({
    where: {
      roleId,

      OR: conditions,
    },

    data: {
      isAllowed: false,
    },
  });
};




export const revokeSubModulePermissions = (
  roleId: string,
  subModuleId: string,
  featureIds: string[],
  apiIds: string[]
) => {
  const conditions: any[] = [
    {
      subModuleId,
    },
  ];

  if (featureIds.length > 0) {
    conditions.push({
      featureId: {
        in: featureIds,
      },
    });
  }

  if (apiIds.length > 0) {
    conditions.push({
      apiId: {
        in: apiIds,
      },
    });
  }

  return prisma.rolePermission.updateMany({
    where: {
      roleId,

      OR: conditions,
    },

    data: {
      isAllowed: false,
    },
  });
};


export const revokeFeaturePermissions = (
  roleId: string,
  featureId: string,
  apiIds: string[]
) => {
  const conditions: any[] = [
    {
      featureId,
    },
  ];

  if (apiIds.length > 0) {
    conditions.push({
      apiId: {
        in: apiIds,
      },
    });
  }

  return prisma.rolePermission.updateMany({
    where: {
      roleId,

      OR: conditions,
    },

    data: {
      isAllowed: false,
    },
  });
};

export const revokeRoleApiPermission = (
  roleId: string,
  apiId: string
) => {
  return prisma.roleApiPermission.updateMany({
    where: {
      roleId,
      apiId,
    },

    data: {
      isAllowed: false,
    },
  });
};

export const revokeRoleApiPermissions = (
  roleId: string,
  apiIds: string[]
) => {
  if (apiIds.length === 0) {
    return prisma.roleApiPermission.updateMany({
      where: {
        roleId,
        apiId: {
          in: [],
        },
      },
      data: {
        isAllowed: false,
      },
    });
  }

  return prisma.roleApiPermission.updateMany({
    where: {
      roleId,
      apiId: {
        in: apiIds,
      },
    },

    data: {
      isAllowed: false,
    },
  });
};