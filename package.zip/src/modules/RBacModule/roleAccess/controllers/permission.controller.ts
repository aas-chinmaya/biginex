import { Request, Response } from "express";
import * as service from "../services/permission.service";


export const assignPermissions = async (
  req: Request,
  res: Response 
) => {
  try {
    const result =
      await service.assignPermissionsService(
        req.params.roleId as string,
        req.body
      );

    return res.status(result.status).json({
      message: result.message,
      totalApis: result.totalApis,
      permissions: result.permissions,
    });
  } catch (error) {
    console.error(
      "Assign Permissions Error:",
      error
    );

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};


export const getRolePermissions = async (
  req: Request,
  res: Response
) => {
  try {
    const roleId = req.params.roleId as string;

    const result =
      await service.getRolePermissionsService(roleId);

    return res.status(result.status).json({
      message: result.message,
      data: result.data,
    });
  } catch (error) {
    console.error(
      "Get Role Permissions Error:",
      error
    );

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};
