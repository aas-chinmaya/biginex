import { Router } from "express";
import { assignPermissions, getRolePermissions } from "../controllers/permission.controller";
import { isAuthenticated } from "../../../../middleware/auth.middleware";
const router = Router();

router.post("/assign-permissions/:roleId", assignPermissions);
router.get("/role-permissions/:roleId", getRolePermissions);
    

export default router;