import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/role.service";

export const createRole = asyncHandler(async (req: Request, res: Response) => {
  const role = await service.createRoleService(req.body);

  return res.status(201).json({
    success: true,
    message: "Role created successfully",
    data: role,
  });
});

export const getAllRoles = asyncHandler(async (_req: Request, res: Response) => {
  const roles = await service.getAllRolesService();

  return res.status(200).json({
    success: true,
    message: "Roles fetched successfully",
    data: roles,
  });
});

export const updateRole = asyncHandler(async (req: Request, res: Response) => {
  const roleId = req.params.id as string;
  const role = await service.updateRoleService(roleId, req.body);

  return res.status(200).json({
    success: true,
    message: "Role updated successfully",
    data: role,
  });
});

export const deleteRole = asyncHandler(async (req: Request, res: Response) => {
  const roleId = req.params.id as string;
  const role = await service.deleteRoleService(roleId);

  return res.status(200).json({
    success: true,
    message: "Role deleted successfully",
    data: role,
  });
});