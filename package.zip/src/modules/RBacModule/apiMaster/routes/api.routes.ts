import { Router } from "express";
import {createApi, getAllApis, getApisByFeature , updateApi, deleteApi, getApisByModule, getApisBySubModule} from "../controllers/api.controller";
import { isAuthenticated } from "../../../../middleware/auth.middleware";
const router = Router();

router.post("/createApi", createApi);
router.get("/getAllApis", getAllApis);
router.get("/getApisByFeature/:featureId", getApisByFeature);
router.get("/getApisByModule/:moduleId", getApisByModule);
router.get("/getApisBySubModule/:subModuleId", getApisBySubModule);
router.put("/updateApi/:id", updateApi);
router.delete("/deleteApi/:id", deleteApi);


export default router;