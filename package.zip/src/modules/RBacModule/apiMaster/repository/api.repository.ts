import prisma from "../../../../config/db";

export const findFeatureById = async (id: string) => {
    return await prisma.feature.findUnique({
        where: { id },
    });
};

export const findSubModuleById = async (id: string) => {
    return await prisma.subModule.findUnique({
        where: { id },
    });
};

export const findModuleById = async (id: string) => {
    return await prisma.module.findUnique({
        where: { id },
    });
};

export const createApiRepo = (data: any) => {
    return prisma.api.create({
        data,
    });
};

export const updateApiRepo = (id: string, data: any) => {
    return prisma.api.update({
        where: { id },
        data,
    });
}

export const findApiById = async (id: string) => {
    return await prisma.api.findUnique({
        where: { id },
    });
};


export const findApiByMethodAndRoute = (
  method: string,
  route: string
) => {
  return prisma.api.findFirst({
    where: {
      method,
      route,
    },
  });
};

export const countApisRepo = async (whereClause: any) => {
  return prisma.api.count({
    where: whereClause,
  });
};

export const getAllApisDropdownRepo = async (
  whereClause: any
) => {
  return prisma.api.findMany({
    where: whereClause,
    orderBy: {
      createdAt: "desc",
    },
    select: {
      id: true,
      name: true,
      route: true,
      method: true,
    },
  });
};

export const getAllApisRepo = async (
  whereClause: any,
  skip: number,
  take: number
) => {
  return prisma.api.findMany({
    where: whereClause,
    orderBy: {
      createdAt: "desc",
    },
    skip,
    take,
    include: {
      feature: {
        include: {
          subModule: {
            include: {
              module: true,
            },
          },
          module: true,
        },
      },
      subModule: {
        include: {
          module: true,
        },
      },
      module: true,
    },
  });
};

export const getApisByFeatureRepo = async (
  featureId: string
) => {
  return prisma.api.findMany({
    where: {
      featureId,
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const getApisBySubModuleRepo = async (
  subModuleId: string
) => {
  return prisma.api.findMany({
    where: {
      subModuleId,
      featureId: null,
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const getApisByModuleRepo = async (
  moduleId: string
) => {
  return prisma.api.findMany({
    where: {
      moduleId,
      featureId: null,
      subModuleId: null,
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const deleteApiRepo = async (id: string) => {
  return prisma.api.update({
    where: { id },
    data: {
      isDeleted: true,
    },
  });
};
