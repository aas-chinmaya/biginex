import prisma from "../../../../config/db";

export const findModuleById = async (id: string) => {
  return prisma.module.findUnique({
    where: { id },
  });
};

export const findSubModuleById = async (id: string) => {
  return prisma.subModule.findUnique({
    where: { id },
  });
};

export const findFeatureByName = async (
  name: string,
  subModuleId: string | null,
  moduleId: string | null
) => {
  return prisma.feature.findFirst({
    where: {
      name,
      subModuleId,
      moduleId,
    },
  });
};

export const createFeatureRepo = async (data: any) => {
  return prisma.feature.create({
    data,
  });
};

export const updateFeatureRepo = async (
  id: string,
  data: any
) => {
  return prisma.feature.update({
    where: { id },
    data,
  });
};


export const countFeaturesRepo = async (whereClause: any) => {
  return prisma.feature.count({
    where: whereClause,
  });
};

export const getAllFeaturesDropdownRepo = async (
  whereClause: any
) => {
  return prisma.feature.findMany({
    where: whereClause,
    orderBy: {
      createdAt: "desc",
    },
    select: {
      id: true,
      name: true,
    },
  });
};

export const getAllFeaturesRepo = async (
  whereClause: any,
  skip: number,
  take: number
) => {
  return prisma.feature.findMany({
    where: whereClause,
    orderBy: {
      createdAt: "desc",
    },
    skip,
    take,
    include: {
      subModule: {
        select: {
          id: true,
          name: true,
          module: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      },
      module: {
        select: {
          id: true,
          name: true,
        },
      },
      apis: {
        where: {
          isDeleted: false,
        },
        select: {
          id: true,
          name: true,
          method: true,
          route: true,
        },
      },
    },
  });
};

export const getFeaturesBySubModuleRepo = async (
  subModuleId: string
) => {
  return prisma.feature.findMany({
    where: {
      subModuleId,
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
    include: {
      apis: {
        where: {
          isDeleted: false,
        },
      },
    },
  });
};

export const getFeaturesByModuleRepo = async (
  moduleId: string
) => {
  return prisma.feature.findMany({
    where: {
      moduleId,
      subModuleId: null,
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
    include: {
      apis: {
        where: {
          isDeleted: false,
        },
      },
    },
  });
};

export const findFeatureById = async (id: string) => {
  return prisma.feature.findUnique({
    where: { id },
  });
};

export const findDuplicateFeature = async (
  name: string,
  subModuleId: string | null,
  moduleId: string | null,
  id: string
) => {
  return prisma.feature.findFirst({
    where: {
      name,
      subModuleId,
      moduleId,
      NOT: {
        id,
      },
    },
  });
};

export const deleteFeatureRepo = async (id: string) => {
  return prisma.feature.update({
    where: { id },
    data: {
      isDeleted: true,
    },
  });
};
