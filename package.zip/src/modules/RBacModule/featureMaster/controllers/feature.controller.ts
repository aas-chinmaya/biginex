import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/feature.service";

export const createFeature = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createFeatureService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getAllFeatures = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getAllFeaturesService(req.query);

  return res.status(200).json({
    success: true,
    message: result.message,
    count: result.count,
    data: result.data,
    pagination: result.pagination,
  });
});

export const getFeaturesBySubModule = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getFeaturesBySubModuleService(String(req.params.subModuleId));

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getFeaturesByModule = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getFeaturesByModuleService(String(req.params.moduleId));

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateFeature = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateFeatureService(String(req.params.id), req.body);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteFeature = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.deleteFeatureService(String(req.params.id));

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});