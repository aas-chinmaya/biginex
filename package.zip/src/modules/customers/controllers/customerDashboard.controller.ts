import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as customerDashboardService from "../services/customerDashboard.service";

export const getCustomerDashboard = asyncHandler(async (req: Request, res: Response) => {
    const customerId = req.params.customerId as string;
    const dashboard = await customerDashboardService.getCustomerDashboard(customerId);
    return res.status(200).json({ success: true, data: dashboard });
});