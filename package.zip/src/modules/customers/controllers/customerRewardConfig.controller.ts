// import { Request, Response } from "express";
// import asyncHandler from "../../../common/helpers/asyncHandler";
// import * as service from "../services/customerRewardConfig.service";

// export const createConfig = asyncHandler(async (req: Request, res: Response) => {
    
//     const data = await service.createConfig(req.body);
//     res.status(201).json({ success: true, data });
// });

// export const getConfig = asyncHandler(async (req: Request, res: Response) => {
//     const id  = req.params.businessId as string;

//     const data = await service.getConfig(id, req.query.branchId as string);
//     res.status(200).json({ success: true, data });
// });

// export const updateConfig = asyncHandler(async (req: Request, res: Response) => {
//     const id = req.params.businessId as string;
//     const data = await service.updateConfig(id, req.query.branchId as string, req.body);
//     res.status(200).json({ success: true, data });
// });

// export const deleteConfig = asyncHandler(async (req: Request, res: Response) => {
//     const id = req.params.businessId as string;
    
//     const data = await service.deleteConfig(id, req.query.branchId as string);
//     res.status(200).json({ success: true, data });
// });

import {Prisma} from "@prisma/client";
import { Request, Response } from "express";
import prisma from "../../../config/db";
import asyncHandler from "../../../common/helpers/asyncHandler";
import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import * as service from "../services/customerRewardConfig.service";
import * as rewardService from "../services/customerReward.service";

export const createConfig = asyncHandler(
  async (req: Request, res: Response) => {
    const data = await service.createConfig(req.body);

    res.status(201).json({
      success: true,
      message: "Reward configuration created successfully.",
      data
    });
  }
);

export const getConfig = asyncHandler(
  async (req: Request, res: Response) => {
    const { businessId, branchId } = req.params as { businessId: string, branchId: string };

    const data = await service.getConfig(
      businessId,
      branchId
    );

    res.status(200).json({
      success: true,
      data
    });
  }
);

export const updateConfig = asyncHandler(
  async (req: Request, res: Response) => {
    const { businessId, branchId } = req.params as { businessId: string, branchId: string };

    const data = await service.updateConfig(
      businessId,
      branchId,
      req.body
    );

    res.status(200).json({
      success: true,
      message: "Reward configuration updated successfully.",
      data
    });
  }
);

export const deleteConfig = asyncHandler(
  async (req: Request, res: Response) => {
    const { businessId, branchId } = req.params as { businessId: string, branchId: string };

    const data = await service.deleteConfig(
      businessId,
      branchId
    );

    res.status(200).json({
      success: true,
      ...data
    });
  }
);


/**
 * REWARD POINTS MANAGEMENT CONTROLLERS
 */
export const getRewardHistory = asyncHandler(
  async (req: Request, res: Response) => {
    const { customerId } = req.params as { customerId: string };

    const data = await rewardService.getRewardHistory(customerId, {
      branchId: req.query.branchId as string,
      type: req.query.type as string,
      page: Number(req.query.page ?? 1),
      limit: Number(req.query.limit ?? 20)
    });

    res.status(200).json({
      success: true,
      data
    });
  }
);

export const redeemRewardPoints = asyncHandler(
  async (req: Request, res: Response) => {
    const {
      businessId,
      branchId,
      customerId,
      points,
      invoiceId,
      invoiceNumber,
      createdBy
    } = req.body;

    const result = await prisma.$transaction((tx) =>
      rewardService.redeemRewardPoints({
        tx,
        businessId,
        branchId,
        customerId,
        points: Number(points),
        invoiceId,
        invoiceNumber,
        createdBy
      })
    );

    res.status(200).json({
      success: true,
      message: "Reward points redeemed successfully.",
      data: result
    });
  }
);

