import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import { ValidationError } from "../../../common/exceptions/ValidationError";
import * as customerPurchaseService from "../services/customerPurchase.service";

export const getPurchaseHistory = asyncHandler(async (req: Request, res: Response) => {
    const customerId = req.params.customerId as string;
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 20;
    const fromDate = req.query.fromDate ? new Date(req.query.fromDate as string) : undefined;
    const toDate = req.query.toDate ? new Date(req.query.toDate as string) : undefined;

    if (fromDate && isNaN(fromDate.getTime())) throw new ValidationError("Invalid fromDate.");
    if (toDate && isNaN(toDate.getTime())) throw new ValidationError("Invalid toDate.");
    if (fromDate && toDate && fromDate > toDate) throw new ValidationError("fromDate cannot be greater than toDate.");

    const result = await customerPurchaseService.getPurchaseHistory(
        customerId,
        page,
        limit,
        fromDate,
        toDate,
        req.query.status as string,
        req.query.invoiceType as string,
        req.query.search as string
    );

    return res.status(200).json({ success: true, data: result });
});