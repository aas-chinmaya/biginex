import express from "express";
console.log("🔥 CUSTOMER ROUTES FILE LOADED");
const router = express.Router();
import * as customerController from "../controllers/customer.controller";
import * as customerLedgerController from "../controllers/customerLedger.controller";
import * as customerPurchaseController from "../controllers/customerPurchase.controller";
import * as customerDashboardController from "../controllers/customerDashboard.controller";
import * as customerRewardConfigController from "../controllers/customerRewardConfig.controller";
/**
 * ---------------------------------------------------------
 * Customer APIs    
 * ---------------------------------------------------------
*/
router.post("/create", customerController.createCustomer);
router.get("/fetch/:id", customerController.getCustomerById);
router.get("/fetch", customerController.getCustomers);
router.patch("/update/:id", customerController.updateCustomer);
router.delete("/delete/:id", customerController.deleteCustomer);


/**
 * ---------------------------------------------------------
 * Customer_Ledger APIs    
 * ---------------------------------------------------------
*/
router.get("/:customerId/ledger", customerLedgerController.getCustomerLedger);
router.get("/:customerId/outstanding", customerLedgerController.getCustomerOutstanding);
router.get("/:customerId/statement", customerLedgerController.getCustomerStatement);

/**
 * ---------------------------------------------------------
 * Customer_Purchase APIs    
 * ---------------------------------------------------------
*/
router.get("/:customerId/purchases", customerPurchaseController.getPurchaseHistory);

/**
 * ---------------------------------------------------------
 * Customer_Dashboard APIs    
 * ---------------------------------------------------------
*/
router.get("/:customerId/dashboard", customerDashboardController.getCustomerDashboard);

/**
 * ---------------------------------------------------------
 * Customer_Reward_Config APIs    
 * ---------------------------------------------------------
*/
router.post("/rewards/config", customerRewardConfigController.createConfig);
router.get("/rewards/config/:businessId/:branchId", customerRewardConfigController.getConfig);
router.patch("/rewards/config/:businessId/:branchId", customerRewardConfigController.updateConfig);
router.delete("/rewards/config/:businessId/:branchId", customerRewardConfigController.deleteConfig);

/**
 * ---------------------------------------------------------
 * Customer_Reward_History APIs    
 * ---------------------------------------------------------
*/
router.get("/:rewardsId/rewards/history", customerRewardConfigController.getRewardHistory);

export default router;