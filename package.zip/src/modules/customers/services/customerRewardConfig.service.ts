import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import * as repository from "../repository/customerRewardConfig.repository";

export const getConfig = async (businessId: string, branchId?: string) => {
  const config = await repository.findConfig(businessId, branchId);
  if (!config) 
    throw new NotFoundError("Reward configuration not found.");
  return config;
};

export const createConfig = async (payload: any) => {
  const existing = await repository.findConfig(payload.businessId, payload.branchId);
  if (existing) 
    throw new ConflictError("Reward configuration already exists.");

  return repository.createConfig({
    businessId: payload.businessId,
    branchId: payload.branchId,
    isEnabled: payload.isEnabled ?? false,
    pointsPerCurrency: payload.pointsPerCurrency ?? 1,
    currencyPerPoint: payload.currencyPerPoint ?? 100,
    minimumInvoiceAmount: payload.minimumInvoiceAmount ?? 0,
    redemptionEnabled: payload.redemptionEnabled ?? false,
    pointValue: payload.pointValue ?? 1,
    minimumRedeemPoints: payload.minimumRedeemPoints ?? 0,
    maximumRedeemPoints: payload.maximumRedeemPoints,
    maximumRedeemPercentage: payload.maximumRedeemPercentage ?? 100,
    expiryEnabled: payload.expiryEnabled ?? false,
    expiryDays: payload.expiryDays,
    createdBy: payload.createdBy
  });
};

export const updateConfig = async (businessId: string, branchId: string | undefined, payload: any) => {
  const existing = await repository.findConfig(businessId, branchId);
  if (!existing) 
    throw new NotFoundError("Reward configuration not found.");

  const { createdBy, businessId: _, branchId: __, ...data } = payload;

  await repository.updateConfig(businessId, branchId, data);
  return repository.findConfig(businessId, branchId);
};

export const deleteConfig = async (businessId: string, branchId?: string) => {
  const existing = await repository.findConfig(businessId, branchId);
  if (!existing) 
    throw new NotFoundError("Reward configuration not found.");

  await repository.deleteConfig(businessId, branchId);
  return { message: "Reward configuration deleted successfully." };
};