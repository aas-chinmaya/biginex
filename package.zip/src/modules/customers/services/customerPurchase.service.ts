import NotFoundError from "../../../common/exceptions/NotFoundError";
import * as customerRepository from "../repository/customer.repository";
import * as customerPurchaseRepository from "../repository/customerPurchase.repository";

export const getPurchaseHistory = async (
  customerId: string,
  page = 1,
  limit = 20,
  fromDate?: Date,
  toDate?: Date,
  status?: any,
  invoiceType?: any,
  search?: string
) => {
  const customer = await customerRepository.findById(customerId);
  if (!customer) throw new NotFoundError("Customer not found.");

  const [purchases, total, summary] = await Promise.all([
    customerPurchaseRepository.findPurchaseHistory(
      customerId,
      page,
      limit,
      fromDate,
      toDate,
      status,
      invoiceType,
      search
    ),
    customerPurchaseRepository.countPurchaseHistory(
      customerId,
      fromDate,
      toDate,
      status,
      invoiceType,
      search
    ),
    customerPurchaseRepository.getPurchaseSummary(
      customerId,
      fromDate,
      toDate,
      status,
      invoiceType,
      search
    ),
  ]);

  return {
    summary,
    purchases,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
};