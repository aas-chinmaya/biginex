import NotFoundError from "../../../common/exceptions/NotFoundError";
import * as customerRepository from "../repository/customer.repository";
import * as customerLedgerRepository from "../repository/customerLedger.repository";

//GET CUSTOMER LEDGERS
export const getCustomerLedgers = async (customerId: string, page: number, limit: number): Promise<any> => {
    const customer = await customerRepository   .findById(customerId);
    if (!customer) 
        throw new NotFoundError("Customer not found.");
        const data = await customerLedgerRepository.findMany(customerId, page, limit);
    const total = await customerLedgerRepository.count(customerId);

    return { data, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } };
}

export const getCustomerOutstanding = async (customerId: string) => {
    const customer = await customerRepository.findById(customerId);
    if (!customer) throw new NotFoundError("Customer not found.");

    const balance = await customerLedgerRepository.findLastBalance(customerId);

    return { customerId, outstandingBalance: balance };
};

export const getCustomerStatement = async (customerId: string, fromDate: Date, toDate: Date) => {
    const customer = await customerRepository.findById(customerId);
    if (!customer) throw new NotFoundError("Customer not found.");

    const openingBalance = await customerLedgerRepository.findOpeningBalance(customerId, fromDate);
    const entries = await customerLedgerRepository.findStatement(customerId, fromDate, toDate);
    const closingBalance = entries.length ? Number(entries[entries.length - 1].balance) : openingBalance;

    return { customerId, fromDate, toDate, openingBalance, entries, closingBalance };
};