import { Prisma } from "@prisma/client";
import prisma from "../../../config/db";
import * as customerRepository from "../repository/customer.repository";
import { CreateCustomerRequest } from "../validators/createCustomer.validator";
import { UpdateCustomerRequest } from "../validators/updateCustomer.validator";
import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";

export const createCustomer = async (payload: CreateCustomerRequest) => {

    const existingMobile = await customerRepository.findByMobile(payload.businessId, payload.mobile);

    if (existingMobile)
        throw new ConflictError("Customer already exists with this mobile number.");

    if (payload.gstin) {
        const existingGSTIN = await customerRepository.findByGSTIN(
            payload.businessId,
            payload.gstin
        );

        if (existingGSTIN)
            throw new ConflictError("Customer already exists with this GSTIN.");
    }

    return prisma.$transaction(async (tx) => {
        const customer = await customerRepository.create(tx, {
            businessId: payload.businessId,
            branchId: payload.branchId,
            createdBy: payload.createdBy,
            customerType: payload.customerType,
            name: payload.name,
            mobile: payload.mobile,
            alternateMobile: payload.alternateMobile,
            email: payload.email,
            gstin: payload.gstin,
            pan: payload.pan,
            companyName: payload.companyName,
            creditLimit: payload.creditLimit,
            creditDays: payload.creditDays,
            openingBalance: payload.openingBalance,
            outstandingBalance: payload.openingBalance,
            rewardPoints: payload.rewardPoints,
            notes: payload.notes
        });

        for (const address of payload.addresses) {
            await customerRepository.createAddress(tx, {
                businessId: payload.businessId,
                customerId: customer.id,
                type: address.type,
                label: address.label,
                contactPerson: address.contactPerson,
                contactNumber: address.contactNumber,
                addressLine1: address.addressLine1,
                addressLine2: address.addressLine2,
                landmark: address.landmark,
                city: address.city,
                district: address.district,
                state: address.state,
                stateCode: address.stateCode,
                country: address.country,
                pincode: address.pincode,
                isDefault: address.isDefault,
                isActive: address.isActive
            });
        }
        return customerRepository.findById(customer.id);
    });
};

export const getCustomerById = async (id: string) => {

    const customer = await customerRepository.findById(id);

    if (!customer)
        throw new NotFoundError("Customer not found.");

    return customer;

};

export const getCustomers = async (businessId: string,page: number,limit: number) => {
    const customers = await customerRepository.findMany(
        businessId,
        page,
        limit
    );

    const total = await customerRepository.count(
        businessId
    );

    return {
        data: customers,
        pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit)
        }
    };
};

export const updateCustomer = async (id: string, payload: UpdateCustomerRequest) => {

    const existingCustomer = await customerRepository.findById(id);
    if (!existingCustomer)
        throw new NotFoundError("Customer not found.");

    if (payload.mobile && payload.mobile !== existingCustomer.mobile) {

        const duplicate = await customerRepository.findByMobile(existingCustomer.businessId, payload.mobile);
        if (duplicate && duplicate.id !== id)
            throw new ConflictError("Customer already exists with this mobile number.");
    }

    if (payload.gstin && payload.gstin !== existingCustomer.gstin) {
        const duplicate = await customerRepository.findByGSTIN(existingCustomer.businessId, payload.gstin);
        if (duplicate && duplicate.id !== id)
            throw new ConflictError("Customer already exists with this GSTIN.");
    }

    return prisma.$transaction(async (tx) => {
        await customerRepository.update(tx, id, {
            updatedBy: payload.updatedBy,
            customerType: payload.customerType,
            name: payload.name,
            mobile: payload.mobile,
            alternateMobile: payload.alternateMobile,
            email: payload.email,
            gstin: payload.gstin,
            pan: payload.pan,
            companyName: payload.companyName,
            creditLimit: payload.creditLimit,
            creditDays: payload.creditDays,
            openingBalance: payload.openingBalance,
            outstandingBalance: payload.outstandingBalance,
            rewardPoints: payload.rewardPoints,
            isActive: payload.isActive,
            notes: payload.notes
        });

        if (payload.addresses) {

            const dbAddresses = await customerRepository.getAddresses(id);
            const payloadIds = payload.addresses.filter(a => a.id).map(a => a.id!);
            for (const dbAddress of dbAddresses) {
                if (!payloadIds.includes(dbAddress.id))
                    await customerRepository.deleteAddress(tx, dbAddress.id);

            }

            for (const address of payload.addresses) {
                if (address.id) {
                    await customerRepository.updateAddress(tx, address.id, {
                        type: address.type,
                        label: address.label,
                        contactPerson: address.contactPerson,
                        contactNumber: address.contactNumber,
                        addressLine1: address.addressLine1,
                        addressLine2: address.addressLine2,
                        landmark: address.landmark,
                        city: address.city,
                        district: address.district,
                        state: address.state,
                        stateCode: address.stateCode,
                        country: address.country,
                        pincode: address.pincode,
                        isDefault: address.isDefault,
                        isActive: address.isActive
                    });
                } else {
                    await customerRepository.createAddress(tx, {
                        businessId: existingCustomer.businessId,
                        customerId: id,
                        type: address.type,
                        label: address.label,
                        contactPerson: address.contactPerson,
                        contactNumber: address.contactNumber,
                        addressLine1: address.addressLine1,
                        addressLine2: address.addressLine2,
                        landmark: address.landmark,
                        city: address.city,
                        district: address.district,
                        state: address.state,
                        stateCode: address.stateCode,
                        country: address.country,
                        pincode: address.pincode,
                        isDefault: address.isDefault,
                        isActive: address.isActive
                    });
                }
            }
        }
        return customerRepository.findByIdTx(tx, id);
    });
};

export const deleteCustomer = async (id: string) => {

    const customer = await customerRepository.findById(id);
    if (!customer)
        throw new NotFoundError("Customer not found.");

    return prisma.$transaction(async (tx) => customerRepository.remove(tx, id));
};