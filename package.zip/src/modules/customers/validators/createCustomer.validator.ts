import { z } from "zod";
import { AddressType, CustomerType } from "@prisma/client";

const addressSchema = z.object({
    type: z.nativeEnum(AddressType),
    label: z.string().trim().optional(),
    contactPerson: z.string().trim().optional(),
    contactNumber: z.string().trim().optional(),

    addressLine1: z.string().trim().min(1, "Address Line 1 is required."),
    addressLine2: z.string().trim().optional(),
    landmark: z.string().trim().optional(),

    city: z.string().trim().min(1, "City is required."),
    district: z.string().trim().optional(),
    state: z.string().trim().min(1, "State is required."),
    stateCode: z.string().trim().optional(),
    country: z.string().trim().default("India"),
    pincode: z.string().trim().min(6).max(6),

    isDefault: z.boolean().default(false),
    isActive: z.boolean().default(true)
});

export const createCustomerSchema = z.object({

    businessId: z.string().cuid(),
    branchId: z.string().cuid().optional(),
    createdBy: z.string().cuid(),
    customerType: z.nativeEnum(CustomerType).default(CustomerType.WALK_IN),
    name: z.string().trim().min(1, "Customer name is required."),
    mobile: z.string().trim().regex(/^[6-9]\d{9}$/, "Invalid mobile number."),
    alternateMobile: z.string().trim().optional(),
    email: z.string().trim().email().optional(),
    gstin: z.string().trim().optional(),
    pan: z.string().trim().optional(),
    companyName: z.string().trim().optional(),
    creditLimit: z.coerce.number().default(0),
    creditDays: z.coerce.number().default(0),
    openingBalance: z.coerce.number().default(0),
    rewardPoints: z.coerce.number().default(0),
    notes: z.string().trim().optional(),
    addresses: z.array(addressSchema).min(1, "At least one address is required.")
});

export type CreateCustomerRequest = z.infer<typeof createCustomerSchema>;