import prisma from "../../../config/db";
import { CustomerLedger, Prisma } from "@prisma/client";

export const create = async (tx: Prisma.TransactionClient, data: Prisma.CustomerLedgerCreateInput): Promise<CustomerLedger> => {
    return tx.customerLedger.create({ data });
};

export const findLastBalance = async (customerId: string): Promise<number> => {

    const ledger = await prisma.customerLedger.findFirst({
        where: { customerId },
        orderBy: [
            { transactionDate: "desc" },
            { createdAt: "desc" }
        ],
        select: { balance: true }
    });

    return Number(ledger?.balance ?? 0);

};

export const findMany = async (customerId: string,page: number,limit: number): Promise<CustomerLedger[]> => {

    const skip = (page - 1) * limit;

    return prisma.customerLedger.findMany({
        where: { customerId },
        orderBy: [
            { transactionDate: "desc" },
            { createdAt: "desc" }
        ],
        skip,
        take: limit
    });

};

export const count = async (customerId: string): Promise<number> => {

    return prisma.customerLedger.count({
        where: { customerId }
    });

};

// export const findStatement = async (customerId: string, fromDate: Date, toDate: Date) => prisma.customerLedger.findMany({ where: { customerId, transactionDate: { gte: fromDate, lte: toDate } }, orderBy: { transactionDate: "asc" } });

export const findStatement = async (customerId: string, fromDate: Date, toDate: Date) => {
  return await prisma.customerLedger.findMany({
    where: {
      customerId,
      transactionDate: {
        gte: fromDate,
        lte: toDate,
      },
    },
    orderBy: {
      transactionDate: "asc",
    },
  });
};

export const findOpeningBalance = async (customerId: string, fromDate: Date) => {
    const entry = await prisma.customerLedger.findFirst({ where: { customerId, transactionDate: { lt: fromDate } }, orderBy: { transactionDate: "desc" }, select: { balance: true } });
    return Number(entry?.balance ?? 0);
};