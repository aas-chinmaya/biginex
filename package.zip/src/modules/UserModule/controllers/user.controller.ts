import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import { AuthRequest } from "../../../middleware/auth.middleware";
import * as service from "../services/user.service";

export const registerUser = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.registerUserService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.user,
  });
});

export const getAllUsers = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getAllUsersService(req.query);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.users,
    total: result.total,
    page: result.page,
    limit: result.limit,
    totalPages: result.totalPages,
  });
});

export const updateUser = asyncHandler(async (req: Request, res: Response) => {
  const userId = String(req.params.id);
  const result = await service.updateUserService(userId, req.body);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.user,
  });
});

export const deleteUser = asyncHandler(async (req: Request, res: Response) => {
  const userId = String(req.params.id);
  const result = await service.deleteUserService(userId);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.user,
  });
});

export const loginUser = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;
  const result = await service.loginUserService(email, password);

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});

export const verifyLoginOtp = asyncHandler(async (req: Request, res: Response) => {
  const { email, otp } = req.body;
  const result = await service.verifyLoginOtpService(email, otp, req);

  res.cookie("accessToken", result.accessToken, {
    httpOnly: true,
    secure: false,
    sameSite: "lax",
    maxAge: 15 * 60 * 1000,
  });

  res.cookie("refreshToken", result.refreshToken, {
    httpOnly: true,
    secure: false,
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.user,
  });
});

export const getLoggedInUser = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized",
    });
  }

  const result = await service.getLoggedInUserService(req.user.id);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.user,
  });
});

export const checkAuth = asyncHandler(async (req: AuthRequest, res: Response) => {
  const result = await service.checkAuthService(req.user?.id);

  if (!result.isAuthenticated) {
    return res.status(result.status).json({
      success: false,
      isAuthenticated: false,
    });
  }

  return res.status(200).json({
    success: true,
    isAuthenticated: true,
    data: result.user,
  });
});

export const forgotPassword = asyncHandler(async (req: Request, res: Response) => {
  const { email } = req.body;
  const result = await service.forgotPasswordService(email);

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});

export const verifyForgotPasswordOtp = asyncHandler(async (req: Request, res: Response) => {
  const { email, otp, newPassword } = req.body;
  const result = await service.verifyForgotPasswordOtpService(email, otp, newPassword);

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});

export const changePassword = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  const result = await service.changePasswordService(req.user?.id as string, currentPassword, newPassword);

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});

export const logoutCurrentDevice = asyncHandler(async (req: Request, res: Response) => {
  const refreshToken = req.cookies.refreshToken;
  const result = await service.logoutCurrentDeviceService(refreshToken);

  res.clearCookie("accessToken");
  res.clearCookie("refreshToken");

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});

export const logoutAllDevices = asyncHandler(async (req: AuthRequest, res: Response) => {
  const result = await service.logoutAllDevicesService(req.user?.id);

  res.clearCookie("accessToken");
  res.clearCookie("refreshToken");

  return res.status(200).json({
    success: true,
    message: result.message,
  });
});

export const getActiveDevices = asyncHandler(async (req: AuthRequest, res: Response) => {
  const userId = req.user?.id;
  const result = await service.getActiveDevicesService(userId);

  return res.status(200).json({
    success: true,
    data: result.devices,
  });
});