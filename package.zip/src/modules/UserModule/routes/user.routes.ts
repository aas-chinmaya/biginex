import { Router } from "express";
import { getAllUsers, registerUser, updateUser, deleteUser, loginUser , verifyLoginOtp, getLoggedInUser, checkAuth, forgotPassword, verifyForgotPasswordOtp, changePassword, logoutCurrentDevice,logoutAllDevices, getActiveDevices } from "../controllers/user.controller";
import { isAuthenticated } from "../../../middleware/auth.middleware";
const router = Router();

router.post("/register", registerUser);
router.get("/users",  getAllUsers);
router.get("/profile", isAuthenticated, getLoggedInUser);
router.post("/login", loginUser);
router.put("/updateUser/:id", updateUser); 
router.delete("/deleteUser/:id", deleteUser);               
router.post("/verify-otp", verifyLoginOtp);
router.get("/check-auth", isAuthenticated, checkAuth);
router.post("/forgot-password", forgotPassword);
router.post("/verify-forgot-password-otp", verifyForgotPasswordOtp);
router.post("/change-password", isAuthenticated, changePassword);
router.post("/logout", isAuthenticated, logoutCurrentDevice);
router.post("/logout-all", isAuthenticated, logoutAllDevices);

export default router;