import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class SubCategoryRepository {

    async create(data: Prisma.ProductSubCategoryCreateInput) {
        return prisma.productSubCategory.create({
            data,
            include: {
                category: {
                    select: {
                        id: true,
                        categoryName: true,
                    },
                },
            },
        });
    }

    async findById(id: string) {
        return prisma.productSubCategory.findFirst({
            where: {
                id,
                deletedAt: null,
            },
            include: {
                category: {
                    select: {
                        id: true,
                        categoryName: true,
                    },
                },
            },
        });
    }

    async findByName(categoryId: string, subCategoryName: string) {
        return prisma.productSubCategory.findFirst({
            where: {
                categoryId,
                subCategoryName,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.ProductSubCategoryWhereInput = {
            deletedAt: null,

            ...(search && {
                subCategoryName: {
                    contains: search,
                    mode: "insensitive",
                },
            }),

            ...(status !== undefined && {
                status,
            }),
        };

        const [subCategories, total] = await prisma.$transaction([

            prisma.productSubCategory.findMany({

                where,

                skip,

                take: limit,

                include: {
                    category: {
                        select: {
                            id: true,
                            categoryName: true,
                        },
                    },
                },

                orderBy: {
                    createdAt: "desc",
                },
            }),

            prisma.productSubCategory.count({
                where,
            }),
        ]);

        return {
            data: subCategories,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
        };
    }

    async update(
        id: string,
        data: Prisma.ProductSubCategoryUpdateInput
    ) {

        return prisma.productSubCategory.update({
            where: {
                id,
            },
            data,
            include: {
                category: {
                    select: {
                        id: true,
                        categoryName: true,
                    },
                },
            },
        });
    }

    async softDelete(id: string) {
        return prisma.productSubCategory.update({
            where: {
                id,
            },
            data: {
                deletedAt: new Date(),
                status: false,
            },
        });
    }

    async restore(id: string) {
        return prisma.productSubCategory.update({
            where: {
                id,
            },
            data: {
                deletedAt: null,
                status: true,
            },
        });
    }

    async getByCategoryId(categoryId: string) {
        return prisma.productSubCategory.findMany({
            where: {
                categoryId,
                deletedAt: null,
                status: true,
            },
            orderBy: {
                subCategoryName: "asc",
            },
        });
    }

}

export default new SubCategoryRepository();