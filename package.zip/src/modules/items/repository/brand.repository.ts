import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class BrandRepository {

    async create(data: Prisma.BrandCreateInput) {
        return prisma.brand.create({
            data,
        });
    }

    async findById(id: string) {
        return prisma.brand.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findByName(brandName: string) {
        return prisma.brand.findFirst({
            where: {
                brandName,
                deletedAt: null,
            },
        });
    }

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.BrandWhereInput = {

            deletedAt: null,

            ...(search && {
                brandName: {
                    contains: search,
                    mode: "insensitive",
                },
            }),

            ...(status !== undefined && {
                status,
            }),

        };

        const [brands, total] = await prisma.$transaction([

            prisma.brand.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    createdAt: "desc",
                },

            }),

            prisma.brand.count({
                where,
            }),

        ]);

        return {

            data: brands,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),

        };
    }

    async update(
        id: string,
        data: Prisma.BrandUpdateInput
    ) {

        return prisma.brand.update({

            where: {
                id,
            },

            data,

        });

    }

    async softDelete(id: string) {

        return prisma.brand.update({

            where: {
                id,
            },

            data: {
                deletedAt: new Date(),
                status: false,
            },

        });

    }

    async restore(id: string) {

        return prisma.brand.update({

            where: {
                id,
            },

            data: {
                deletedAt: null,
                status: true,
            },

        });

    }

}

export default new BrandRepository();