import prisma from "../../../config/db";
import { Prisma } from "@prisma/client";

class ProductRepository {

    async create(data: Prisma.ProductCreateInput) {
        return prisma.product.create({
            data,
            include: {
                category: true,
                subCategory: true,
                brand: true,
                inventoryUnit: true,
                tax: true,
                variantType: true,
                variantValue: true,
            },
        });
    }

    async findById(id: string) {
        return prisma.product.findFirst({
            where: {
                id,
                deletedAt: null,
            },
            include: {
                category: true,
                subCategory: true,
                brand: true,
                inventoryUnit: true,
                tax: true,
                productUnits: true,
                variantType: true,
                variantValue: true,
            },
        });
    }

    async findByItemCode(itemCode: string) {
        return prisma.product.findFirst({
            where: {
                itemCode,
                deletedAt: null,
            },
        });
    }

    async findByItemName(itemName: string) {
        return prisma.product.findFirst({
            where: {
                itemName,
                deletedAt: null,
            },
        });
    }

    async findCategory(id: string) {
        return prisma.category.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

//     async findCategory(id: number) {

//     console.log("Searching Category ID:", id);

//     const allCategories = await prisma.category.findMany();

//     console.log("All Categories:", allCategories);

//     const category = await prisma.category.findFirst({
//         where: {
//             id,
//             deletedAt: null,
//         },
//     });

//     console.log("Found Category:", category);

//     return category;
// }

    async findSubCategory(id: string) {
        return prisma.subCategory.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findBrand(id: string) {
        return prisma.brand.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findInventoryUnit(id: string) {
        return prisma.unit.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findTax(id: string) {
        return prisma.tax.findFirst({
            where: {
                id,
                deletedAt: null,
            },
        });
    }

    async findByBarcode(barcode: string) {
    return prisma.product.findFirst({
        where: {
            barcode,
            deletedAt: null,
        },
      });
    }

    async findVariantType(id: string) {
    return prisma.variantType.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
}

async findVariantValue(id: string) {
    return prisma.variantValue.findFirst({
        where: {
            id,
            deletedAt: null,
        },
    });
}

    async getAll(
        page: number,
        limit: number,
        search?: string,
        status?: boolean
    ) {

        const skip = (page - 1) * limit;

        const where: Prisma.ProductWhereInput = {

            deletedAt: null,

            ...(status !== undefined && {
                status,
            }),

            ...(search && {

                OR: [

                    {
                        itemCode: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },

                    {
                        itemName: {
                            contains: search,
                            mode: "insensitive",
                        },
                    },

                ],

            }),

        };

        const [products, total] = await prisma.$transaction([

            prisma.product.findMany({

                where,

                skip,

                take: limit,

                orderBy: {
                    createdAt: "desc",
                },

                include: {
                    category: true,
                    subCategory: true,
                    brand: true,
                    inventoryUnit: true,
                    tax: true,
                    variantType: true,
                    variantValue: true,
                },

            }),

            prisma.product.count({
                where,
            }),

        ]);

        return {

            data: products,

            total,

            page,

            limit,

            totalPages: Math.ceil(total / limit),

        };

    }

    async update(
        id: string,
        data: Prisma.ProductUpdateInput
    ) {

        return prisma.product.update({

            where: {
                id,
            },

            data,

            include: {
                category: true,
                subCategory: true,
                brand: true,
                inventoryUnit: true,
                tax: true,
                variantType: true,
                variantValue: true,
            },

        });

    }

    async softDelete(id: string) {

        return prisma.product.update({

            where: {
                id,
            },

            data: {

                deletedAt: new Date(),

                status: false,

            },

        });

    }

    async restore(id: string) {

        return prisma.product.update({

            where: {
                id,
            },

            data: {

                deletedAt: null,

                status: true,

            },

        });

    }

}

export default new ProductRepository();