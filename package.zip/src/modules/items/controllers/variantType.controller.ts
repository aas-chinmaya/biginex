import { Request, Response, NextFunction } from "express";
import variantTypeService from "../services/variantType.service";

class VariantTypeController {

    async createVariantType(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantType = await variantTypeService.createVariantType(req.body);

            return res.status(201).json({
                success: true,
                message: "Variant Type created successfully.",
                data: variantType,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllVariantTypes(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const variantTypes = await variantTypeService.getAllVariantTypes(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

            return res.status(200).json({
                success: true,
                message: "Variant Types fetched successfully.",
                data: variantTypes,
            });

        } catch (error) {
            next(error);
        }
    }

    async getVariantTypeById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantType = await variantTypeService.getVariantTypeById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Variant Type fetched successfully.",
                data: variantType,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateVariantType(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantType = await variantTypeService.updateVariantType(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Variant Type updated successfully.",
                data: variantType,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteVariantType(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await variantTypeService.deleteVariantType(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Variant Type deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreVariantType(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const variantType = await variantTypeService.restoreVariantType(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Variant Type restored successfully.",
                data: variantType,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new VariantTypeController();
