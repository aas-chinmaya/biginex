import { Request, Response, NextFunction } from "express";
import categoryService from "../services/category.service";

class CategoryController {

    async createCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const category = await categoryService.createCategory(req.body);

            return res.status(201).json({
                success: true,
                message: "Category created successfully",
                data: category,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllCategories(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const categories = await categoryService.getAllCategories(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined ? status === "true" : undefined
            );

            return res.status(200).json({
                success: true,
                message: "Categories fetched successfully",
                data: categories,
            });

        } catch (error) {
            next(error);
        }
    }

    async getCategoryById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const category = await categoryService.getCategoryById(req.params.id as string);

            return res.status(200).json({
                success: true,
                message: "Category fetched successfully",
                data: category,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const category = await categoryService.updateCategory(req.params.id as string, req.body);

            return res.status(200).json({
                success: true,
                message: "Category updated successfully",
                data: category,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await categoryService.deleteCategory(req.params.id as string);

            return res.status(200).json({
                success: true,
                message: "Category deleted successfully",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreCategory(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const category = await categoryService.restoreCategory(req.params.id as string);

            return res.status(200).json({
                success: true,
                message: "Category restored successfully",
                data: category,
            });

        } catch (error) {
            next(error);
        }
    }
}

export default new CategoryController();