import { Request, Response, NextFunction } from "express";
import taxService from "../services/tax.service";

class TaxController {

    async createTax(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const tax = await taxService.createTax(req.body);

            return res.status(201).json({
                success: true,
                message: "Tax created successfully.",
                data: tax,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllTaxes(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const taxes = await taxService.getAllTaxes(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

            return res.status(200).json({
                success: true,
                message: "Taxes fetched successfully.",
                data: taxes,
            });

        } catch (error) {
            next(error);
        }
    }

    async getTaxById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const tax = await taxService.getTaxById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Tax fetched successfully.",
                data: tax,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateTax(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const tax = await taxService.updateTax(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Tax updated successfully.",
                data: tax,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteTax(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await taxService.deleteTax(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Tax deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreTax(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const tax = await taxService.restoreTax(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Tax restored successfully.",
                data: tax,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new TaxController();