import { Request, Response, NextFunction } from "express";
import productService from "../services/product.service";

class ProductController {

  async createProduct(
     req: Request,
     res: Response,
     next: NextFunction
  ) {

    try {

        const payload = {

            ...req.body,

            image: req.file
                ? `/uploads/${req.file.filename}`
                : undefined,

        };

        const product =
            await productService.createProduct(payload);

        return res.status(201).json({

            success: true,

            message: "Product created successfully.",

            data: product,

        });

    } catch (error) {

        next(error);

    }

}

    async getAllProducts(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const products =
                await productService.getAllProducts(
                    Number(page),
                    Number(limit),
                    search as string,
                    status !== undefined
                        ? status === "true"
                        : undefined
                );

            return res.status(200).json({
                success: true,
                message: "Products fetched successfully.",
                data: products,
            });

        } catch (error) {
            next(error);
        }
    }

    async getProductById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const product =
                await productService.getProductById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Product fetched successfully.",
                data: product,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateProduct(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const product =
                await productService.updateProduct(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Product updated successfully.",
                data: product,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteProduct(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await productService.deleteProduct(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Product deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreProduct(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const product =
                await productService.restoreProduct(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Product restored successfully.",
                data: product,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new ProductController();