import { Request, Response, NextFunction } from "express";
import unitService from "../services/unit.service";

class UnitController {

    async createUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const unit = await unitService.createUnit(req.body);

            return res.status(201).json({
                success: true,
                message: "Unit created successfully.",
                data: unit,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllUnits(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const units = await unitService.getAllUnits(
                Number(page),
                Number(limit),
                search as string,
                status !== undefined
                    ? status === "true"
                    : undefined
            );

            return res.status(200).json({
                success: true,
                message: "Units fetched successfully.",
                data: units,
            });

        } catch (error) {
            next(error);
        }
    }

    async getUnitById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const unit = await unitService.getUnitById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Unit fetched successfully.",
                data: unit,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const unit = await unitService.updateUnit(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Unit updated successfully.",
                data: unit,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await unitService.deleteUnit(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Unit deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const unit = await unitService.restoreUnit(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Unit restored successfully.",
                data: unit,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new UnitController();