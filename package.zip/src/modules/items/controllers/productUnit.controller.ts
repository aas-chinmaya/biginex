import { Request, Response, NextFunction } from "express";
import productUnitService from "../services/productUnit.service";

class ProductUnitController {

    async createProductUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const productUnit =
                await productUnitService.createProductUnit(req.body);

            return res.status(201).json({
                success: true,
                message: "Product Unit created successfully.",
                data: productUnit,
            });

        } catch (error) {
            next(error);
        }
    }

    async getAllProductUnits(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const {
                page = "1",
                limit = "10",
                search,
                status,
            } = req.query;

            const productUnits =
                await productUnitService.getAllProductUnits(
                    Number(page),
                    Number(limit),
                    search as string,
                    status !== undefined
                        ? status === "true"
                        : undefined
                );

            return res.status(200).json({
                success: true,
                message: "Product Units fetched successfully.",
                data: productUnits,
            });

        } catch (error) {
            next(error);
        }
    }

    async getProductUnitById(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const productUnit =
                await productUnitService.getProductUnitById(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Product Unit fetched successfully.",
                data: productUnit,
            });

        } catch (error) {
            next(error);
        }
    }

    async updateProductUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const productUnit =
                await productUnitService.updateProductUnit(req.params.id, req.body);

            return res.status(200).json({
                success: true,
                message: "Product Unit updated successfully.",
                data: productUnit,
            });

        } catch (error) {
            next(error);
        }
    }

    async deleteProductUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            await productUnitService.deleteProductUnit(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Product Unit deleted successfully.",
            });

        } catch (error) {
            next(error);
        }
    }

    async restoreProductUnit(
        req: Request,
        res: Response,
        next: NextFunction
    ) {
        try {

            const productUnit =
                await productUnitService.restoreProductUnit(req.params.id);

            return res.status(200).json({
                success: true,
                message: "Product Unit restored successfully.",
                data: productUnit,
            });

        } catch (error) {
            next(error);
        }
    }

}

export default new ProductUnitController();