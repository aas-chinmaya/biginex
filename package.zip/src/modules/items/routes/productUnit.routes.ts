import { Router } from "express";
import productUnitController from "../controllers/productUnit.controller";

const router = Router();

/**
 * Create Product Unit
 */
router.post(
    "/create",
    productUnitController.createProductUnit
);

/**
 * Get All Product Units
 */
router.get(
    "/getall",
    productUnitController.getAllProductUnits
);

/**
 * Get Product Unit By Id
 */
router.get(
    "/getbyid/:id",
    productUnitController.getProductUnitById
);

/**
 * Update Product Unit
 */
router.put(
    "/update/:id",
    productUnitController.updateProductUnit
);

/**
 * Soft Delete Product Unit
 */
router.delete(
    "/delete/:id",
    productUnitController.deleteProductUnit
);

/**
 * Restore Product Unit
 */
router.patch(
    "/restore/:id",
    productUnitController.restoreProductUnit
);

export default router;