import { Router } from "express";
import variantValueController from "../controllers/variantValue.controller";

const router = Router();

/**
 * Create Variant Value
 */
router.post(
    "/create",
    variantValueController.createVariantValue
);

/**
 * Get All Variant Values
 */
router.get(
    "/getall",
    variantValueController.getAllVariantValues
);

/**
 * Get Variant Value By Id
 */
router.get(
    "/getbyid/:id",
    variantValueController.getVariantValueById
);

/**
 * Update Variant Value
 */
router.put(
    "/update/:id",
    variantValueController.updateVariantValue
);

/**
 * Soft Delete Variant Value
 */
router.delete(
    "/delete/:id",
    variantValueController.deleteVariantValue
);

/**
 * Restore Variant Value
 */
router.patch(
    "/restore/:id",
    variantValueController.restoreVariantValue
);

export default router;