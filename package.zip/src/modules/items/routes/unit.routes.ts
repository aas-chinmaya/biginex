import { Router } from "express";
import unitController from "../controllers/unit.controller";

const router = Router();

/**
 * Create Unit
 * POST /api/units
 */
router.post(
    "/create",
    unitController.createUnit
);

/**
 * Get All Units
 * GET /api/units?page=1&limit=10&search=&status=true
 */
router.get(
    "/getall",
    unitController.getAllUnits
);

/**
 * Get Unit By Id
 * GET /api/units/:id
 */
router.get(
    "/getby/:id",
    unitController.getUnitById
);

/**
 * Update Unit
 * PUT /api/units/:id
 */
router.put(
    "/update/:id",
    unitController.updateUnit
);

/**
 * Soft Delete Unit
 * DELETE /api/units/:id
 */
router.delete(
    "/delete/:id",
    unitController.deleteUnit
);

/**
 * Restore Unit
 * PATCH /api/units/:id/restore
 */
router.patch(
    "/restore/:id",
    unitController.restoreUnit
);

export default router;