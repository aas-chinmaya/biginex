import unitRepository from "../repository/unit.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateUnitDto {
    unitName: string;
    shortName: string;
    unitType:
        | "WEIGHT"
        | "LENGTH"
        | "VOLUME"
        | "COUNT"
        | "AREA"
        | "TIME"
        | "PACKAGING"
        | "CUSTOM";
    description?: string;
    status?: boolean;
}

interface UpdateUnitDto {
    unitName?: string;
    shortName?: string;
    unitType?:
        | "WEIGHT"
        | "LENGTH"
        | "VOLUME"
        | "COUNT"
        | "AREA"
        | "TIME"
        | "PACKAGING"
        | "CUSTOM";
    description?: string;
    status?: boolean;
}

class UnitService {

    async createUnit(payload: CreateUnitDto) {

        const {
            unitName,
            shortName,
            unitType,
            description,
            status = true,
        } = payload;

        if (!unitName?.trim()) {
            throw new ValidationError("Unit name is required.");
        }

        if (!shortName?.trim()) {
            throw new ValidationError("Short name is required.");
        }

        if (!unitType) {
            throw new ValidationError("Unit type is required.");
        }

        const existingName = await unitRepository.findByName(
            unitName.trim()
        );

        if (existingName) {
            throw new ValidationError("Unit name already exists.");
        }

        const existingShortName =
            await unitRepository.findByShortName(
                shortName.trim()
            );

        if (existingShortName) {
            throw new ValidationError("Short name already exists.");
        }

        return await unitRepository.create({
            unitName: unitName.trim(),
            shortName: shortName.trim(),
            unitType,
            description,
            status,
        });
    }

    async getAllUnits(
        page = 1,
        limit = 10,
        search?: string,
        status?: boolean
    ) {

        page = Number(page);
        limit = Number(limit);

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;

        return await unitRepository.getAll(
            page,
            limit,
            search,
            status
        );
    }

    async getUnitById(id: string) {

        const unit = await unitRepository.findById(id);

        if (!unit) {
            throw new ValidationError("Unit not found.");
        }

        return unit;
    }

    async updateUnit(
        id: string,
        payload: UpdateUnitDto
    ) {

        const unit = await unitRepository.findById(id);

        if (!unit) {
            throw new ValidationError("Unit not found.");
        }

        if (payload.unitName) {

            const existingName =
                await unitRepository.findByName(
                    payload.unitName.trim()
                );

            if (
                existingName &&
                existingName.id !== id
            ) {
                throw new ValidationError(
                    "Unit name already exists."
                );
            }
        }

        if (payload.shortName) {

            const existingShortName =
                await unitRepository.findByShortName(
                    payload.shortName.trim()
                );

            if (
                existingShortName &&
                existingShortName.id !== id
            ) {
                throw new ValidationError(
                    "Short name already exists."
                );
            }
        }

        return await unitRepository.update(id, {

            unitName: payload.unitName?.trim(),

            shortName: payload.shortName?.trim(),

            unitType: payload.unitType,

            description: payload.description,

            status: payload.status,

        });

    }

    async deleteUnit(id: string) {

        const unit = await unitRepository.findById(id);

        if (!unit) {
            throw new ValidationError("Unit not found.");
        }

        return await unitRepository.softDelete(id);
    }

    async restoreUnit(id: string) {

        const unit = await unitRepository.findById(id);

        if (unit) {
            throw new ValidationError("Unit is already active.");
        }

        return await unitRepository.restore(id);
    }

}

export default new UnitService();