import variantValueRepository from "../repository/variantValue.repository";
import ValidationError from "../../../common/exceptions/ValidationError";

interface CreateVariantValueDto {
    variantTypeId: string;
    value: string;
    shortName?: string;
    displayOrder?: number;
    status?: boolean;
}

interface UpdateVariantValueDto {
    variantTypeId?: string;
    value?: string;
    shortName?: string;
    displayOrder?: number;
    status?: boolean;
}

class VariantValueService {

    async createVariantValue(payload: CreateVariantValueDto) {

        const {
            variantTypeId,
            value,
            shortName,
            displayOrder,
            status = true,
        } = payload;

        if (!variantTypeId) {
            throw new ValidationError("Variant Type is required.");
        }

        if (!value?.trim()) {
            throw new ValidationError("Variant Value is required.");
        }

        // Validate Variant Type
        const variantType =
            await variantValueRepository.findVariantType(
                variantTypeId
            );

        if (!variantType) {
            throw new ValidationError("Variant Type not found.");
        }

        // Duplicate Check
        const existing =
            await variantValueRepository.findByValue(
                variantTypeId,
                value.trim()
            );

        if (existing) {
            throw new ValidationError(
                "Variant Value already exists for this Variant Type."
            );
        }

        return await variantValueRepository.create({

            value: value.trim(),

            shortName: shortName?.trim(),

            displayOrder,

            status,

            variantType: {
                connect: {
                    id: variantTypeId,
                },
            },

        });

    }

    async getAllVariantValues(
        page = 1,
        limit = 10,
        search?: string,
        status?: boolean
    ) {

        page = Number(page);
        limit = Number(limit);

        if (page < 1) page = 1;
        if (limit < 1) limit = 10;

        return await variantValueRepository.getAll(
            page,
            limit,
            search,
            status
        );

    }

    async getVariantValueById(id: string) {

        const variantValue =
            await variantValueRepository.findById(id);

        if (!variantValue) {
            throw new ValidationError(
                "Variant Value not found."
            );
        }

        return variantValue;

    }

    async updateVariantValue(
        id: string,
        payload: UpdateVariantValueDto
    ) {

        const variantValue =
            await variantValueRepository.findById(id);

        if (!variantValue) {
            throw new ValidationError(
                "Variant Value not found."
            );
        }

        const variantTypeId =
            payload.variantTypeId ??
            variantValue.variantTypeId;

        if (payload.variantTypeId) {

            const variantType =
                await variantValueRepository.findVariantType(
                    payload.variantTypeId
                );

            if (!variantType) {
                throw new ValidationError(
                    "Variant Type not found."
                );
            }

        }

        if (payload.value) {

            const existing =
                await variantValueRepository.findByValue(
                    variantTypeId,
                    payload.value.trim()
                );

            if (
                existing &&
                existing.id !== id
            ) {
                throw new ValidationError(
                    "Variant Value already exists."
                );
            }

        }

        return await variantValueRepository.update(
            id,
            {

                value: payload.value?.trim(),

                shortName: payload.shortName?.trim(),

                displayOrder: payload.displayOrder,

                status: payload.status,

                ...(payload.variantTypeId && {

                    variantType: {
                        connect: {
                            id: payload.variantTypeId,
                        },
                    },

                }),

            }
        );

    }

    async deleteVariantValue(id: string) {

        const variantValue =
            await variantValueRepository.findById(id);

        if (!variantValue) {
            throw new ValidationError(
                "Variant Value not found."
            );
        }

        return await variantValueRepository.softDelete(
            id
        );

    }

    async restoreVariantValue(id: string) {

        const variantValue =
            await variantValueRepository.findById(id);

        if (variantValue) {
            throw new ValidationError(
                "Variant Value is already active."
            );
        }

        return await variantValueRepository.restore(
            id
        );

    }

}

export default new VariantValueService();