import { Router } from "express";
import * as controller from "../controllers/business.controller";


import  uploadFactory  from "../../../middleware/multer.middleware";
import  { compressorMiddleware } from "../../../middleware/compressor.middleware";

const router = Router();
const upload = uploadFactory("business");
// Create Business

router.post("/createBusiness", upload.fields([{ name: "businessLogo", maxCount: 1 }]), compressorMiddleware, controller.createBusiness);

// Get All Businesses
router.get("/getAllBusinesses", controller.getBusinesses);

// Get Business By Id
router.get("/getBusinessById/:id", controller.getBusinessById);

// Update Business
router.put("/updateBusiness/:id", upload.fields([{ name: "businessLogo", maxCount: 1 }]), compressorMiddleware, controller.updateBusiness);

// Delete Business
router.delete("/deleteBusiness/:id", controller.deleteBusiness);

export default router;