import { Router } from "express";
import * as controller from "../controllers/businessDocument.controller";

import  uploadFactory  from "../../../middleware/multer.middleware";
import  { compressorMiddleware } from "../../../middleware/compressor.middleware";

const router = Router();

const upload = uploadFactory("business");


router.post(
  "/createDocument",
  upload.fields([
    {
      name: "businessDocument",
      maxCount: 10,
    }
  ]),

  compressorMiddleware,
  controller.createDocument
);


// router.get(
//   "/getAllDocuments",
//   controller.getAllDocuments
// );


// router.get(
//   "/getDocumentsByBusiness/:businessId",
//   controller.getDocumentsByBusiness
// );


router.get(
  "/getDocumentsByBranch/:branchId",
  controller.getDocumentsByBranch
);


router.get(
  "/getDocumentById/:id",
  controller.getDocumentById
);


router.put(
  "/updateDocument/:id",
  upload.fields([
    {
      name: "businessDocument",
      maxCount: 10,
    }
  ]),
  compressorMiddleware,
  controller.updateDocument
);


// router.patch(
//   "/verify/:id",
//   controller.verifyDocument
// );


router.delete(
  "/delete/:id",
  controller.deleteDocument
);


// router.patch(
//   "/restore/:id",
//   controller.restoreDocument
// );

export default router;