import { Router } from "express";
import * as controller from "../controllers/businessBank.controller";

const router = Router();

/**
 * Create Bank
 */
router.post("/", controller.createBank);

/**
 * Get All Banks of Business
 */
router.get(
  "/business/:businessId",
  controller.getBanks
);

/**
 * Get Bank By ID
 */
router.get("/:id", controller.getBankById);

/**
 * Update Bank
 */
router.put("/:id", controller.updateBank);

/**
 * Delete Bank
 */
router.delete("/:id", controller.deleteBank);

export default router;