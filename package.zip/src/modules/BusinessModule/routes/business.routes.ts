import { Router } from "express";
import * as controller from "../controllers/business.controller";

const router = Router();

// Create Business
router.post("/", controller.createBusiness);

// Get All Businesses
router.get("/", controller.getBusinesses);

// Get Business By Id
router.get("/:id", controller.getBusinessById);

// Update Business
router.put("/:id", controller.updateBusiness);

// Delete Business
router.delete("/:id", controller.deleteBusiness);

export default router;