import { Router } from "express";
import * as controller from "../controllers/businessAddress.controller";

const router = Router();

// Create Address
router.post("/", controller.createAddress);

// Get All Addresses of a Business
router.get(
  "/business/:businessId",
  controller.getAddresses
);

// Get Address By Id
router.get("/:id", controller.getAddressById);

// Update Address
router.put("/:id", controller.updateAddress);

// Delete Address
router.delete("/:id", controller.deleteAddress);

export default router;