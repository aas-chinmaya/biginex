import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as service from "../services/businessBank.service";

export const createBank = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createBankService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBanks = asyncHandler(async (req: Request, res: Response) => {
  const businessId = String(req.params.businessId);
  const result = await service.getBanksService(businessId);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBankById = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const result = await service.getBankByIdService(id);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateBank = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const result = await service.updateBankService(id, req.body);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteBank = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  await service.deleteBankService(id);

  return res.status(200).json({
    success: true,
    message: "Business bank deleted successfully",
  });
});