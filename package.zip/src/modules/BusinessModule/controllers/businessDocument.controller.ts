import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as service from "../services/businessDocument.service";

export const createDocument = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createDocumentService(req.body, req.file, (req as any).compressedFile);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getDocumentById = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getDocumentByIdService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

// export const getAllDocuments = asyncHandler(async (_req: Request, res: Response) => {
//   const result = await service.getAllDocumentsService();

//   return res.status(200).json({
//     success: true,
//     message: result.message,
//     data: result.data,
//   });
// });

// export const getDocumentsByBusiness = asyncHandler(async (req: Request, res: Response) => {
//   const result = await service.getDocumentsByBusinessService(req.params.businessId as string);

//   return res.status(200).json({
//     success: true,
//     message: result.message,
//     data: result.data,
//   });
// });

export const getDocumentsByBranch = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getDocumentsByBranchService(req.params.branchId as string);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateDocument = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateDocumentService(req.params.id as string, req.body, req.file, (req as any).compressedFile);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

// export const verifyDocument = asyncHandler(async (req: Request, res: Response) => {
//   const verified = Boolean(req.body.verified);
//   const result = await service.verifyDocumentService(req.params.id, verified);

//   return res.status(200).json({
//     success: true,
//     message: result.message,
//     data: result.data,
//   });
// });

export const deleteDocument = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.deleteDocumentService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

// export const restoreDocument = asyncHandler(async (req: Request, res: Response) => {
//   const result = await service.restoreDocumentService(req.params.id);

//   return res.status(200).json({
//     success: true,
//     message: result.message,
//     data: result.data,
//   });
// });