import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as service from "../services/business.service";

export const createBusiness = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createBusinessService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBusinesses = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getBusinessesService();

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBusinessById = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const result = await service.getBusinessByIdService(id);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateBusiness = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  const compressedFile = (req as any).compressedFile;
  const result = await service.updateBusinessService(id, {
    ...req.body,
    compressedFile,
  });

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteBusiness = asyncHandler(async (req: Request, res: Response) => {
  const id = String(req.params.id);
  await service.deleteBusinessService(id);

  return res.status(200).json({
    success: true,
    message: "Business deleted successfully",
  });
});