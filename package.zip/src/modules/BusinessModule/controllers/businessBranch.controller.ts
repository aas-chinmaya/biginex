import { Request, Response } from "express";
import asyncHandler from "../../../common/helpers/asyncHandler";
import * as service from "../services/businessBranch.service";

export const createBusinessBranch = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createBusinessBranchService(req.body);

  return res.status(201).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBusinessBranchById = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getBusinessBranchByIdService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getBusinessBranches = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getBusinessBranchesService(req.params.businessId as string);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const getAllBusinessBranches = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getAllBusinessBranchesService();

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const updateBusinessBranch = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateBusinessBranchService(req.params.id as string, req.body);

  return res.status(200).json({
    success: true,
    message: result.message,
    data: result.data,
  });
});

export const deleteBusinessBranch = asyncHandler(async (req: Request, res: Response) => {
  await service.deleteBusinessBranchService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: "Business branch deleted successfully",
  });
});