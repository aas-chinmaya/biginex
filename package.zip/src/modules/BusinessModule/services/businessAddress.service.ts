import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import ValidationError from "../../../common/exceptions/ValidationError";
import * as repository from "../repository/businessAddress.repository";
import prisma from "../../../config/db";


// export const createAddressService = async (body: any) => {
//   const {
//     tenantId,
//     addressLine1,
//     addressLine2,
//     pincode,
//     country,
//     state,
//     city,
//     isPrimary,
//   } = body;

//   // ===========================
//   // Required Validation
//   // ===========================

//   if (!tenantId) {
//     return {
//       status: 400,
//       message: "Tenant is required.",
//     };
//   }

//   if (!addressLine1) {
//     return {
//       status: 400,
//       message: "Address Line 1 is required.",
//     };
//   }

//   if (!pincode) {
//     return {
//       status: 400,
//       message: "Pincode is required.",
//     };
//   }

//   if (!country) {
//     return {
//       status: 400,
//       message: "Country is required.",
//     };
//   }

//   if (!state) {
//     return {
//       status: 400,
//       message: "State is required.",
//     };
//   }

//   if (!city) {
//     return {
//       status: 400,
//       message: "City is required.",
//     };
//   }

//   // ===========================
//   // Business Validation
//   // ===========================

//   const business = await prisma.business.findFirst({
//     where: {
//       tenantId,
//       deletedAt: null,
//     },
//     select: {
//       id: true,
//       tenantId: true,
//     },
//   });

//   console.log("Received tenantId:", tenantId);
//   console.log("Business found:", business);

//   if (!business) {
//     return {
//       status: 404,
//       message: "Business not found.",
//     };
//   }

//   // ===========================
//   // Duplicate Validation
//   // ===========================

//   const duplicate =
//     await repository.findDuplicateAddress(
//       tenantId,
//       addressLine1,
//       pincode
//     );

//   if (duplicate) {
//     // Existing active address
//     if (!duplicate.deletedAt) {
//       return {
//         status: 400,
//         message: "Address already exists.",
//       };
//     }

//     // ===========================
//     // Restore Deleted Address
//     // ===========================

//     if (isPrimary) {
//       await repository.clearPrimaryAddress(tenantId);
//     }

//     const restored =
//       await repository.restoreAddress(
//         duplicate.id,
//         body
//       );

//     return {
//       status: 200,
//       message: "Address restored successfully.",
//       data: restored,
//     };
//   }

//   // ===========================
//   // Only One Primary Address
//   // ===========================

//   if (isPrimary) {
//     await repository.clearPrimaryAddress(tenantId);
//   }

//   // ===========================
//   // Create Address
//   // ===========================

//   const address =
//     await repository.createAddress({
//       tenantId,
//       addressLine1,
//       addressLine2,
//       pincode,
//       country,
//       state,
//       city,
//       isPrimary,
//     });

//   return {
//     status: 201,
//     message: "Business Address created successfully.",
//     data: address,
//   };
// };


export const createAddressService = async (body: any) => {
  const {
    tenantId,
    addressLine1,
    addressLine2,
    pincode,
    country,
    state,
    city,
    isPrimary = false,
  } = body;

  // ===========================
  // Required Validation
  // ===========================

  if (!tenantId) {
    throw new ValidationError("Tenant is required.");
  }

  if (!addressLine1?.trim()) {
    throw new ValidationError("Address Line 1 is required.");
  }

  if (!pincode) {
    throw new ValidationError("Pincode is required.");
  }

  if (!country?.trim()) {
    throw new ValidationError("Country is required.");
  }

  if (!state?.trim()) {
    throw new ValidationError("State is required.");
  }

  if (!city?.trim()) {
    throw new ValidationError("City is required.");
  }

  // ===========================
  // Business Validation
  // ===========================

  const business =
    await prisma.business.findFirst({
      where: {
        tenantId,
        deletedAt: null,
      },
      select: {
        id: true,
        tenantId: true,
      },
    });

  if (!business) {
    throw new NotFoundError("Business not found.");
  }

  // ===========================
  // Find Existing Address
  // ===========================

  const existingAddress =
    await repository.findDuplicateAddress(
      tenantId,
      addressLine1,
      pincode
    );

  // ==========================================================
  // EXISTING ADDRESS
  // ==========================================================

  if (existingAddress) {

    // ===========================
    // Active Address
    // ===========================

    if (!existingAddress.deletedAt) {

      // If this address should become primary,
      // remove primary from other addresses
      if (isPrimary) {
        await repository.clearPrimaryAddress(
          tenantId,
          existingAddress.id
        );
      }

      const updated =
        await repository.updateAddress(
          existingAddress.id,
          {
            addressLine1,
            addressLine2,
            pincode,
            country,
            state,
            city,
            isPrimary,
          }
        );

      return {
        status: 200,
        message: "Address updated successfully.",
        data: updated,
      };
    }

    // ===========================
    // Soft Deleted Address
    // ===========================

    if (isPrimary) {
      await repository.clearPrimaryAddress(
        tenantId
      );
    }

    const restored =
      await repository.restoreAddress(
        existingAddress.id,
        {
          tenantId,
          addressLine1,
          addressLine2,
          pincode,
          country,
          state,
          city,
          isPrimary,
        }
      );

    return {
      status: 200,
      message: "Address restored successfully.",
      data: restored,
    };
  }

  // ==========================================================
  // NEW ADDRESS
  // ==========================================================

  if (isPrimary) {
    await repository.clearPrimaryAddress(
      tenantId
    );
  }

  const address =
    await repository.createAddress({
      tenantId,
      addressLine1,
      addressLine2,
      pincode,
      country,
      state,
      city,
      isPrimary,
    });

  return {
    message: "Business Address created successfully.",
    data: address,
  };
};





// export const getAddressesService = async (
//   tenantId: string
// ) => {
//   const addresses =
//     await repository.getAllByBusiness(
//       tenantId
//     );

//   return {
//     status: 200,
//     data: addresses,
//   };
// };

export const getAddressesService = async (
  tenantId: string
) => {
  const addresses =
    await repository.getAllByBusiness(tenantId);

  return {
    message: "Addresses fetched successfully.",
    data: addresses,
  };
};



export const getAddressByIdService = async (
  id: string
) => {
  const address =
    await repository.findById(id);

  if (!address) {
    return {
      status: 404,
      message: "Address not found.",
    };
  }

  return {
    status: 200,
    data: address,
  };
};



export const updateAddressService = async (
  id: string,
  body: any
) => {
  const address =
    await repository.findById(id);

  if (!address) {
    return {
      status: 404,
      message: "Address not found.",
    };
  }

  if (body.tenantId) {
    const business =
      await prisma.business.findFirst({
        where: {
          id: body.tenantId,
          deletedAt: null,
        },
      });

    if (!business) {
      return {
        status: 404,
        message: "Business not found.",
      };
    }
  }

  if (body.isPrimary) {
    await repository.clearPrimaryAddress(
      body.tenantId || address.tenantId 
    );
  }

  const updated =
    await repository.updateAddress(
      id,
      body
    );

  return {
    status: 200,
    message:
      "Business Address updated successfully.",
    data: updated,
  };
};



export const deleteAddressService = async (
  id: string
) => {
  const address =
    await repository.findById(id);

  if (!address) {
    return {
      status: 404,
      message: "Address not found.",
    };
  }

  await repository.deleteAddress(id);

  return {
    status: 200,
    message:
      "Business Address deleted successfully.",
  };
};

