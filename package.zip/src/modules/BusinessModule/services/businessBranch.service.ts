import ConflictError from "../../../common/exceptions/ConflictError";
import NotFoundError from "../../../common/exceptions/NotFoundError";
import ValidationError from "../../../common/exceptions/ValidationError";
import prisma from "../../../config/db";
import * as repository from "../repository/businessBranch.repository";
import { generateBranchCode } from "../../../utils/generateBranchCode";

// ============================================================
// CREATE
// ============================================================


export const createBusinessBranchService = async (
  body: any
) => {
  const {
    tenantId,
    branchName,
    userId,
    phone,
    email,
    pincode,
    country,
    state,
    city,
    status,
  } = body;

  // ==========================================================
  // REQUIRED VALIDATION
  // ==========================================================

  if (!tenantId) {
    throw new ValidationError("Tenant ID is required.");
  }

  if (!branchName?.trim()) {
    throw new ValidationError("Branch Name is required.");
  }

  if (!phone?.trim()) {
    throw new ValidationError("Phone is required.");
  }

  if (!email?.trim()) {
    throw new ValidationError("Email is required.");
  }

  if (!pincode) {
    throw new ValidationError("Pincode is required.");
  }

  if (!country?.trim()) {
    throw new ValidationError("Country is required.");
  }

  if (!state?.trim()) {
    throw new ValidationError("State is required.");
  }

  if (!city?.trim()) {
    throw new ValidationError("City is required.");
  }

  // ==========================================================
  // BUSINESS VALIDATION
  // ==========================================================

  const business =
    await prisma.business.findFirst({
      where: {
        tenantId,
        deletedAt: null,
      },
      select: {
        id: true,
        tenantId: true,
      },
    });

  if (!business) {
    throw new NotFoundError("Business not found.");
  }

  // ==========================================================
  // USER VALIDATION
  // ==========================================================

  if (userId) {
    const user =
      await prisma.user.findFirst({
        where: {
          id: userId,
          isDeleted: false,
        },
      });

    if (!user) {
      throw new NotFoundError("User not found.");
    }
  }

  // ==========================================================
  // FIND EXISTING BRANCH
  // ==========================================================

  const existingBranch =
    await repository.findByBranchName(
      tenantId,
      branchName
    );

  // ==========================================================
  // EXISTING BRANCH
  // ==========================================================

  if (existingBranch) {

    // ========================================================
    // ACTIVE BRANCH → UPDATE
    // ========================================================

    if (!existingBranch.isDeleted) {

      const updated =
        await repository.updateBusinessBranch(
          existingBranch.id,
          {
            // Do NOT change branchCode
            branchName,
            userId,
            phone,
            email,
            pincode,
            country,
            state,
            city,
            status,
          }
        );

      return {
        message: "Business branch updated successfully.",
        data: updated,
      };
    }

    // ========================================================
    // DELETED BRANCH → RESTORE + UPDATE
    // ========================================================

    const restored =
      await repository.restoreBusinessBranch(
        existingBranch.id,
        {
          tenantId,
          branchName,
          userId,
          phone,
          email,
          pincode,
          country,
          state,
          city,
          status,
        }
      );

    return {
      message: "Business branch restored successfully.",
      data: restored,
    };
  }

  // ==========================================================
  // NEW BRANCH
  // ==========================================================

  let branchCode: string;

  try {
    branchCode =
      await generateBranchCode(tenantId);
  } catch (error) {
    throw new ValidationError(error instanceof Error ? error.message : "Unable to generate branch code.");
  }

  // ==========================================================
  // CREATE NEW BRANCH
  // ==========================================================

  const branch =
    await repository.createBusinessBranch({
      tenantId,
      branchCode,
      branchName,
      userId,
      phone,
      email,
      pincode,
      country,
      state,
      city,
      status,
    });

  return {
    message: "Business branch created successfully.",
    data: branch,
  };
};





// ============================================================
// GET BY ID
// ============================================================

export const getBusinessBranchByIdService =
  async (id: string) => {
    if (!id) {
      return {
        status: 400,
        message: "Branch ID is required.",
      };
    }

    const branch =
      await repository.findBusinessBranchById(
        id
      );

    if (!branch) {
      throw new NotFoundError("Business branch not found.");
    }

    return {
      message: "Business branch fetched successfully.",
      data: branch,
    };
  };

// ============================================================
// GET BY BUSINESS
// ============================================================

export const getBusinessBranchesService =
  async (tenatId: string) => {
    if (!tenatId) {
      throw new ValidationError("Business ID is required.");
    }

    // Validate business
    const business =
      await prisma.business.findFirst({
        where: {
          id: tenatId,
          deletedAt: null,
        },
      });

    if (!business) {
      throw new NotFoundError("Business not found.");
    }

    const branches =
      await repository.findBusinessBranchesByBusinessId(
        tenatId
      );

    return {
      status: 200,
      message:
        "Business branches fetched successfully.",
      data: branches,
    };
  };

// ============================================================
// GET ALL
// ============================================================

export const getAllBusinessBranchesService =
  async () => {
    const branches =
      await repository.getAllBusinessBranches();

    return {
      status: 200,
      message:
        "Business branches fetched successfully.",
      data: branches,
    };
  };

// ============================================================
// UPDATE
// ============================================================

export const updateBusinessBranchService =
  async (
    id: string,
    body: any
  ) => {
    if (!id) {
      return {
        status: 400,
        message: "Branch ID is required.",
      };
    }

    // ========================================================
    // FIND EXISTING BRANCH
    // ========================================================

    const existingBranch =
      await repository.findBusinessBranchById(
        id
      );

    if (!existingBranch) {
      return {
        status: 404,
        message: "Business branch not found.",
      };
    }

    const {
      tenatId,
      branchCode,
      branchName,
      userId,
    } = body;

    // ========================================================
    // BUSINESS VALIDATION
    // ========================================================

    if (tenatId) {
      const business =
        await prisma.business.findFirst({
          where: {
            id: tenatId,
            deletedAt: null,
          },
        });

      if (!business) {
        return {
          status: 404,
          message: "Business not found.",
        };
      }
    }

    // ========================================================
    // USER VALIDATION
    // ========================================================

    if (userId) {
      const user =
        await prisma.user.findFirst({
          where: {
            id: userId,
            isDeleted: false,
          },
        });

      if (!user) {
        return {
          status: 404,
          message: "User not found.",
        };
      }
    }

    // ========================================================
    // BRANCH CODE DUPLICATE
    // ========================================================

    if (branchCode) {
      const checkBusinessId =
        tenatId ||
        existingBranch.tenatId;

      const branch =
        await repository.findByBranchCode(
          checkBusinessId,
          branchCode
        );

      if (
        branch &&
        branch.id !== id &&
        !branch.isDeleted
      ) {
        return {
          status: 400,
          message:
            "Branch code already exists for this business.",
        };
      }
    }

    // ========================================================
    // BRANCH NAME DUPLICATE
    // ========================================================

    if (branchName) {
      const checkBusinessId =
        tenatId ||
        existingBranch.tenatId;

      const branch =
        await repository.findByBranchName(
          checkBusinessId,
          branchName
        );

      if (
        branch &&
        branch.id !== id &&
        !branch.isDeleted
      ) {
        return {
          status: 400,
          message:
            "Branch name already exists for this business.",
        };
      }
    }

    // ========================================================
    // UPDATE DATA
    // ========================================================

    const updateData: any = {
      ...body,
    };

    // Prevent modification of protected fields

    delete updateData.id;
    delete updateData.createdAt;
    delete updateData.updatedAt;
    delete updateData.deletedAt;
    delete updateData.isDeleted;

    // ========================================================
    // UPDATE
    // ========================================================

    const updatedBranch =
      await repository.updateBusinessBranch(
        id,
        updateData
      );

    return {
      message: "Business branch updated successfully.",
      data: updatedBranch,
    };
  };

// ============================================================
// DELETE
// ============================================================

export const deleteBusinessBranchService =
  async (id: string) => {
    if (!id) {
      return {
        status: 400,
        message: "Branch ID is required.",
      };
    }

    const branch =
      await repository.findBusinessBranchById(
        id
      );

    if (!branch) {
      return {
        status: 404,
        message: "Business branch not found.",
      };
    }

    await repository.deleteBusinessBranch(id);

    return {
      status: 200,
      message:
        "Business branch deleted successfully.",
    };
  };