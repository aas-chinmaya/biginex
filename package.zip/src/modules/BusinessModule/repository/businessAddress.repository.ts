import prisma from "../../../config/db";

export const createAddress = (data: {
  tenantId: string;
  addressLine1: string;
  addressLine2?: string;
  pincode: string;
  country: string;
  state: string;
  city: string;
  isPrimary?: boolean;
}) => {
  return prisma.businessAddress.create({
    data,
  });
};

export const findById = (id: string) => {
  return prisma.businessAddress.findFirst({
    where: {
      id,
      deletedAt: null,
    },
    include: {
      business: true,
    },
  });
};

export const getAllByBusiness = (tenantId: string) => {
  return prisma.businessAddress.findMany({
    where: {
      tenantId,
      deletedAt: null,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const updateAddress = (
  id: string,
  data: any
) => {
  return prisma.businessAddress.update({
    where: {
      id,
    },
    data,
  });
};

export const deleteAddress = (id: string) => {
  return prisma.businessAddress.update({
    where: {
      id,
    },
    data: {
      deletedAt: new Date(),
    },
  });
};

export const restoreAddress = (
  id: string,
  data: any
) => {
  return prisma.businessAddress.update({
    where: {
      id,
    },
    data: {
      ...data,
      deletedAt: null,
    },
  });
};

export const findDuplicateAddress = (
  tenantId: string,
  addressLine1: string,
  pincode: string
) => {
  return prisma.businessAddress.findFirst({
    where: {
      tenantId,
      addressLine1,
      pincode,
    },
  });
};


export const clearPrimaryAddress = (
  tenantId: string,
  excludeAddressId?: string
) => {
  return prisma.businessAddress.updateMany({
    where: {
      tenantId,
      deletedAt: null,

      ...(excludeAddressId
        ? {
            id: {
              not: excludeAddressId,
            },
          }
        : {}),
    },

    data: {
      isPrimary: false,
    },
  });
};