import prisma from "../../../config/db";
import { BusinessDocumentType } from "@prisma/client";

/**
 * Create Document
 */
export const createDocument = (data: {
  tenantId: string;
  branchId?: string | null;
  documentType: BusinessDocumentType;
  fileName: string;
  fileUrl: string;
  verified?: boolean;
}) => {
  return prisma.businessDocument.create({
    data,
    include: {
      business: true,
      branch: true,
    },
  });
};

/**
 * Find Document By ID
 */
export const findById = (id: string) => {
  return prisma.businessDocument.findFirst({
    where: {
      id,
      deletedAt: null,
    },
    include: {
      business: true,
      branch: true,
    },
  });
};

/**
 * Get All Documents
 */
export const getAllDocuments = () => {
  return prisma.businessDocument.findMany({
    where: {
      deletedAt: null,
    },
    include: {
      business: true,
      branch: true,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

/**
 * Get Documents By Business
 */
export const getDocumentsByBusiness = (
  tenantId: string
) => {
  return prisma.businessDocument.findMany({
    where: {
      tenantId,
      deletedAt: null,
    },
    include: {
      branch: true,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

/**
 * Get Documents By Branch
 */
export const getDocumentsByBranch = (
  branchId: string
) => {
  return prisma.businessDocument.findMany({
    where: {
      branchId,
      deletedAt: null,
    },
    include: {
      business: true,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

/**
 * Find Document By Type
 */

export const findByType = (
  tenantId: string,
  branchId: string | null,
  documentType: BusinessDocumentType
) => {
  return prisma.businessDocument.findFirst({
    where: {
      tenantId,
      branchId,
      documentType,
    },
  });
};


/**
 * Update Document
 */
export const updateDocument = (
  id: string,
  data: {
    tenantId?: string;
    documentType?: BusinessDocumentType;
    fileName?: string;
    fileUrl?: string;
    branchId?: string | null;
    verified?: boolean;
  }
) => {
  return prisma.businessDocument.update({
    where: {
      id,
    },
    data,
  });
};

/**
 * Verify Document
 */
export const verifyDocument = (
  id: string,
  verified: boolean
) => {
  return prisma.businessDocument.update({
    where: {
      id,
    },
    data: {
      verified,
    },
  });
};

/**
 * Soft Delete
 */
export const deleteDocument = (
  id: string
) => {
  return prisma.businessDocument.update({
    where: {
      id,
    },
    data: {
      deletedAt: new Date(),
    },
  });
};

/**
 * Restore
 */
export const restoreDocument = async (
  id: string,
  data: {
    tenantId: string;
    branchId: string | null;
    documentType: BusinessDocumentType;
    fileName: string;
    fileUrl: string;
    verified: boolean;
  }
) => {
  return prisma.businessDocument.update({
    where: {
      id,
    },
    data: {
      ...data,
      deletedAt: null,
    },
  });
};