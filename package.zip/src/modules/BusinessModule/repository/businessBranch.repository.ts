import prisma from "../../../config/db";

// ============================================================
// CREATE
// ============================================================

export const createBusinessBranch = (
  data: any
) => {
  return prisma.businessBranch.create({
    data,
    include: {
      business: true,
      user: true,
    },
  });
};

// ============================================================
// FIND BY ID
// ============================================================

export const findBusinessBranchById = (
  id: string
) => {
  return prisma.businessBranch.findFirst({
    where: {
      id,
      isDeleted: false,
    },
    include: {
      business: true,
      user: true,
      documents: {
        where: {
          deletedAt: null,
        },
      },
    },
  });
};

// ============================================================
// FIND ALL BY BUSINESS
// ============================================================

export const findBusinessBranchesByBusinessId = (
  tenantId: string
) => {
  return prisma.businessBranch.findMany({
    where: {
      tenantId,
      isDeleted: false,
    },
    include: {
      user: true,
      documents: {
        where: {
          deletedAt: null,
        },
      },
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};



export const getAllBusinessBranches = () => {
  return prisma.businessBranch.findMany({
    where: {
      isDeleted: false,
    },
    include: {
      business: true,
      user: true,
      documents: {
        where: {
          deletedAt: null,
        },
      },
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};



export const findByBranchCode = (
  tenantId: string,
  branchCode: string
) => {
  return prisma.businessBranch.findFirst({
    where: {
      tenantId,
      branchCode,
    },
  });
};



export const findByBranchName = (
  tenantId: string,
  branchName: string
) => {
  return prisma.businessBranch.findFirst({
    where: {
      tenantId,
      branchName,
    },
  });
};



// export const updateBusinessBranch = (
//   id: string,
//   data: any
// ) => {
//   return prisma.businessBranch.update({
//     where: {
//       id,
//     },
//     data,
//     include: {
//       business: true,
//       user: true,
//     },
//   });
// };

// ============================================================
// SOFT DELETE
// ============================================================

export const deleteBusinessBranch = (
  id: string
) => {
  return prisma.businessBranch.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
      deletedAt: new Date(),
    },
  });
};

// ============================================================
// RESTORE + UPDATE
// ============================================================

export const restoreBusinessBranch = (
  id: string,
  data: {
    tenantId: string;
    branchName?: string;
    userId?: string;
    phone: string;
    email: string;
    pincode: string;
    country: string;
    state: string;
    city: string;
    status?: any;
  }
) => {
  return prisma.businessBranch.update({
    where: {
      id,
    },
    data: {
      tenantId: data.tenantId,
      branchName: data.branchName,
      userId: data.userId,
      phone: data.phone,
      email: data.email,
      pincode: data.pincode,
      country: data.country,
      state: data.state,
      city: data.city,
      status: data.status,

      // Restore
      isDeleted: false,
      deletedAt: null,
    },
    include: {
      business: true,
      user: true,
    },
  });
};

// ============================================================
// FIND LATEST BRANCH BY TENANT
// ============================================================

export const findLatestBranchByTenant = async (
  tenantId: string
) => {
  return prisma.businessBranch.findFirst({
    where: {
      tenantId,
    },
    orderBy: {
      branchCode: "desc",
    },
  });
};
