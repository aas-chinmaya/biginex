import prisma from "../../../config/db";

export const createBusiness = (data: any) => {
  return prisma.business.create({
    data,
  });
};

export const findById = (id: string) => {
  return prisma.business.findFirst({
    where: {
      id,
      deletedAt: null,
    },
    include: {
      category: true,
      industry: true,
      registrationType: true,
      currency: true,
      creator: true,

      addresses: {
        where: {
          deletedAt: null,
        },
      },

      banks: {
        where: {
          deletedAt: null,
        },
      },

      branches: {
        where: {
          deletedAt: null,
        },
      },

      documents: {
        where: {
          deletedAt: null,
        },
      },
    },
  });
};

export const getAllBusinesses = async () => {
  return prisma.business.findMany({
    where: {
      deletedAt: null,
    },

    include: {
      // ==========================
      // Addresses
      // ==========================
      addresses: {
        where: {
          deletedAt: null,
        },
        orderBy: {
          isPrimary: "desc",
        },
      },

      // ==========================
      // Bank Details
      // ==========================
      banks: {
        where: {
          deletedAt: null,
        },
      },

      // ==========================
      // Branches
      // ==========================
      branches: {
        where: {
          isDeleted: false,
          deletedAt: null,
        },

        include: {
          // User assigned to branch
          user: true,

          // Branch Documents
          documents: {
            where: {
              isDeleted: false,
              deletedAt: null,
            },
          },
        },
      },

      // ==========================
      // Business-level Documents
      // ==========================
      documents: {
        where: {
          isDeleted: false,
          deletedAt: null,

          // Only documents that are NOT
          // associated with a branch
          branchId: null,
        },
      },
    },

    orderBy: {
      createdAt: "desc",
    },
  });
};

export const findByGSTIN = (gstin: string) => {
  return prisma.business.findFirst({
    where: {
      gstin,
    },
  });
};

export const findByPAN = (pan: string) => {
  return prisma.business.findFirst({
    where: {
      pan,
    },
  });
};

export const updateBusiness = (
  id: string,
  data: any
) => {
  return prisma.business.update({
    where: {
      id,
    },
    data,
  });
};

export const deleteBusiness = (id: string) => {
  return prisma.business.update({
    where: {
      id,
    },
    data: {
      deletedAt: new Date(),
    },
  });
};

export const restoreBusiness = (
  id: string,
  data: any
) => {
  return prisma.business.update({
    where: {
      id,
    },
    data: {
      ...data,
      deletedAt: null,
    },
  });
};

export const businessExists = (
  legalName: string
) => {
  return prisma.business.findFirst({
    where: {
      legalName,
    },
  });
};


export const findLatestTenantByPrefix = async (
  prefix: string
) => {
  return prisma.business.findFirst({
    where: {
      tenantId: {
        startsWith: `${prefix}-Ten-`,
      },
    },
    orderBy: {
      createdAt: "desc",
    },
    select: {
      tenantId: true,
    },
  });
};