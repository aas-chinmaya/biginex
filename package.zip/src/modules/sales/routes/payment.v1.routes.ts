import express from "express";
const router = express.Router();
import * as paymentController from "../controllers/payment.controller";

router.post("/create-payment", paymentController.createPayment);

export default router; 