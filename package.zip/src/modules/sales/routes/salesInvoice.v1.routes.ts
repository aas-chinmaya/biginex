import express from "express";
const router = express.Router();
import * as salesInvoiceController from "../controllers/salesInvoice.controller";


/**
 * ---------------------------------------------------------
 * Draft APIs
 * ---------------------------------------------------------
*/
router.post("/drafts", salesInvoiceController.createDraft);
router.get("/fetch-drafts", salesInvoiceController.getDrafts);
router.get("/fetch-drafts/:id", salesInvoiceController.getDraftById);
router.patch("/drafts/:id", salesInvoiceController.updateDraft);
router.delete("/drafts/:id", salesInvoiceController.deleteDraft);
router.post("/drafts/:id/finalize", salesInvoiceController.finalizeDraft);

/**
 * ---------------------------------------------------------
 * Invoice Operations APIs
 * ---------------------------------------------------------
*/
router.post("/", salesInvoiceController.saveInvoice);
router.get("/invoices", salesInvoiceController.getInvoices);
router.get("/invoices/:id", salesInvoiceController.getInvoiceById);
router.patch("/invoices/:id/cancel", salesInvoiceController.cancelInvoice);

export default router;