import { Prisma,PaymentDocumentType } from "@prisma/client";
type Tx = Prisma.TransactionClient;

/**
 * Create a payment
 */
export const create = async (tx: Tx,data: Prisma.PaymentCreateInput) => {
  return tx.payment.create({
    data,
  });
};

/**
 * Find payment by ID
 */
export const findById = async (tx: Tx,id: string) => {
  return tx.payment.findUnique({
    where: { id },
  });
};

/**
 * Find payment by payment number
 */
export const findByPaymentNumber = async (tx: Tx,businessId: string,paymentNumber: string) => {
  return tx.payment.findFirst({
    where: {
      businessId,
      paymentNumber,
      deletedAt: null,
    },
  });
};

/**
 * Find all payments for an invoice/document
 */
export const findByDocument = async (tx: Tx,businessId: string,documentType: PaymentDocumentType,documentNumber: string) => {
  return tx.payment.findMany({
    where: {
      businessId,
      documentType,
      documentNumber,
      deletedAt: null,
    },
    orderBy: {
      paymentDate: "desc",
    },
  });
};

/**
 * Find successful payments for an invoice
 */
export const findSuccessfulByDocument = async (tx: Tx,businessId: string,documentType: PaymentDocumentType,documentNumber: string) => {
  return tx.payment.findMany({
    where: {
      businessId,
      documentType,
      documentNumber,
      paymentStatus: "SUCCESS",
      deletedAt: null,
    },
    orderBy: {
      paymentDate: "asc",
    },
  });
};

/**
 * Find payment using Razorpay order ID
 */
export const findByGatewayOrderId = async (tx: Tx,gatewayOrderId: string) => {
  return tx.payment.findFirst({
    where: {
      gatewayOrderId,
      deletedAt: null,
    },
  });
};

/**
 * Find payment using Razorpay payment ID
 */
export const findByGatewayPaymentId = async (tx: Tx,gatewayPaymentId: string) => {
  return tx.payment.findFirst({
    where: {
      gatewayPaymentId,
      deletedAt: null,
    },
  });
};

/**
 * Update payment
 */
export const update = async (tx: Tx,id: string,data: Prisma.PaymentUpdateInput) => {
  return tx.payment.update({
    where: { id },
    data,
  });
};

/**
 * Mark payment as successful
 */
export const markSuccess = async ( tx: Tx, id: string, data?: Prisma.PaymentUpdateInput) => {
  return tx.payment.update({
    where: { id },
    data: {
      paymentStatus: "SUCCESS",
      ...data,
    },
  });
};

/**
 * Mark payment as failed
 */
export const markFailed = async ( tx: Tx,id: string,data?: Prisma.PaymentUpdateInput) => {
  return tx.payment.update({
    where: { id },
    data: {
      paymentStatus: "FAILED",
      ...data,
    },
  });
};

/**
 * Mark payment as cancelled
 */
export const markCancelled = async (tx: Tx,id: string, updatedBy?: string) => {
  return tx.payment.update({
    where: { id },
    data: {
      paymentStatus: "CANCELLED",
      updatedBy,
    },
  });
};

/**
 * Get customer's payment history
 */
export const findByCustomer = async ( tx: Tx, businessId: string, customerId: string,take = 50) => {
  return tx.payment.findMany({
    where: {
      businessId,
      customerId,
      deletedAt: null,
    },
    orderBy: {
      paymentDate: "desc",
    },
    take,
  });
};