export const compareAmount = (
    backendValue: number | string,
    frontendValue: number | string,
    tolerance = 0.01
): boolean => {

    const backend = Number(backendValue);
    const frontend = Number(frontendValue);

    return Math.abs(backend - frontend) <= tolerance;

};

export const compareQuantity = (
    backendValue: number | string,
    frontendValue: number | string,
    tolerance = 0.001
): boolean => {

    const backend = Number(backendValue);
    const frontend = Number(frontendValue);

    return Math.abs(backend - frontend) <= tolerance;

};