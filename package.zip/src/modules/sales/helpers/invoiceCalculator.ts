export const calculateInvoice = (
    invoice: any,
    items: any[]
) => {

    const sellerStateCode = invoice.sellerStateCode;
    const placeOfSupplyCode = invoice.placeOfSupplyCode;

    const isIntraState =
        sellerStateCode === placeOfSupplyCode;

    let totalItems = items.length;
    let totalQuantity = 0;
    let taxableAmount = 0;
    let discountAmount = 0;
    let cgstAmount = 0;
    let sgstAmount = 0;
    let igstAmount = 0;
    let cessAmount = 0;
    let roundOffAmount = 0;
    let grandTotal = 0;

    const calculatedItems = items.map((item, index) => {

        const quantity = Number(item.quantity);
        const unitPrice = Number(item.unitPrice);
        const gstRate = Number(item.gstRate);
        const cessRate = Number(item.cessRate ?? 0);
        const discount = Number(item.discountAmount ?? 0);
        const grossAmount = quantity * unitPrice;
        const taxable = grossAmount - discount;

        let cgst = 0;
        let sgst = 0;
        let igst = 0;

        if (isIntraState) {

            cgst = taxable * ((gstRate / 2) / 100);
            sgst = taxable * ((gstRate / 2) / 100);

        } else {

            igst = taxable * (gstRate / 100);

        }

        const cess = taxable * (cessRate / 100);

        const lineTotal = taxable + cgst + sgst + igst + cess;

        totalQuantity += quantity;
        taxableAmount += taxable;
        discountAmount += discount;
        cgstAmount += cgst;
        sgstAmount += sgst;
        igstAmount += igst;
        cessAmount += cess;
        grandTotal += lineTotal;

        return {
            lineNumber: index + 1,
            quantity,
            taxableAmount: Number(taxable.toFixed(2)),
            discountAmount: Number(discount.toFixed(2)),
            cgstAmount: Number(cgst.toFixed(2)),
            sgstAmount: Number(sgst.toFixed(2)),
            igstAmount: Number(igst.toFixed(2)),
            cessAmount: Number(cess.toFixed(2)),
            lineTotal: Number(lineTotal.toFixed(2))
        };

    });

    grandTotal = Number(grandTotal.toFixed(2));
    return {

        taxType: isIntraState
            ? "INTRA_STATE"
            : "INTER_STATE",

        summary: {

            totalItems,
            totalQuantity: Number(totalQuantity.toFixed(3)),
            taxableAmount: Number(taxableAmount.toFixed(2)),
            discountAmount: Number(discountAmount.toFixed(2)),
            cgstAmount: Number(cgstAmount.toFixed(2)),
            sgstAmount: Number(sgstAmount.toFixed(2)),
            igstAmount: Number(igstAmount.toFixed(2)),
            cessAmount: Number(cessAmount.toFixed(2)),
            roundOffAmount: Number(roundOffAmount.toFixed(2)),
            grandTotal,
            pendingAmount: grandTotal
        },
        items: calculatedItems
    };

};