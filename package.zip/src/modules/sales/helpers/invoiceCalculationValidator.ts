import { ValidationError } from "../../../common/exceptions/ValidationError";
import { compareAmount, compareQuantity } from "./amountComparator";

export const validateCalculatedInvoice = (
    frontendInvoice: any,
    backendInvoice: any
): void => {

    const frontendSummary = frontendInvoice;

    const backendSummary = backendInvoice.summary;
    console.log("backendSummary", backendSummary);

    if (
        !compareQuantity(
            backendSummary.totalQuantity,
            frontendSummary.totalQuantity
        )
    ) {
        throw new ValidationError("Total quantity mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.taxableAmount,
            frontendSummary.taxableAmount
        )
    ) {
        throw new ValidationError("Taxable amount mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.discountAmount,
            frontendSummary.discountAmount
        )
    ) {
        throw new ValidationError("Discount amount mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.cgstAmount,
            frontendSummary.cgstAmount
        )
    ) {
        throw new ValidationError("CGST amount mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.sgstAmount,
            frontendSummary.sgstAmount
        )
    ) {
        throw new ValidationError("SGST amount mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.igstAmount,
            frontendSummary.igstAmount
        )
    ) {
        throw new ValidationError("IGST amount mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.cessAmount,
            frontendSummary.cessAmount
        )
    ) {
        throw new ValidationError("CESS amount mismatch.");
    }

    if (
        !compareAmount(
            backendSummary.grandTotal,
            frontendSummary.grandTotal
        )
    ) {
        throw new ValidationError("Grand total mismatch.");
    }

    backendInvoice.items.forEach((item: any, index: number) => {

        const frontendItem = frontendInvoice.items[index];

        if (!frontendItem) {
            throw new ValidationError(`Missing invoice item ${index + 1}.`);
        }

        if (
            !compareQuantity(
                item.quantity,
                frontendItem.quantity
            )
        ) {
            throw new ValidationError(`Quantity mismatch at row ${index + 1}.`);
        }

        if (
            !compareAmount(
                item.taxableAmount,
                frontendItem.taxableAmount
            )
        ) {
            throw new ValidationError(`Taxable amount mismatch at row ${index + 1}.`);
        }

        if (
            !compareAmount(
                item.lineTotal,
                frontendItem.lineTotal
            )
        ) {
            throw new ValidationError(`Line total mismatch at row ${index + 1}.`);
        }
    });
};