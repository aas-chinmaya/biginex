import { z } from "zod";
import { InvoiceSource, InvoiceType } from "@prisma/client";

export const createDraftValidator = z.object({
    body: z.object({
        businessId: z
            .string()
            .trim()
            .min(1, "Business Id is required.")
            .cuid("Invalid Business Id."),

        branchId: z
            .string()
            .trim()
            .cuid("Invalid Branch Id.")
            .optional(),

        createdBy: z
            .string()
            .trim()
            .min(1, "Created By is required.")
            .cuid("Invalid User Id."),

        invoiceType: z.nativeEnum(InvoiceType),

        invoiceSource: z
            .nativeEnum(InvoiceSource)
            .optional()
    }),

    params: z.object({}),

    query: z.object({})
});

export type CreateDraftRequest = z.infer<typeof createDraftValidator>["body"];