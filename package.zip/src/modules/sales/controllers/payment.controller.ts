import { Request, Response } from "express";
import * as paymentService from "../services/payment2.service";

export const createPayment = async (req: Request,res: Response) => {

    const result = await paymentService.createPayment(req.body);

    return res.status(201).json({
        success: true,
        message:
            result.payment.paymentStatus === "PENDING"
                ? "Payment initiated successfully."
                : "Payment completed successfully.",
        data: result,
    });
};