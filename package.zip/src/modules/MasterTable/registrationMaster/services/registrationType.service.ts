import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/registrationType.repository";

export const createRegistrationTypeService = async (body: any) => {
  const { name, description } = body;

  if (!name?.trim()) {
    throw new ValidationError("Registration Type name is required");
  }

  const exists = await repository.findRegistrationTypeByName(name);

  if (exists) {
    throw new ConflictError("Registration Type already exists");
  }

  return repository.createRegistrationType({
    registrationName: name,
    description,
  });
};

export const getAllRegistrationTypesService = async () => {
  return repository.getAllRegistrationTypes();
};

export const updateRegistrationTypeService = async (id: string, body: any) => {
  const registrationType = await repository.findRegistrationTypeById(id);

  if (!registrationType) {
    throw new NotFoundError("Registration Type not found");
  }

  const normalizedBody = { ...body };

  if (typeof normalizedBody.registrationName === "string") {
    normalizedBody.registrationName = normalizedBody.registrationName.trim();
  }

  if (typeof normalizedBody.name === "string") {
    normalizedBody.registrationName = normalizedBody.name.trim();
    delete normalizedBody.name;
  }

  if (normalizedBody.registrationName && normalizedBody.registrationName !== registrationType.registrationName) {
    const exists = await repository.findRegistrationTypeByName(normalizedBody.registrationName);

    if (exists) {
      throw new ConflictError("Registration Type already exists");
    }
  }

  return repository.updateRegistrationType(id, normalizedBody);
};

export const deleteRegistrationTypeService = async (id: string) => {
  const registrationType = await repository.findRegistrationTypeById(id);

  if (!registrationType) {
    throw new NotFoundError("Registration Type not found");
  }

  await repository.deleteRegistrationType(id);
};