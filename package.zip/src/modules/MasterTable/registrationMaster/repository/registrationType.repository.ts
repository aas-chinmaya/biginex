import prisma from "../../../../config/db";

export const createRegistrationType = async (data: any) => {
  return prisma.registrationType.create({
    data,
  });
};

export const findRegistrationTypeByName = async (
  name: string
) => {
  return prisma.registrationType.findFirst({
    where: {
      registrationName: name,
      deletedAt: null,
    },
  });
};

export const findRegistrationTypeById = async (
  id: string
) => {
  return prisma.registrationType.findFirst({
    where: {
      id,
      deletedAt: null,
    },
  });
};

export const getAllRegistrationTypes = async () => {
  return prisma.registrationType.findMany({
    where: {
      deletedAt: null,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const updateRegistrationType = async (
  id: string,
  data: any
) => {
  return prisma.registrationType.update({
    where: {
      id,
    },
    data,
  });
};

export const deleteRegistrationType = async (
  id: string
) => {
  return prisma.registrationType.update({
    where: {
      id,
    },
    data: {
      deletedAt: new Date(),
    },
  });
};