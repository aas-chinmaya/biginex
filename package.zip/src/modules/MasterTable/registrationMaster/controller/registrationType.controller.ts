import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/registrationType.service";

export const createRegistrationType = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.createRegistrationTypeService(req.body);

  return res.status(201).json({
    success: true,
    message: "Registration type created successfully",
    data: result,
  });
});

export const getAllRegistrationTypes = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getAllRegistrationTypesService();

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const updateRegistrationType = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateRegistrationTypeService(req.params.id as string, req.body);

  return res.status(200).json({
    success: true,
    message: "Registration type updated successfully",
    data: result,
  });
});

export const deleteRegistrationType = asyncHandler(async (req: Request, res: Response) => {
  await service.deleteRegistrationTypeService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: "Registration type deleted successfully",
  });
});