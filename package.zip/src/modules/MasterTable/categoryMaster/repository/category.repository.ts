import prisma from "../../../../config/db";

export const createCategory = (data: {
  categoryName: string;
  description?: string;
  icon: string;
}) => {
  return prisma.category.create({
    data,
  });
};

export const restoreCategory = (
  id: string,
  description: string | undefined,
  icon: string,
) => {
  return prisma.category.update({
    where: {
      id,
    },
    data: {
      isDeleted: false,
      description,
      status: true,
      deletedAt: null,
      icon,
    },
  });
};

export const findByName = (categoryName: string) => {
  return prisma.category.findFirst({
    where: {
      categoryName,
    },
  });
};

export const findById = (id: string) => {
  return prisma.category.findFirst({
    where: {
      id,
      isDeleted: false,
    },
  });
};

export const getAll = () => {
  return prisma.category.findMany({
    where: {
      isDeleted: false,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const updateCategory = (
  id: string,
  data: {
    categoryName?: string;
    description?: string;
    status?: boolean;
    icon?: string;
  }
) => {
  return prisma.category.update({
    where: { id },
    data,
  });
};

export const deleteCategory = (id: string) => {
  return prisma.category.update({
    where: { id },
    data: {
      isDeleted: true,
      deletedAt: new Date(),
    },
  });
};
