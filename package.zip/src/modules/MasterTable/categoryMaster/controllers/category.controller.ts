import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/category.service";

export const createCategory = asyncHandler(async (req: Request, res: Response) => {
  const { categoryName, description, icon } = req.body;
  const result = await service.createCategoryService(categoryName, description, icon);

  return res.status(201).json({
    success: true,
    message: "Category created successfully",
    data: result,
  });
});

export const getCategories = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getCategoriesService();

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const getCategoryById = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getCategoryByIdService(req.params.id as string);

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const updateCategory = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateCategoryService(req.params.id as string, req.body);

  return res.status(200).json({
    success: true,
    message: "Category updated successfully",
    data: result,
  });
});

export const deleteCategory = asyncHandler(async (req: Request, res: Response) => {
  await service.deleteCategoryService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: "Category deleted successfully",
  });
});