import { Router } from "express";
import * as controller from "../controllers/category.controller";

const router = Router();

router.post("/createCategory", controller.createCategory);

router.get("/getAllCategories", controller.getCategories);

router.get("/getCategoryById/:id", controller.getCategoryById);

router.put("/updateCategory/:id", controller.updateCategory);

router.delete("/deleteCategory/:id", controller.deleteCategory);

export default router;