import { Router } from "express";
import * as controller from "../controllers/industry.controller";

const router = Router();

router.post("/createIndustry", controller.createIndustry);

router.get("/getAllIndustries", controller.getAllIndustries);

router.put("/updateIndustry/:id", controller.updateIndustry);

router.delete("/deleteIndustry/:id", controller.deleteIndustry);

export default router;