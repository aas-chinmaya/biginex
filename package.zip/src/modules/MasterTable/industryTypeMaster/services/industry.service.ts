import ConflictError from "../../../../common/exceptions/ConflictError";
import NotFoundError from "../../../../common/exceptions/NotFoundError";
import ValidationError from "../../../../common/exceptions/ValidationError";
import * as repository from "../repository/industry.repository";

export const createIndustryService = async (body: any) => {
  const { industryName, description, status } = body;

  if (!industryName?.trim()) {
    throw new ValidationError("Industry name is required");
  }

  const existingIndustry = await repository.findIndustryByName(industryName);

  if (existingIndustry) {
    throw new ConflictError("Industry already exists");
  }

  return repository.createIndustry({
    industryName,
    description,
    status: typeof status === "boolean" ? status : undefined,
  });
};

export const getAllIndustriesService = async () => {
  return repository.getAllIndustries();
};

export const updateIndustryService = async (id: string, body: any) => {
  const industry = await repository.findIndustryById(id);

  if (!industry) {
    throw new NotFoundError("Industry not found");
  }

  if (body.industryName && body.industryName !== industry.industryName) {
    const existingIndustry = await repository.findIndustryByName(body.industryName);

    if (existingIndustry) {
      throw new ConflictError("Industry already exists");
    }
  }

  return repository.updateIndustry(id, body);
};

export const deleteIndustryService = async (id: string) => {
  const industry = await repository.findIndustryById(id);

  if (!industry) {
    throw new NotFoundError("Industry not found");
  }

  await repository.deleteIndustry(id);
};