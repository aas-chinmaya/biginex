import prisma from "../../../../config/db";

export const createSubCategory = (data: {
  categoryId: string;
  subCategoryName: string;
  description?: string;
}) => {
  return prisma.subCategory.create({
    data,
  });
};

export const findById = (id: string) => {
  return prisma.subCategory.findFirst({
    where: {
      id,
      isDeleted: false,
    },
    include: {
      category: true,
    },
  });
};

export const findByName = (
  categoryId: string,
  subCategoryName: string
) => {
  return prisma.subCategory.findFirst({
    where: {
      categoryId,
      subCategoryName,
    },
  });
};

export const getAll = () => {
  return prisma.subCategory.findMany({
    where: {
      isDeleted: false,
    },
    include: {
      category: true,
    },
    orderBy: {
      createdAt: "desc",
    },
  });
};

export const getByCategory = (categoryId: string) => {
  return prisma.subCategory.findMany({
    where: {
      categoryId,
      isDeleted: false,
    },
    orderBy: {
      subCategoryName: "asc",
    },
  });
};

export const updateSubCategory = (
  id: string,
  data: {
    categoryId?: string;
    subCategoryName?: string;
    description?: string;
    status?: boolean;
  }
) => {
  return prisma.subCategory.update({
    where: {
      id,
    },
    data,
  });
};

export const deleteSubCategory = (id: string) => {
  return prisma.subCategory.update({
    where: {
      id,
    },
    data: {
      isDeleted: true,
      deletedAt: new Date(),
    },
  });
};

export const restoreSubCategory = (
  id: string,
  data: {
    description?: string;
    categoryId?: string;
  }
) => {
  return prisma.subCategory.update({
    where: {
      id,
    },
    data: {
      categoryId: data.categoryId,
      description: data.description,
      status: true,
      isDeleted: false,
      deletedAt: null,
    },
  });
};
