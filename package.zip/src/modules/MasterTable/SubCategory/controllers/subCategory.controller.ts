import { Request, Response } from "express";
import asyncHandler from "../../../../common/helpers/asyncHandler";
import * as service from "../services/subCategory.service";

export const createSubCategory = asyncHandler(async (req: Request, res: Response) => {
  const { categoryId, subCategoryName, description } = req.body;
  const result = await service.createSubCategoryService(categoryId, subCategoryName, description);

  return res.status(201).json({
    success: true,
    message: "Sub category created successfully",
    data: result,
  });
});

export const getSubCategories = asyncHandler(async (_req: Request, res: Response) => {
  const result = await service.getSubCategoriesService();

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const getSubCategoryById = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getSubCategoryByIdService(req.params.id as string);

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const getByCategory = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.getSubCategoryByCategoryService(req.params.categoryId as string);

  return res.status(200).json({
    success: true,
    data: result,
  });
});

export const updateSubCategory = asyncHandler(async (req: Request, res: Response) => {
  const result = await service.updateSubCategoryService(req.params.id as string, req.body);

  return res.status(200).json({
    success: true,
    message: "Sub category updated successfully",
    data: result,
  });
});

export const deleteSubCategory = asyncHandler(async (req: Request, res: Response) => {
  await service.deleteSubCategoryService(req.params.id as string);

  return res.status(200).json({
    success: true,
    message: "Sub category deleted successfully",
  });
});