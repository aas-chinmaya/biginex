import "dotenv/config";
import express, { type Application } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import path from "path";
import errorMiddleware from "./common/middlewares/error.middleware";
import indexRouter from "./routes/index";

const app: Application = express();

app.set("trust proxy", 1);

// app.use(
//   cors({
//     origin: true,
//     credentials: true,
//   })
// );

// ====================== CORS Configuration ======================
const allowedOrigins = [
  "http://localhost:3000"
];
 
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) {
        return callback(null, true);
      }
 
      if (allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error(`CORS Error: Origin ${origin} is not allowed`));
      }
    },
 
    credentials: true,                    // Required if using cookies or Authorization header
 
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
 
    allowedHeaders: [
      "Content-Type",
      "Authorization",
      "X-Requested-With",
      "Accept",
    ],
 
    maxAge: 3600,   // Cache preflight (OPTIONS) request for 1 hour
  })
);
// ================================================================
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.get("/", (_req, res) => {
  res.json({
    success: true,
    message: "Biznex API is running",
  });
});

app.get("/health", (_req, res) => {
  res.json({
    success: true,
    status: "ok",
  });
});

app.use("/api", indexRouter);

app.use((req, _res, next) => {
  const error = new Error(`Route not found: ${req.originalUrl}`) as Error & { statusCode?: number };
  error.statusCode = 404;
  next(error);
});

app.use(errorMiddleware);

export default app;
