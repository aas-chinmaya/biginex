import * as tenantRepository from "../modules/BusinessModule/repository/business.repository";

export const generateTenantId = async (
  businessName: string
): Promise<string> => {
  if (!businessName) {
    throw new Error("Business name is required");
  }

  // Remove spaces and special characters
  const cleanedName = businessName
    .replace(/[^a-zA-Z0-9]/g, "")
    .toUpperCase();

  if (!cleanedName) {
    throw new Error("Invalid business name");
  }

  // First 4 characters
  const prefix = cleanedName.substring(0, 4);

  const latestTenant =
    await tenantRepository.findLatestTenantByPrefix(
      prefix
    );

  let nextNumber = 1;

  if (latestTenant?.tenantId) {
    const match = latestTenant.tenantId.match(
      new RegExp(`^${prefix}-Ten-(\\d+)$`)
    );

    if (match) {
      nextNumber = Number(match[1]) + 1;
    }
  }

  return `${prefix}-Ten-${String(nextNumber).padStart(3, "0")}`;
};