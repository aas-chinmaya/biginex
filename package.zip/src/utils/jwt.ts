import jwt from "jsonwebtoken";

const ACCESS_SECRET = process.env.JWT_SECRET as string;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET as string;

// Define type
type UserPayload = {
  id: string;
  roleId: string;
  role: string;
};

export const generateAccessToken = (user: UserPayload) => {
  return jwt.sign(
    { id: user.id, roleId: user.roleId, role: user.role },
    ACCESS_SECRET,
    { expiresIn: "1m" }
  );
};

export const generateRefreshToken = (user: UserPayload) => {
  return jwt.sign(
    { id: user.id },
    REFRESH_SECRET,
    { expiresIn: "7d" }
  );
};
