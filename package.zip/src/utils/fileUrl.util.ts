// utils/fileUrl.util.ts

export const getFileUrl = (
  filePath?: string | null
): string | null => {
  if (!filePath) {
    return null;
  }

  // Already a complete URL
  if (
    filePath.startsWith("http://") ||
    filePath.startsWith("https://")
  ) {
    return filePath;
  }

  const baseUrl =
    process.env.BASE_URL ||
    "http://localhost:8000";

  // Make sure there is only one /
  const cleanBaseUrl = baseUrl.replace(/\/$/, "");

  const cleanPath = filePath.startsWith("/")
    ? filePath
    : `/${filePath}`;

  return `${cleanBaseUrl}${cleanPath}`;
};
