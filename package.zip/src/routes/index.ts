import express from "express";
import v1Routes from "./v1";

const router = express.Router();

//Register Version 1 routes here
router.use("/v1", v1Routes);

export default router;