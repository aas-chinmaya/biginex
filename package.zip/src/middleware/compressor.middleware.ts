
import { Request, Response, NextFunction } from "express";
import { compressFile } from "../common/helpers/compressImage";

export const compressorMiddleware = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {

        // case 1: single file (upload.single)
        if (req.file) {
            req.file = await compressFile(req.file) as Express.Multer.File;
            return next();
        }

        // case 2: multiple files (upload.array)
        if (Array.isArray(req.files) && req.files.length > 0) {
            req.files = await Promise.all(
                (req.files as Express.Multer.File[]).map((file) =>
                    compressFile(file)
                )
            ) as Express.Multer.File[];
            return next();
        }

        // case 3: upload.fields() -> req.files is an object of arrays
        if (req.files && !Array.isArray(req.files)) {
            const filesObj = req.files as { [field: string]: Express.Multer.File[] };

            const entries = await Promise.all(
                Object.entries(filesObj).map(async ([field, arr]) => {
                    const compressedArr = await Promise.all(
                        arr.map((file) => compressFile(file))
                    );
                    return [field, compressedArr] as const;
                })
            );

            req.files = Object.fromEntries(entries);
            return next();
        }

        return next();

    } catch (error) {
        next(error);
    }
};