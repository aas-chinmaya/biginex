import { Request, Response, NextFunction } from "express";
import prisma from "../config/db";

interface AuthRequest extends Request {
  user?: {
    id: string;
    roleId: string;
  };
}

export const checkPermission = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    // Auth check
    if (!req.user) {
      return res.status(401).json({
        message: "Unauthorized"
      });
    }

    const roleId = req.user.roleId;

    // Full route path
    const routePath = req.baseUrl + req.route.path;

    // Find API from DB
    const api = await prisma.api.findFirst({
      where: {
        method: req.method.toUpperCase(),
        route: routePath, // IMPORTANT: store same format in DB
        isDeleted: false
      },
      select: { id: true }
    });

    if (!api) {
      return res.status(404).json({
        message: `API not registered: ${req.method} ${routePath}`
      });
    }

    // ✅ Check permission
    const permission = await prisma.roleApiPermission.findUnique({
      where: {
        roleId_apiId: {
          roleId,
          apiId: api.id
        }
      },
      select: { isAllowed: true }
    });

    // ❗ Correct logic
    if (!permission || !permission.isAllowed) {
      return res.status(403).json({
        message: "Access Denied"
      });
    }

    next();

  } catch (error) {
    console.error("Permission Middleware Error:", error);
    return res.status(500).json({
      message: "Permission check failed"
    });
  }
};
