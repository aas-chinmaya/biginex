import multer from "multer";
import path from "path";
import fs from "fs";

const storage = (folderName: string) =>
  multer.diskStorage({
    destination: (_req, _file, cb) => {
      const uploadPath = path.join(process.cwd(), "uploads", folderName);

      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, {
          recursive: true,
        });
      }

      cb(null, uploadPath);
    },

    filename: (_req, file, cb) => {
      const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`;

      cb(null, uniqueName);
    },
  });

const fileFilter: multer.Options["fileFilter"] = (_req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/svg+xml", "application/pdf"];

  if (!allowedTypes.includes(file.mimetype)) {
    return cb(new Error("Invalid file type"));
  }

  cb(null, true);
};

const uploadFactory = (folderName: string) =>
  multer({
    storage: storage(folderName),
    fileFilter,
    limits: {
      fileSize: 5 * 1024 * 1024,
    },
  });

export default uploadFactory;