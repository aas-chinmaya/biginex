// middlewares/validate.middleware.ts
import { ZodType, ZodError } from "zod";
import { NextFunction, Request, Response } from "express";
import { ValidationError } from "../exceptions/ValidationError";

export const validate =
    (schema: ZodType) =>
    (req: Request, _res: Response, next: NextFunction): void => {
        try {
            schema.parse({
                body: req.body,
                params: req.params,
                query: req.query,
            });

            next();
        } catch (error) {
            if (error instanceof ZodError) {
                throw new ValidationError(
                    "Validation failed.",
                    error.flatten().fieldErrors
                );
            }

            throw error;
        }
    };