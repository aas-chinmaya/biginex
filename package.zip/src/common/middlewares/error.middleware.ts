import type { ErrorRequestHandler } from "express";

const errorMiddleware: ErrorRequestHandler = (err, _req, res, _next) => {
  const statusCode = (err as { statusCode?: number }).statusCode || 500;

  const response: Record<string, unknown> = {
    success: false,
    message: err.message || "Internal Server Error",
  };

  if ((err as { errorCode?: string }).errorCode) {
    response.errorCode = (err as { errorCode?: string }).errorCode;
  }

  if (process.env.NODE_ENV === "development") {
    response.stack = (err as Error).stack;
  }

  return res.status(statusCode).json(response);
};

export default errorMiddleware;