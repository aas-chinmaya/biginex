import type { Request } from "express";

const getFileUrl = (req: Request, filePath?: string | null): string | null => {
  if (!filePath) return null;

  return `${req.protocol}://${req.get("host")}/uploads/${filePath}`;
};

export default getFileUrl;