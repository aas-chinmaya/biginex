export const getEnumValue = <T extends Record<string, string>>(
    enumObject: T,
    value: unknown,
    defaultValue: T[keyof T]
): T[keyof T] => {

    const stringValue =
        String(value ?? "")
            .trim()
            .toUpperCase();

    const values =
        Object.values(enumObject);

    if (values.includes(stringValue as T[keyof T])) {
        return stringValue as T[keyof T];
    }

    return defaultValue;
};