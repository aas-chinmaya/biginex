/**
 * Returns Financial Year
 *
 * Example:
 * 15-Mar-2026  -> 2025-2026
 * 10-Apr-2026  -> 2026-2027
 */

export const generateFinancialYear = (
    date: Date = new Date()
): string => {

    const month = date.getMonth() + 1;
    const year = date.getFullYear();

    if (month >= 4) {
        return `${year}-${year + 1}`;
    }

    return `${year - 1}-${year}`;
};