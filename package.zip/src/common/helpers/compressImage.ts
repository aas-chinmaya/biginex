import sharp from "sharp";
import fs from "fs";
import path from "path";

const TARGET_SIZE = 100 * 1024; // 100 KB

export const compressFile  = async (
    file: Express.Multer.File
) => {
    try {
        if (!file.mimetype.startsWith("image/")) {
            return file;
        }

        const outputPath = file.path.replace(
            path.extname(file.path),
            ".webp"
        );

        let quality = 90;
        let buffer: Buffer;

        while (true) {
            buffer = await sharp(file.path)
                .resize({
                    width: 1200,
                    withoutEnlargement: true,
                })
                .webp({
                    quality,
                })
                .toBuffer();

            if (
                buffer.length <= TARGET_SIZE ||
                quality <= 20
            ) {
                break;
            }

            quality -= 5;
        }

        fs.writeFileSync(outputPath, buffer);
        fs.unlinkSync(file.path);

        return {
            ...file,
            path: outputPath,
            filename: path.basename(outputPath),
            mimetype: "image/webp",
            size: buffer.length,
        };
    } catch (err) {
        console.error(err);
        return file;
    }
};