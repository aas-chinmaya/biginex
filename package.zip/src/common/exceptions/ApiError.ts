class ApiError extends Error {
  statusCode: number;
  errorCode: string | null;

  constructor(statusCode: number, message: string, errorCode: string | null = null) {
    super(message);

    this.statusCode = statusCode;
    this.errorCode = errorCode;

    Error.captureStackTrace(this, this.constructor);
  }
}

export default ApiError;