import ApiError from "./ApiError";

class ForbiddenError extends ApiError {
  constructor(message = "Access denied") {
    super(403, message, "FORBIDDEN");
  }
}

export default ForbiddenError;
