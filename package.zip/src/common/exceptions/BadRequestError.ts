import ApiError from "./ApiError";

class BadRequestError extends ApiError {
  constructor(message = "Bad Request") {
    super(400, message, "BAD_REQUEST");
  }
}

export default BadRequestError;